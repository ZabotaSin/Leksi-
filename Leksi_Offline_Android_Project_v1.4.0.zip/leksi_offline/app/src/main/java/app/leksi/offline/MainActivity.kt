package app.leksi.offline

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

private val Green = Color(0xFF49B96B)
private val DeepGreen = Color(0xFF197A48)
private val Mint = Color(0xFFE3F7E8)
private val Ink = Color(0xFF20352A)
private val Muted = Color(0xFF78877D)
private val Page = Color(0xFFF5F8F4)
private val Orange = Color(0xFFFFB84D)
private val Red = Color(0xFFD94B4B)
private val Purple = Color(0xFF8B78DB)

private data class StudyCard(
    val id: String = UUID.randomUUID().toString(),
    val front: String,
    val back: String,
    val note: String = "",
    val learned: Boolean = false,
    val dueAt: Long = 0L,
    val mastery: Int = 0,
    val wrongStreak: Int = 0,
    val correctStreak: Int = 0,
    val mistakeCount: Int = 0,
    val needsReview: Boolean = false
)

private data class StudyDeck(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val color: Long = 0xFF49B96B,
    val cards: List<StudyCard> = emptyList()
)

private enum class StudyMode { DAILY, CARDS, TEST, WRITE, MATCH }

private const val MISTAKES_DECK_ID = "__leksi_mistakes__"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LeksiApp() }
    }
}

@Composable
private fun LeksiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var decks by remember { mutableStateOf(loadDecks(context)) }
    var language by remember { mutableStateOf(loadLanguage(context)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedDeckId by remember { mutableStateOf<String?>(null) }
    var activeStudyDeckId by remember { mutableStateOf<String?>(null) }
    var activeMode by remember { mutableStateOf(StudyMode.CARDS) }
    var showDeckDialog by remember { mutableStateOf(false) }
    var editingCard by remember { mutableStateOf<Pair<String, StudyCard?>?>(null) }
    var searchText by remember { mutableStateOf("") }
    var dictionaryQuery by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(decks) { saveDecks(context, decks) }
    LaunchedEffect(language) { context.getSharedPreferences("leksi", Context.MODE_PRIVATE).edit().putString("language", language).apply() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() } ?: ""
                val imported = parseCsv(text)
                if (imported.isNotEmpty()) {
                    decks = mergeImported(decks, imported)
                    message = tx(language, "imported") + ": ${imported.sumOf { it.cards.size }}"
                } else message = tx(language, "nothing_imported")
            }.onFailure { message = tx(language, "import_error") }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(toCsv(decks).toByteArray(Charsets.UTF_8)) }
            message = tx(language, "exported")
        }.onFailure { message = tx(language, "export_error") }
    }

    val activeStudyDeck = when (activeStudyDeckId) {
        MISTAKES_DECK_ID -> createMistakesDeck(decks, language)
        else -> decks.firstOrNull { it.id == activeStudyDeckId }
    }
    val selectedDeck = decks.firstOrNull { it.id == selectedDeckId }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, secondary = DeepGreen, background = Page, surface = Color.White, onSurface = Ink),
        typography = Typography(bodyLarge = MaterialTheme.typography.bodyLarge.copy(color = Ink), titleLarge = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = Ink))
    ) {
        if (activeStudyDeck != null) {
            StudyScreen(
                deck = activeStudyDeck,
                mode = activeMode,
                language = language,
                onExit = { activeStudyDeckId = null },
                onUpdateCard = { cardId, isCorrect ->
                    val now = System.currentTimeMillis()
                    decks = decks.map { d ->
                        d.copy(cards = d.cards.map { c ->
                            if (c.id != cardId) c else {
                                if (isCorrect) {
                                    val nextCorrect = c.correctStreak + 1
                                    val nextMastery = (c.mastery + 1).coerceAtMost(5)
                                    val stillNeedsReview = c.needsReview && nextCorrect < 3
                                    c.copy(
                                        learned = nextMastery >= 3 && !stillNeedsReview,
                                        dueAt = now + if (nextMastery >= 4) 86_400_000L else 300_000L,
                                        mastery = nextMastery,
                                        wrongStreak = 0,
                                        correctStreak = nextCorrect,
                                        needsReview = stillNeedsReview
                                    )
                                } else {
                                    val nextWrong = c.wrongStreak + 1
                                    val resetAfterFive = nextWrong >= 5
                                    val nextMastery = if (resetAfterFive) 0 else (c.mastery - 1).coerceAtLeast(0)
                                    c.copy(
                                        learned = false,
                                        dueAt = now + 300_000L,
                                        mastery = nextMastery,
                                        wrongStreak = nextWrong,
                                        correctStreak = 0,
                                        mistakeCount = c.mistakeCount + 1,
                                        needsReview = true
                                    )
                                }
                            }
                        })
                    }
                }
            )
        } else {
            Scaffold(
                containerColor = Page,
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                        NavigationBarItem(selected = selectedTab == 0 && selectedDeckId == null, onClick = { selectedTab = 0; selectedDeckId = null }, icon = { Icon(Icons.Filled.Home, null) }, label = { Text(tx(language, "home")) })
                        NavigationBarItem(selected = selectedTab == 1 || selectedDeckId != null, onClick = { selectedTab = 1; selectedDeckId = null }, icon = { Icon(Icons.Filled.CollectionsBookmark, null) }, label = { Text(tx(language, "sets")) })
                        NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; selectedDeckId = null }, icon = { Icon(Icons.Filled.EmojiEvents, null) }, label = { Text(tx(language, "progress")) })
                        NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3; selectedDeckId = null }, icon = { Icon(Icons.Filled.Settings, null) }, label = { Text(tx(language, "settings")) })
                        NavigationBarItem(selected = selectedTab == 4, onClick = { selectedTab = 4; selectedDeckId = null }, icon = { Icon(Icons.Filled.MenuBook, null) }, label = { Text(tx(language, "dictionary")) })
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    if (selectedDeck != null) {
                        DeckDetailScreen(
                            deck = selectedDeck,
                            language = language,
                            onBack = { selectedDeckId = null },
                            onStudy = { mode -> activeStudyDeckId = selectedDeck.id; activeMode = mode },
                            onChangeColor = { color -> decks = decks.map { if (it.id == selectedDeck.id) it.copy(color = color) else it } },
                            onAddCard = { editingCard = selectedDeck.id to null },
                            onEditCard = { card -> editingCard = selectedDeck.id to card },
                            onDeleteCard = { card -> decks = decks.map { d -> if (d.id == selectedDeck.id) d.copy(cards = d.cards.filterNot { it.id == card.id }) else d } },
                            onRename = { newTitle -> decks = decks.map { if (it.id == selectedDeck.id) it.copy(title = newTitle) else it } },
                            onDeleteDeck = { decks = decks.filterNot { it.id == selectedDeck.id }; selectedDeckId = null }
                        )
                    } else when (selectedTab) {
                        0 -> HomeScreen(decks, language, onStudy = { deck -> activeStudyDeckId = deck.id; activeMode = StudyMode.DAILY }, onOpenDeck = { selectedDeckId = it.id; selectedTab = 1 }, onAllSets = { selectedTab = 1 })
                        1 -> SetsScreen(decks, language, searchText, onSearch = { searchText = it }, onAdd = { showDeckDialog = true }, onOpen = { if (it.id == MISTAKES_DECK_ID) { activeStudyDeckId = MISTAKES_DECK_ID; activeMode = StudyMode.CARDS } else selectedDeckId = it.id }, onStudy = { activeStudyDeckId = it.id; activeMode = StudyMode.CARDS })
                        2 -> ProgressScreen(decks, language)
                        3 -> SettingsScreen(language, onLanguage = { language = it }, onImport = { importLauncher.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel")) }, onExport = { exportLauncher.launch("leksi-backup.csv") })
                        else -> DictionaryScreen(
                            decks = decks,
                            language = language,
                            query = dictionaryQuery,
                            onQuery = { dictionaryQuery = it },
                            onAddWord = { deckId, entry ->
                                val existing = decks.firstOrNull { it.id == deckId }
                                if (existing != null) {
                                    val already = existing.cards.any { it.front.equals(entry.serbian, true) && it.back.equals(entry.russian, true) }
                                    if (already) message = tx(language, "word_exists")
                                    else {
                                        decks = decks.map { d -> if (d.id == deckId) d.copy(cards = d.cards + StudyCard(front = entry.serbian, back = entry.russian, note = entry.example)) else d }
                                        message = tx(language, "word_added") + ": ${entry.serbian}"
                                    }
                                }
                            },
                            onCreateSetAndAdd = { entry ->
                                val newDeck = StudyDeck(title = tx(language, "dictionary_set"), cards = listOf(StudyCard(front = entry.serbian, back = entry.russian, note = entry.example)))
                                decks = decks + newDeck
                                message = tx(language, "word_added") + ": ${entry.serbian}"
                            }
                        )
                    }
                }
            }
        }

        if (showDeckDialog) {
            TextEntryDialog(title = tx(language, "new_set"), label = tx(language, "set_name"), confirm = tx(language, "create"), onDismiss = { showDeckDialog = false }) { title ->
                if (title.isNotBlank()) {
                    decks = decks + StudyDeck(title = title.trim(), color = listOf(0xFF49B96B, 0xFF8B78DB, 0xFFFFB84D, 0xFF4DA6D9).random())
                    showDeckDialog = false
                }
            }
        }
        editingCard?.let { (deckId, card) ->
            CardEditorDialog(card = card, language = language, onDismiss = { editingCard = null }) { front, back, note ->
                if (front.isNotBlank() && back.isNotBlank()) {
                    decks = decks.map { d ->
                        if (d.id != deckId) d else if (card == null) d.copy(cards = d.cards + StudyCard(front = front.trim(), back = back.trim(), note = note.trim()))
                        else d.copy(cards = d.cards.map { if (it.id == card.id) it.copy(front = front.trim(), back = back.trim(), note = note.trim()) else it })
                    }
                    editingCard = null
                }
            }
        }
        message?.let { msg ->
            AlertDialog(onDismissRequest = { message = null }, title = { Text(tx(language, "notice")) }, text = { Text(msg) }, confirmButton = { TextButton(onClick = { message = null }) { Text(tx(language, "ok")) } })
        }
    }
}

@Composable
private fun BrandHeader(language: String, subtitle: String? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(Green), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("leksi", fontSize = 23.sp, fontWeight = FontWeight.Black, color = DeepGreen, letterSpacing = (-0.8).sp)
            Text(subtitle ?: tx(language, "learn_play"), fontSize = 12.sp, color = Muted)
        }
        Box(Modifier.clip(CircleShape).background(Mint).padding(horizontal = 11.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.LocalFireDepartment, null, tint = Color(0xFFE89B24), modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("1", fontWeight = FontWeight.Bold, color = DeepGreen, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun HomeScreen(decks: List<StudyDeck>, language: String, onStudy: (StudyDeck) -> Unit, onOpenDeck: (StudyDeck) -> Unit, onAllSets: () -> Unit) {
    val allCards = decks.sumOf { it.cards.size }
    val learned = decks.sumOf { d -> d.cards.count { it.learned } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            BrandHeader(language)
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(tx(language, "hello"), fontSize = 29.sp, fontWeight = FontWeight.Black, color = Ink)
                Text(tx(language, "small_steps"), color = Muted, fontSize = 15.sp, modifier = Modifier.padding(top = 3.dp, bottom = 18.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Green).padding(20.dp)) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tx(language, "ready_today"), color = Color.White.copy(alpha = .88f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(tx(language, "little_every_day"), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 27.sp, modifier = Modifier.padding(top = 5.dp))
                            }
                            Box(Modifier.size(66.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.School, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("$learned / $allCards", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(tx(language, "cards_learned"), color = Color.White.copy(alpha = .84f), fontSize = 12.sp)
                            }
                            Button(onClick = { decks.firstOrNull { it.cards.isNotEmpty() }?.let(onStudy) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepGreen), shape = RoundedCornerShape(16.dp), enabled = decks.any { it.cards.isNotEmpty() }) {
                                Text(tx(language, "start"), fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Icon(Icons.Filled.ArrowForward, null, modifier = Modifier.size(17.dp))
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatPill(Modifier.weight(1f), Icons.Filled.CollectionsBookmark, decks.size.toString(), tx(language, "sets"), Purple)
                    StatPill(Modifier.weight(1f), Icons.Filled.Style, allCards.toString(), tx(language, "cards"), Orange)
                    StatPill(Modifier.weight(1f), Icons.Filled.CheckCircle, learned.toString(), tx(language, "known"), Green)
                }
                Row(Modifier.fillMaxWidth().padding(top = 17.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(language, "your_sets"), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onAllSets) { Text(tx(language, "see_all"), color = DeepGreen) }
                }
            }
        }
        if (decks.isEmpty()) item { EmptyState(language, tx(language, "no_sets"), tx(language, "make_first_set"), Icons.Filled.CollectionsBookmark) }
        items(decks.take(4), key = { it.id }) { deck -> DeckRow(deck, language, onClick = { onOpenDeck(deck) }, onStudy = { onStudy(deck) }) }
    }
}

@Composable
private fun StatPill(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, number: String, label: String, tint: Color) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).padding(horizontal = 12.dp, vertical = 14.dp)) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
        Text(number, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(top = 8.dp))
        Text(label, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SetsScreen(decks: List<StudyDeck>, language: String, searchText: String, onSearch: (String) -> Unit, onAdd: () -> Unit, onOpen: (StudyDeck) -> Unit, onStudy: (StudyDeck) -> Unit) {
    val mistakesDeck = createMistakesDeck(decks, language)
    val visibleDecks = (if (mistakesDeck.cards.isNotEmpty()) listOf(mistakesDeck) else emptyList()) + decks
    val filtered = visibleDecks.filter { it.title.contains(searchText, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        BrandHeader(language, tx(language, "your_library"))
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tx(language, "your_sets"), fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            FilledIconButton(onClick = onAdd, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)) { Icon(Icons.Filled.Add, null, tint = Color.White) }
        }
        OutlinedTextField(value = searchText, onValueChange = onSearch, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), placeholder = { Text(tx(language, "search_sets")) }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) }, shape = RoundedCornerShape(18.dp), singleLine = true, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFFE3EAE2), focusedBorderColor = Green))
        if (filtered.isEmpty()) {
            EmptyState(language, tx(language, "nothing_here"), tx(language, "create_or_search"), Icons.Filled.AutoAwesome)
        } else LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) { items(filtered, key = { it.id }) { DeckRow(it, language, onClick = { onOpen(it) }, onStudy = { onStudy(it) }) } }
    }
}

@Composable
private fun DeckRow(deck: StudyDeck, language: String, onClick: () -> Unit, onStudy: () -> Unit) {
    val color = Color(deck.color)
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(22.dp)).background(Color.White).clickable(onClick = onClick).padding(15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(color.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Style, null, tint = color, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(deck.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${deck.cards.size} ${tx(language, "cards_small")}  •  ${deck.cards.count { it.learned }} ${tx(language, "known_small")}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                val progress = if (deck.cards.isEmpty()) 0f else deck.cards.count { it.learned }.toFloat() / deck.cards.size
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(5.dp).clip(CircleShape), color = color, trackColor = color.copy(alpha = .12f))
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onStudy, enabled = deck.cards.isNotEmpty()) { Icon(Icons.Filled.PlayArrow, null, tint = if (deck.cards.isNotEmpty()) DeepGreen else Muted) }
        }
    }
}

@Composable
private fun DeckDetailScreen(deck: StudyDeck, language: String, onBack: () -> Unit, onStudy: (StudyMode) -> Unit, onChangeColor: (Long) -> Unit, onAddCard: () -> Unit, onEditCard: (StudyCard) -> Unit, onDeleteCard: (StudyCard) -> Unit, onRename: (String) -> Unit, onDeleteDeck: () -> Unit) {
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    var showColorPicker by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
                Text(deck.title, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton(onClick = { showColorPicker = true }) { Icon(Icons.Filled.Palette, null, tint = Color(deck.color)) }
                IconButton(onClick = { showRename = true }) { Icon(Icons.Filled.Edit, null, tint = Muted) }
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Filled.DeleteOutline, null, tint = Red) }
            }
            Column(Modifier.padding(horizontal = 20.dp)) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color(deck.color)).padding(20.dp)) {
                    Column {
                        Text(tx(language, "study_set"), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                        Text(deck.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 5.dp))
                        Text("${deck.cards.size} ${tx(language, "cards_small")}  •  ${deck.cards.count { it.learned }} ${tx(language, "known_small")}", color = Color.White.copy(alpha = .9f), modifier = Modifier.padding(top = 6.dp))
                        Button(onClick = { onStudy(StudyMode.DAILY) }, enabled = deck.cards.isNotEmpty(), modifier = Modifier.padding(top = 15.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepGreen), shape = RoundedCornerShape(15.dp)) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text(tx(language, "start_learning"), fontWeight = FontWeight.Bold) }
                    }
                }
                Text(tx(language, "practice_modes"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    ModeTile(Modifier.weight(1f), Icons.Filled.Style, tx(language, "flashcards"), Purple, enabled = deck.cards.isNotEmpty()) { onStudy(StudyMode.CARDS) }
                    ModeTile(Modifier.weight(1f), Icons.Filled.Quiz, tx(language, "test"), Orange, enabled = deck.cards.isNotEmpty()) { onStudy(StudyMode.TEST) }
                }
                Row(Modifier.padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    ModeTile(Modifier.weight(1f), Icons.Filled.Keyboard, tx(language, "write_answer"), Green, enabled = deck.cards.isNotEmpty()) { onStudy(StudyMode.WRITE) }
                    ModeTile(Modifier.weight(1f), Icons.Filled.GridView, tx(language, "matching"), Color(0xFF4DA6D9), enabled = deck.cards.size >= 2) { onStudy(StudyMode.MATCH) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 23.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(language, "cards_in_set"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onAddCard) { Icon(Icons.Filled.Add, null); Text(tx(language, "add_card")) }
                }
            }
        }
        if (deck.cards.isEmpty()) item { EmptyState(language, tx(language, "empty_set"), tx(language, "add_first_card"), Icons.Filled.Style) }
        items(deck.cards, key = { it.id }) { card ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { onEditCard(card) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(4.dp).height(48.dp).clip(CircleShape).background(if (card.learned) Green else Color(0xFFDDE6DC)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(card.front, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(card.back, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 5.dp)) {
                        repeat(5) { level ->
                            Box(Modifier.padding(end = 3.dp).size(width = 16.dp, height = 4.dp).clip(CircleShape).background(if (level < card.mastery) Green else Color(0xFFE1E8E0)))
                        }
                        Text("${card.mastery}/5", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 3.dp))
                        if (card.needsReview) Text(" • ${tx(language, "mistakes_folder")}", color = Red, fontSize = 10.sp)
                    }
                    if (card.note.isNotBlank()) Text(card.note, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                }
                if (card.learned) Icon(Icons.Filled.CheckCircle, null, tint = Green, modifier = Modifier.size(18.dp))
                IconButton(onClick = { onDeleteCard(card) }) { Icon(Icons.Filled.DeleteOutline, null, tint = Color(0xFFB0BAB1), modifier = Modifier.size(19.dp)) }
            }
        }
    }
    if (showRename) TextEntryDialog(title = tx(language, "rename_set"), label = tx(language, "set_name"), initial = deck.title, confirm = tx(language, "save"), onDismiss = { showRename = false }) { onRename(it.trim()); showRename = false }
    if (showColorPicker) {
        val palette = listOf(0xFF49B96B, 0xFF197A48, 0xFF8B78DB, 0xFFFFB84D, 0xFF4DA6D9, 0xFFE87575, 0xFFEC78B4, 0xFF6D7FE8, 0xFF7D8B84, 0xFF7D5A45)
        AlertDialog(
            onDismissRequest = { showColorPicker = false },
            title = { Text(tx(language, "set_color")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    palette.chunked(5).forEach { rowColors ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            rowColors.forEach { value ->
                                Box(Modifier.size(42.dp).clip(CircleShape).background(Color(value)).clickable { onChangeColor(value); showColorPicker = false }, contentAlignment = Alignment.Center) {
                                    if (deck.color == value) Icon(Icons.Filled.Check, null, tint = Color.White)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showColorPicker = false }) { Text(tx(language, "cancel")) } }
        )
    }
    if (showDelete) AlertDialog(onDismissRequest = { showDelete = false }, title = { Text(tx(language, "delete_set")) }, text = { Text(tx(language, "delete_set_warning")) }, confirmButton = { TextButton(onClick = { onDeleteDeck(); showDelete = false }) { Text(tx(language, "delete"), color = Red) } }, dismissButton = { TextButton(onClick = { showDelete = false }) { Text(tx(language, "cancel")) } })
}

@Composable
private fun ModeTile(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, tint: Color, enabled: Boolean, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(19.dp)).background(Color.White).clickable(enabled = enabled, onClick = onClick).padding(14.dp)) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(tint.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp), color = if (enabled) Ink else Muted)
    }
}

@Composable
private fun StudyScreen(deck: StudyDeck, mode: StudyMode, language: String, onExit: () -> Unit, onUpdateCard: (String, Boolean) -> Unit) {
    var index by remember(deck.id, mode) { mutableIntStateOf(0) }
    var revealed by remember(deck.id, mode) { mutableStateOf(false) }
    var selectedAnswer by remember(deck.id, mode) { mutableStateOf<String?>(null) }
    var typedAnswer by remember(deck.id, mode) { mutableStateOf("") }
    var submitted by remember(deck.id, mode) { mutableStateOf(false) }
    var matched by remember(deck.id, mode) { mutableStateOf(setOf<String>()) }
    var selectedFrontId by remember(deck.id, mode) { mutableStateOf<String?>(null) }
    val cards = remember(deck.id, mode) { if (mode == StudyMode.MATCH) deck.cards.shuffled().take(6) else weightedReviewOrder(deck.cards) }
    val matchFronts = remember(deck.id, mode) { cards.shuffled() }
    val matchBacks = remember(deck.id, mode) { cards.shuffled() }
    val current = cards.getOrNull(index)
    val options = remember(deck.id, mode, index) {
        current?.let { card -> (cards.filter { it.id != card.id }.map { it.back }.distinct().shuffled().take(3) + card.back).distinct().shuffled() } ?: emptyList()
    }
    if (mode == StudyMode.DAILY) {
        DailyChallengeScreen(deck = deck, language = language, onExit = onExit, onUpdateCard = onUpdateCard)
        return
    }
    Column(Modifier.fillMaxSize().background(Page)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onExit) { Icon(Icons.Filled.Close, null) }
            Column(Modifier.weight(1f)) {
                Text(deck.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(modeLabel(language, mode), color = Muted, fontSize = 12.sp)
            }
            Text(if (mode == StudyMode.MATCH) "${matched.size}/${cards.size}" else "${(index + 1).coerceAtMost(cards.size)} / ${cards.size}", color = DeepGreen, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { if (cards.isEmpty()) 0f else if (mode == StudyMode.MATCH) matched.size.toFloat() / cards.size else index.toFloat() / cards.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(6.dp).clip(CircleShape), color = Green, trackColor = Color(0xFFE0E9E0))
        if (cards.isEmpty()) {
            EmptyState(language, tx(language, "empty_set"), tx(language, "add_first_card"), Icons.Filled.Style)
        } else if (mode == StudyMode.MATCH) {
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Text(tx(language, "match_instruction"), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 10.dp))
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        matchFronts.forEach { card ->
                            val done = card.id in matched
                            Surface(modifier = Modifier.fillMaxWidth().weight(1f).clickable(enabled = !done) { selectedFrontId = card.id }, shape = RoundedCornerShape(15.dp), color = when { done -> Mint; selectedFrontId == card.id -> Color(0xFFDDE8FF); else -> Color.White }, border = BorderStroke(1.dp, if (selectedFrontId == card.id) Purple else Color(0xFFE4EAE3))) { Box(Modifier.padding(8.dp), contentAlignment = Alignment.Center) { Text(card.front, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) } }
                        }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        matchBacks.forEach { card ->
                            val done = card.id in matched
                            Surface(modifier = Modifier.fillMaxWidth().weight(1f).clickable(enabled = !done) {
                                val selected = cards.firstOrNull { it.id == selectedFrontId }
                                if (selected != null && selected.back == card.back) {
                                    matched = matched + selected.id + card.id
                                    onUpdateCard(selected.id, true); onUpdateCard(card.id, true)
                                } else if (selected != null) {
                                    onUpdateCard(selected.id, false)
                                }
                                selectedFrontId = null
                            }, shape = RoundedCornerShape(15.dp), color = if (done) Mint else Color.White, border = BorderStroke(1.dp, Color(0xFFE4EAE3))) { Box(Modifier.padding(8.dp), contentAlignment = Alignment.Center) { Text(card.back, fontWeight = FontWeight.Medium, fontSize = 13.sp) } }
                        }
                    }
                }
                if (matched.size >= cards.size) Button(onClick = onExit, modifier = Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "finish")) }
            }
        } else if (current == null) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(94.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Icon(Icons.Filled.EmojiEvents, null, tint = Green, modifier = Modifier.size(52.dp)) }
                Text(tx(language, "session_done"), fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 20.dp))
                Text(tx(language, "keep_it_up"), color = Muted, modifier = Modifier.padding(top = 7.dp))
                Button(onClick = onExit, modifier = Modifier.fillMaxWidth().padding(top = 25.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "finish")) }
            }
        } else when (mode) {
            StudyMode.DAILY -> Unit
            StudyMode.CARDS -> {
                Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tx(language, "tap_to_reveal"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 15.dp))
                    Surface(Modifier.fillMaxWidth().weight(1f).clickable { revealed = !revealed }, shape = RoundedCornerShape(30.dp), color = Color.White, shadowElevation = 3.dp) {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Box(Modifier.clip(CircleShape).background(Mint).padding(horizontal = 12.dp, vertical = 7.dp)) { Text(if (revealed) tx(language, "answer") else tx(language, "question"), color = DeepGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            Text(if (revealed) current.back else current.front, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp, modifier = Modifier.padding(top = 24.dp), color = Ink)
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 18.dp)) {
                                repeat(5) { level ->
                                    Box(Modifier.size(width = 23.dp, height = 5.dp).clip(CircleShape).background(if (level < current.mastery) Green else Color(0xFFE1E8E0)))
                                }
                            }
                            Text("${tx(language, "mastery_label")}: ${current.mastery}/5", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                            if (revealed && current.note.isNotBlank()) Text(current.note, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 15.dp))
                            if (!revealed) Text(tx(language, "tap_card"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 27.dp))
                        }
                    }
                    if (!revealed) Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), shape = RoundedCornerShape(17.dp)) { Text(tx(language, "show_answer")) }
                    else Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { onUpdateCard(current.id, false); index++; revealed = false }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Color(0xFFF0B8B8)), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Icon(Icons.Filled.Replay, null); Spacer(Modifier.width(5.dp)); Text(tx(language, "again"), fontWeight = FontWeight.Bold) }
                        Button(onClick = { onUpdateCard(current.id, true); index++; revealed = false }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(17.dp)) { Icon(Icons.Filled.Check, null); Spacer(Modifier.width(5.dp)); Text(tx(language, "know_it"), fontWeight = FontWeight.Bold) }
                    }
                }
            }
            StudyMode.TEST -> {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Text(tx(language, "choose_translation"), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
                    Text(current.front, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 18.dp))
                    options.forEach { option ->
                        val isCorrect = option == current.back
                        val bg = when { selectedAnswer == null -> Color.White; option == selectedAnswer && isCorrect -> Mint; option == selectedAnswer && !isCorrect -> Color(0xFFFFE7E7); isCorrect -> Mint; else -> Color.White }
                        Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(enabled = selectedAnswer == null) { selectedAnswer = option; onUpdateCard(current.id, isCorrect) }, shape = RoundedCornerShape(17.dp), color = bg, border = BorderStroke(1.dp, when { selectedAnswer == option && isCorrect -> Green; selectedAnswer == option -> Red; else -> Color(0xFFE4EAE3) })) { Text(option, Modifier.padding(16.dp), fontWeight = FontWeight.SemiBold) }
                    }
                    Spacer(Modifier.weight(1f))
                    if (selectedAnswer != null) Text(if (selectedAnswer == current.back) tx(language, "correct") else "${tx(language, "incorrect")} ${current.back}", color = if (selectedAnswer == current.back) DeepGreen else Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp))
                    Button(onClick = { index++; selectedAnswer = null }, enabled = selectedAnswer != null, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(if (index == cards.lastIndex) tx(language, "finish") else tx(language, "next")) }
                }
            }
            StudyMode.WRITE -> {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Text(tx(language, "type_translation"), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
                    Text(current.front, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp, bottom = 25.dp))
                    OutlinedTextField(value = typedAnswer, onValueChange = { typedAnswer = it; submitted = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tx(language, "your_answer")) }, shape = RoundedCornerShape(17.dp), singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
                    if (submitted) {
                        val ok = typedAnswer.trim().equals(current.back.trim(), ignoreCase = true)
                        Text(if (ok) tx(language, "correct") else "${tx(language, "correct_answer")}: ${current.back}", color = if (ok) DeepGreen else Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 15.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = {
                        if (!submitted) { submitted = true; onUpdateCard(current.id, typedAnswer.trim().equals(current.back.trim(), ignoreCase = true)) }
                        else { index++; typedAnswer = ""; submitted = false }
                    }, enabled = typedAnswer.isNotBlank(), modifier = Modifier.fillMaxWidth().height(53.dp), shape = RoundedCornerShape(16.dp)) { Text(if (submitted) tx(language, "next") else tx(language, "check_answer")) }
                }
            }
            StudyMode.MATCH -> Unit
        }
    }
}

private enum class DailyTask { FLASH, QUIZ, TYPE, PAIR }

private fun weightedReviewOrder(source: List<StudyCard>): List<StudyCard> {
    if (source.size < 2) return source.shuffled()
    val unknown = source.filterNot { it.learned }.shuffled().toMutableList()
    val known = source.filter { it.learned }.shuffled()
    if (unknown.isEmpty()) return known
    val knownQuota = if (known.isEmpty()) 0 else maxOf(1, (unknown.size + 3) / 4).coerceAtMost(known.size)
    val selectedKnown = known.take(knownQuota)
    return (unknown + selectedKnown).shuffled()
}

private fun makeDailyQueue(source: List<StudyCard>, size: Int = 20): List<StudyCard> {
    if (source.isEmpty()) return emptyList()
    val result = mutableListOf<StudyCard>()
    repeat(size) {
        val candidates = if (source.size > 1) source.filterNot { it.id == result.lastOrNull()?.id } else source
        val weighted = candidates.flatMap { card -> List(if (card.learned) 1 else 4) { card } }
        result += weighted.random()
    }
    return result
}

@Composable
private fun DailyChallengeScreen(deck: StudyDeck, language: String, onExit: () -> Unit, onUpdateCard: (String, Boolean) -> Unit) {
    val tasks = remember(deck.id) { makeDailyQueue(deck.cards, 20) }
    val taskKinds = remember(deck.id) { List(tasks.size) { listOf(DailyTask.FLASH, DailyTask.QUIZ, DailyTask.TYPE, DailyTask.PAIR).random() } }
    var index by remember(deck.id) { mutableIntStateOf(0) }
    var revealed by remember(deck.id) { mutableStateOf(false) }
    var selected by remember(deck.id) { mutableStateOf<String?>(null) }
    var typed by remember(deck.id) { mutableStateOf("") }
    var checked by remember(deck.id) { mutableStateOf(false) }
    var correctCount by remember(deck.id) { mutableIntStateOf(0) }
    val current = tasks.getOrNull(index)
    val kind = taskKinds.getOrNull(index) ?: DailyTask.FLASH
    val options = remember(deck.id, index) {
        current?.let { c ->
            (tasks.filter { it.id != c.id }.map { it.back }.distinct().shuffled().take(3) + c.back).distinct().shuffled()
        } ?: emptyList()
    }
    Column(Modifier.fillMaxSize().background(Page)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onExit) { Icon(Icons.Filled.Close, null) }
            Column(Modifier.weight(1f)) {
                Text(tx(language, "daily_challenge"), fontWeight = FontWeight.Bold)
                Text(tx(language, "daily_subtitle"), color = Muted, fontSize = 11.sp, maxLines = 2)
            }
            Text("${(index + 1).coerceAtMost(tasks.size)} / ${tasks.size}", color = DeepGreen, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { if (tasks.isEmpty()) 0f else index.toFloat() / tasks.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(6.dp).clip(CircleShape), color = Green, trackColor = Color(0xFFE0E9E0))
        if (current == null) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(94.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Icon(Icons.Filled.EmojiEvents, null, tint = Green, modifier = Modifier.size(52.dp)) }
                Text(tx(language, "session_done"), fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 20.dp))
                Text("$correctCount / ${tasks.size}", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = DeepGreen, modifier = Modifier.padding(top = 10.dp))
                Text(tx(language, "keep_it_up"), color = Muted, modifier = Modifier.padding(top = 7.dp))
                Button(onClick = onExit, modifier = Modifier.fillMaxWidth().padding(top = 25.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "finish")) }
            }
        } else {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                val label = when (kind) {
                    DailyTask.FLASH -> tx(language, "flashcards")
                    DailyTask.QUIZ -> tx(language, "test")
                    DailyTask.TYPE -> tx(language, "write_answer")
                    DailyTask.PAIR -> tx(language, "pair_game")
                }
                Text("${tx(language, "daily_step")} ${index + 1} · $label", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp))
                Surface(Modifier.fillMaxWidth().weight(1f), shape = RoundedCornerShape(27.dp), color = Color.White, shadowElevation = 2.dp) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        when (kind) {
                            DailyTask.FLASH -> {
                                Text(if (revealed) tx(language, "answer") else tx(language, "question"), color = DeepGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(if (revealed) current.back else current.front, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 20.dp))
                                if (revealed && current.note.isNotBlank()) Text(current.note, color = Muted, modifier = Modifier.padding(top = 12.dp))
                            }
                            DailyTask.QUIZ -> {
                                Text(tx(language, "choose_translation"), color = Muted, fontSize = 13.sp)
                                Text(current.front, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 14.dp, bottom = 12.dp))
                            }
                            DailyTask.TYPE -> {
                                Text(tx(language, "type_translation"), color = Muted, fontSize = 13.sp)
                                Text(current.front, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 14.dp, bottom = 18.dp))
                                OutlinedTextField(value = typed, onValueChange = { typed = it; checked = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tx(language, "your_answer")) }, shape = RoundedCornerShape(15.dp), singleLine = true)
                            }
                            DailyTask.PAIR -> {
                                Text(tx(language, "match_instruction"), color = Muted, fontSize = 13.sp)
                                Text(current.front, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 14.dp, bottom = 12.dp))
                            }
                        }
                    }
                }
                if (kind == DailyTask.QUIZ || kind == DailyTask.PAIR) {
                    Spacer(Modifier.height(12.dp))
                    options.forEach { option ->
                        val isRight = option == current.back
                        val bg = when { selected == null -> Color.White; option == current.back -> Mint; option == selected -> Color(0xFFFFE7E7); else -> Color.White }
                        Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(enabled = selected == null) {
                            selected = option; checked = true; val ok = isRight; if (ok) correctCount++; onUpdateCard(current.id, ok)
                        }, shape = RoundedCornerShape(15.dp), color = bg, border = BorderStroke(1.dp, when { selected == option && isRight -> Green; selected == option -> Red; else -> Color(0xFFE4EAE3) })) {
                            Text(option, Modifier.padding(14.dp), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                if (kind == DailyTask.TYPE && checked) {
                    val ok = typed.trim().equals(current.back.trim(), ignoreCase = true)
                    Text(if (ok) tx(language, "correct") else "${tx(language, "correct_answer")}: ${current.back}", color = if (ok) DeepGreen else Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                }
                if ((kind == DailyTask.QUIZ || kind == DailyTask.PAIR) && checked) {
                    Text(if (selected == current.back) tx(language, "correct") else "${tx(language, "incorrect")} ${current.back}", color = if (selected == current.back) DeepGreen else Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                }
                Spacer(Modifier.height(12.dp))
                when (kind) {
                    DailyTask.FLASH -> if (!revealed) Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "show_answer")) }
                    else Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { onUpdateCard(current.id, false); advanceDaily(tasks, index, { index = it }, { revealed = it }, { selected = it }, { typed = it }, { checked = it }) }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "again")) }
                        Button(onClick = { onUpdateCard(current.id, true); correctCount++; advanceDaily(tasks, index, { index = it }, { revealed = it }, { selected = it }, { typed = it }, { checked = it }) }, modifier = Modifier.weight(1f).height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "know_it")) }
                    }
                    DailyTask.TYPE -> Button(onClick = {
                        if (!checked) { checked = true; val ok = typed.trim().equals(current.back.trim(), ignoreCase = true); if (ok) correctCount++; onUpdateCard(current.id, ok) }
                        else advanceDaily(tasks, index, { index = it }, { revealed = it }, { selected = it }, { typed = it }, { checked = it })
                    }, enabled = typed.isNotBlank(), modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(if (checked) tx(language, "next") else tx(language, "check_answer")) }
                    DailyTask.QUIZ, DailyTask.PAIR -> Button(onClick = { advanceDaily(tasks, index, { index = it }, { revealed = it }, { selected = it }, { typed = it }, { checked = it }) }, enabled = selected != null, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(if (index == tasks.lastIndex) tx(language, "finish") else tx(language, "next")) }
                }
            }
        }
    }
}

private fun advanceDaily(tasks: List<StudyCard>, index: Int, setIndex: (Int) -> Unit, setRevealed: (Boolean) -> Unit, setSelected: (String?) -> Unit, setTyped: (String) -> Unit, setChecked: (Boolean) -> Unit) {
    setIndex(index + 1)
    setRevealed(false)
    setSelected(null)
    setTyped("")
    setChecked(false)
}

private data class DictionaryEntry(val serbian: String, val russian: String, val example: String, val category: String)

private val offlineSerbianDictionary: List<DictionaryEntry> = listOf(
    "ја|я|Ја сам овде.|Основы",
    "ти|ты|Ти си добар.|Основы",
    "он|он|Он је код куће.|Основы",
    "она|она|Она је овде.|Основы",
    "оно|оно|Оно је мало.|Основы",
    "ми|мы|Ми смо спремни.|Основы",
    "ви|вы|Ви сте љубазни.|Основы",
    "они|они|Они су код куће.|Основы",
    "мој|мой|Научи ову реч: „мој“.|Основы",
    "твој|твой|Научи ову реч: „твој“.|Основы",
    "његов|его|Научи ову реч: „његов“.|Основы",
    "њен|её|Научи ову реч: „њен“.|Основы",
    "наш|наш|Научи ову реч: „наш“.|Основы",
    "ваш|ваш|Научи ову реч: „ваш“.|Основы",
    "њихов|их|Научи ову реч: „њихов“.|Основы",
    "овај|этот|Научи ову реч: „овај“.|Основы",
    "ова|эта|Научи ову реч: „ова“.|Основы",
    "ово|это|Научи ову реч: „ово“.|Основы",
    "тај|тот|Научи ову реч: „тај“.|Основы",
    "та|та|Научи ову реч: „та“.|Основы",
    "то|то|Научи ову реч: „то“.|Основы",
    "ко|кто|Ко је то?|Общение",
    "шта|что|Шта је ово?|Общение",
    "где|где|Где је књига?|Общение",
    "куда|куда|Научи ову реч: „куда“.|Основы",
    "одакле|откуда|Научи ову реч: „одакле“.|Основы",
    "када|когда|Када долазиш?|Общение",
    "зашто|почему|Зашто си овде?|Общение",
    "како|как|Како се зовеш?|Общение",
    "колико|сколько|Колико кошта?|Общение",
    "који|который;какой|Који дан је данас?|Общение",
    "чији|чей|Научи ову реч: „чији“.|Основы",
    "не|нет|Не, хвала.|Общение",
    "да|да|Да, разумем.|Общение",
    "и|и|Научи ову реч: „и“.|Основы",
    "или|или|Научи ову реч: „или“.|Основы",
    "али|но|Научи ову реч: „али“.|Основы",
    "јер|потому что|Научи ову реч: „јер“.|Основы",
    "ако|если|Научи ову реч: „ако“.|Основы",
    "док|пока|Научи ову реч: „док“.|Основы",
    "такође|также|Научи ову реч: „такође“.|Основы",
    "само|только|Научи ову реч: „само“.|Основы",
    "веома|очень|Научи ову реч: „веома“.|Основы",
    "много|много|Научи ову реч: „много“.|Основы",
    "мало|мало|Научи ову реч: „мало“.|Основы",
    "све|всё|Научи ову реч: „све“.|Основы",
    "нешто|что-то|Научи ову реч: „нешто“.|Основы",
    "ништа|ничего|Научи ову реч: „ништа“.|Основы",
    "неко|кто-то|Научи ову реч: „неко“.|Основы",
    "нико|никто|Научи ову реч: „нико“.|Основы",
    "сваки|каждый|Научи ову реч: „сваки“.|Основы",
    "други|другой|Научи ову реч: „други“.|Основы",
    "исти|тот же|Научи ову реч: „исти“.|Основы",
    "можда|может быть|Можда сутра.|Общение",
    "стварно|действительно|Научи ову реч: „стварно“.|Общение и время",
    "овде|здесь|Овде живим.|Направления",
    "тамо|там|Књига је тамо.|Направления",
    "негде|где-то|Научи ову реч: „негде“.|Общение и время",
    "свуда|везде|Научи ову реч: „свуда“.|Общение и время",
    "сада|сейчас|Сада немам времена.|Время",
    "данас|сегодня|Данас радим.|Время",
    "сутра|завтра|Видимо се сутра.|Время",
    "јуче|вчера|Јуче сам био код куће.|Время",
    "увек|всегда|Научи ову реч: „увек“.|Общение и время",
    "никад|никогда|Научи ову реч: „никад“.|Общение и время",
    "често|часто|Научи ову реч: „често“.|Общение и время",
    "понекад|иногда|Научи ову реч: „понекад“.|Общение и время",
    "одмах|сразу|Научи ову реч: „одмах“.|Общение и время",
    "касније|позже|Назови ме касније.|Время",
    "раније|раньше|Научи ову реч: „раније“.|Общение и время",
    "већ|уже|Научи ову реч: „већ“.|Общение и время",
    "још|ещё|Научи ову реч: „још“.|Общение и время",
    "опет|снова|Научи ову реч: „опет“.|Общение и время",
    "увече|вечером|Научи ову реч: „увече“.|Общение и время",
    "ујутру|утром|Научи ову реч: „ујутру“.|Общение и время",
    "ноћу|ночью|Научи ову реч: „ноћу“.|Общение и время",
    "добро|хорошо|Све је добро.|Общение",
    "лоше|плохо|Данас се осећам лоше.|Общение",
    "брзо|быстро|Научи ову реч: „брзо“.|Общение и время",
    "полако|медленно|Научи ову реч: „полако“.|Общение и время",
    "лако|легко|Научи ову реч: „лако“.|Общение и время",
    "тешко|трудно|Научи ову реч: „тешко“.|Общение и время",
    "заједно|вместе|Научи ову реч: „заједно“.|Общение и время",
    "може|можно|Научи ову реч: „може“.|Общение и время",
    "морам|я должен|Научи ову реч: „морам“.|Общение и время",
    "треба|нужно|Научи ову реч: „треба“.|Общение и время",
    "здраво|привет|Здраво, како си?|Общение",
    "ћао|пока|Научи ову реч: „ћао“.|Общение и время",
    "добар дан|добрый день|Добар дан, госпођо.|Общение",
    "добро јутро|доброе утро|Добро јутро свима.|Общение",
    "добро вече|добрый вечер|Добро вече!|Общение",
    "лаку ноћ|спокойной ночи|Лаку ноћ и лепо спавај.|Общение",
    "довидјења|до свидания|Довиђења! Видимо се сутра.|Общение и время",
    "молим|пожалуйста;прошу|Молим, поновите.|Общение",
    "хвала|спасибо|Хвала на помоћи.|Общение",
    "хвала лепо|большое спасибо|Научи ову реч: „хвала лепо“.|Общение и время",
    "извини|извини|Извини, касним.|Общение",
    "извините|извините|Извините, где је станица?|Общение",
    "опрости|прости|Научи ову реч: „опрости“.|Общение и время",
    "нема на чему|не за что|Научи ову реч: „нема на чему“.|Общение и время",
    "добро дошли|добро пожаловать|Научи ову реч: „добро дошли“.|Глаголы",
    "срећно|удачи|Научи ову реч: „срећно“.|Глаголы",
    "живели|будьте здоровы|Научи ову реч: „живели“.|Глаголы",
    "наравно|конечно|Научи ову реч: „наравно“.|Глаголы",
    "слажем се|я согласен|Научи ову реч: „слажем се“.|Глаголы",
    "не разумем|я не понимаю|Извините, не разумем.|Глаголы",
    "разумем|я понимаю|Сада разумем.|Глаголы",
    "говорим|я говорю|Говорим српски.|Глаголы",
    "зовем се|меня зовут|Зовем се Владимир.|Глаголы",
    "ја сам|я есть|Ја сам учитељ.|Глаголы",
    "драго ми је|приятно познакомиться|Научи ову реч: „драго ми је“.|Глаголы",
    "помоћ|помощь|Треба ми помоћ.|Здоровье",
    "помозите|помогите|Помозите ми, молим вас!|Глаголы",
    "пажња|внимание|Научи ову реч: „пажња“.|Глаголы",
    "опростите|простите|Научи ову реч: „опростите“.|Глаголы",
    "говорити|говорить|Говорим мало српски.|Глаголы",
    "бити|быть|Желим да будем овде.|Глаголы",
    "имати|иметь|Имам времена.|Глаголы",
    "радити|работать;делать|Радим данас.|Глаголы",
    "живети|жить|Живим у граду.|Глаголы",
    "ићи|идти|Идем кући.|Глаголы",
    "доћи|приходить|Долазим сутра.|Глаголы",
    "отићи|уходить|Научи ову реч: „отићи“.|Глаголы",
    "видети|видеть|Видим кућу.|Глаголы",
    "гледати|смотреть|Научи ову реч: „гледати“.|Глаголы",
    "чути|слышать|Чујем музику.|Глаголы",
    "слушати|слушать|Научи ову реч: „слушати“.|Глаголы",
    "знати|знать|Знам одговор.|Глаголы",
    "мислити|думать|Научи ову реч: „мислити“.|Глаголы",
    "разумети|понимать|Разумем питање.|Глаголы",
    "учити|учить;учиться|Учим српски.|Глаголы",
    "учити се|учиться|Научи ову реч: „учити се“.|Глаголы",
    "читати|читать|Читам књигу.|Глаголы",
    "писати|писать|Пишем поруку.|Глаголы",
    "питати|спрашивать|Могу нешто да питам?|Глаголы",
    "одговорити|ответить|Молим те, одговори.|Глаголы",
    "желети|хотеть|Желим воду.|Глаголы",
    "хтети|хотеть|Хоћу воду.|Глаголы",
    "моћи|мочь|Могу да помогнем.|Глаголы",
    "морати|быть должным|Научи ову реч: „морати“.|Глаголы",
    "требати|нуждаться|Научи ову реч: „требати“.|Глаголы",
    "волети|любить|Волим књиге.|Глаголы",
    "свиђати се|нравиться|Свиђа ми се ова књига.|Глаголы",
    "јести|есть|Једем хлеб.|Глаголы",
    "пити|пить|Пијем чај.|Глаголы",
    "кувати|готовить|Научи ову реч: „кувати“.|Глаголы",
    "купити|купить|Желим да купим воду.|Покупки",
    "плаћати|платить|Научи ову реч: „плаћати“.|Глаголы",
    "узети|взять|Научи ову реч: „узети“.|Глаголы",
    "дати|дать|Научи ову реч: „дати“.|Глаголы",
    "донети|принести|Научи ову реч: „донети“.|Глаголы",
    "наћи|найти|Научи ову реч: „наћи“.|Глаголы",
    "тражити|искать|Тражим станицу.|Глаголы",
    "чекати|ждать|Чекам аутобус.|Глаголы",
    "почети|начать|Научи ову реч: „почети“.|Глаголы",
    "завршити|закончить|Научи ову реч: „завршити“.|Глаголы",
    "отворити|открыть|Научи ову реч: „отворити“.|Глаголы",
    "затворити|закрыть|Научи ову реч: „затворити“.|Глаголы",
    "седети|сидеть|Научи ову реч: „седети“.|Глаголы",
    "стајати|стоять|Научи ову реч: „стајати“.|Глаголы",
    "спавати|спать|Желим да спавам.|Глаголы",
    "устати|встать|Научи ову реч: „устати“.|Глаголы",
    "лећи|лечь|Научи ову реч: „лећи“.|Глаголы",
    "ходати|ходить|Научи ову реч: „ходати“.|Глаголы",
    "трчати|бегать|Научи ову реч: „трчати“.|Глаголы",
    "путовати|путешествовать|Научи ову реч: „путовати“.|Глаголы",
    "возити|водить|Научи ову реч: „возити“.|Глаголы",
    "возити се|ехать|Научи ову реч: „возити се“.|Глаголы",
    "помоћи|помочь|Можете ли да ми помогнете?|Глаголы",
    "звати|звать|Научи ову реч: „звати“.|Глаголы",
    "позвати|позвать|Научи ову реч: „позвати“.|Глаголы",
    "сретати|встречать|Научи ову реч: „сретати“.|Глаголы",
    "упознати|познакомиться|Научи ову реч: „упознати“.|Глаголы",
    "памтити|помнить|Научи ову реч: „памтити“.|Глаголы",
    "заборавити|забыть|Научи ову реч: „заборавити“.|Глаголы",
    "осећати|чувствовать|Научи ову реч: „осећати“.|Люди и профессии",
    "играти|играть|Научи ову реч: „играти“.|Люди и профессии",
    "певати|петь|Научи ову реч: „певати“.|Люди и профессии",
    "плесати|танцевать|Научи ову реч: „плесати“.|Люди и профессии",
    "смејати се|смеяться|Научи ову реч: „смејати се“.|Люди и профессии",
    "плакати|плакать|Научи ову реч: „плакати“.|Люди и профессии",
    "чистити|убирать|Научи ову реч: „чистити“.|Люди и профессии",
    "прати|мыть|Научи ову реч: „прати“.|Люди и профессии",
    "купати се|купаться|Научи ову реч: „купати се“.|Люди и профессии",
    "носити|носить|Научи ову реч: „носити“.|Люди и профессии",
    "обући|одеть|Научи ову реч: „обући“.|Люди и профессии",
    "облачити се|одеваться|Научи ову реч: „облачити се“.|Люди и профессии",
    "покушати|попробовать|Научи ову реч: „покушати“.|Люди и профессии",
    "користити|использовать|Научи ову реч: „користити“.|Люди и профессии",
    "потребан|нужный|Научи ову реч: „потребан“.|Люди и профессии",
    "човек|человек|Ово је добар човек.|Люди",
    "људи|люди|Научи ову реч: „људи“.|Люди и профессии",
    "жена|женщина;жена|Моја жена је лекар.|Люди",
    "мушкарац|мужчина|Онај мушкарац је мој брат.|Люди",
    "дете|ребёнок|Дете се игра.|Люди",
    "дечак|мальчик|Научи ову реч: „дечак“.|Люди и профессии",
    "девојчица|девочка|Научи ову реч: „девојчица“.|Люди и профессии",
    "породица|семья|Моја породица је велика.|Люди",
    "мајка|мать|Моја мајка је код куће.|Люди",
    "отац|отец|Мој отац ради.|Люди",
    "родитељи|родители|Научи ову реч: „родитељи“.|Люди и профессии",
    "син|сын|Научи ову реч: „син“.|Люди и профессии",
    "ћерка|дочь|Научи ову реч: „ћерка“.|Люди и профессии",
    "брат|брат|Имам једног брата.|Люди",
    "сестра|сестра|Моја сестра учи.|Люди",
    "муж|муж|Научи ову реч: „муж“.|Люди и профессии",
    "партнер|партнёр|Научи ову реч: „партнер“.|Люди и профессии",
    "пријатељ|друг|Он је мој пријатељ.|Люди",
    "пријатељица|подруга|Научи ову реч: „пријатељица“.|Люди и профессии",
    "комшија|сосед|Научи ову реч: „комшија“.|Люди и профессии",
    "име|имя|Како ти је име?|Люди",
    "презиме|фамилия|Научи ову реч: „презиме“.|Люди и профессии",
    "године|годы;возраст|Научи ову реч: „године“.|Люди и профессии",
    "посао|работа|Имам много посла.|Работа",
    "колега|коллега|Научи ову реч: „колега“.|Люди и профессии",
    "ученик|ученик|Ученик чита књигу.|Учёба",
    "учитељ|учитель|Он је мој учитељ.|Учёба",
    "наставник|преподаватель|Научи ову реч: „наставник“.|Люди и профессии",
    "школа|школа|Школа је отворена.|Город",
    "студент|студент|Научи ову реч: „студент“.|Люди и профессии",
    "студенткиња|студентка|Научи ову реч: „студенткиња“.|Люди и профессии",
    "лекар|врач|Лекар ради данас.|Здоровье",
    "медицинска сестра|медсестра|Научи ову реч: „медицинска сестра“.|Люди и профессии",
    "полицајац|полицейский|Научи ову реч: „полицајац“.|Люди и профессии",
    "возач|водитель|Научи ову реч: „возач“.|Люди и профессии",
    "продавац|продавец|Научи ову реч: „продавац“.|Дом и город",
    "кувар|повар|Научи ову реч: „кувар“.|Дом и город",
    "град|город|Београд је велики град.|Город",
    "село|деревня|Моја бака живи на селу.|Город",
    "држава|государство|Научи ову реч: „држава“.|Дом и город",
    "земља|страна;земля|Научи ову реч: „земља“.|Дом и город",
    "свет|мир|Научи ову реч: „свет“.|Дом и город",
    "место|место|Научи ову реч: „место“.|Дом и город",
    "кућа|дом;дом/здание|Моја кућа је мала.|Дом",
    "стан|квартира|Живим у малом стану.|Дом",
    "соба|комната|Моја соба је светла.|Дом",
    "кухиња|кухня|Кухиња је чиста.|Дом",
    "купатило|ванная|Купатило је тамо.|Дом",
    "тоалет|туалет|Научи ову реч: „тоалет“.|Дом и город",
    "ходник|коридор|Научи ову реч: „ходник“.|Дом и город",
    "врата|дверь|Затвори врата, молим те.|Дом",
    "прозор|окно|Отвори прозор.|Дом",
    "зид|стена|Научи ову реч: „зид“.|Дом и город",
    "под|пол|Научи ову реч: „под“.|Дом и город",
    "плафон|потолок|Научи ову реч: „плафон“.|Дом и город",
    "кров|крыша|Научи ову реч: „кров“.|Дом и город",
    "стол|стол|Научи ову реч: „стол“.|Дом и город",
    "столица|стул|Седи на столицу.|Дом",
    "кревет|кровать|Кревет је удобан.|Дом",
    "орман|шкаф|Научи ову реч: „орман“.|Дом и город",
    "полице|полки|Научи ову реч: „полице“.|Дом и город",
    "лампа|лампа|Научи ову реч: „лампа“.|Дом и город",
    "светло|свет|Научи ову реч: „светло“.|Дом и город",
    "кључ|ключ|Где су ми кључеви?|Дом",
    "телефон|телефон|Мој телефон је нов.|Дом",
    "рачунар|компьютер|Научи ову реч: „рачунар“.|Дом и город",
    "лаптоп|ноутбук|Научи ову реч: „лаптоп“.|Дом и город",
    "интернет|интернет|Научи ову реч: „интернет“.|Дом и город",
    "порука|сообщение|Научи ову реч: „порука“.|Дом и город",
    "пошта|почта|Научи ову реч: „пошта“.|Дом и город",
    "књига|книга|Читам занимљиву књигу.|Дом",
    "свеска|тетрадь|Научи ову реч: „свеска“.|Дом и город",
    "оловка|карандаш|Научи ову реч: „оловка“.|Дом и город",
    "хемијска оловка|ручка|Научи ову реч: „хемијска оловка“.|Дом и город",
    "папир|бумага|Научи ову реч: „папир“.|Дом и город",
    "торба|сумка|Научи ову реч: „торба“.|Дом и город",
    "новац|деньги|Немам довољно новца.|Покупки",
    "картица|карта|Научи ову реч: „картица“.|Дом и город",
    "документ|документ|Научи ову реч: „документ“.|Дом и город",
    "пасош|паспорт|Научи ову реч: „пасош“.|Дом и город",
    "адреса|адрес|Научи ову реч: „адреса“.|Дом и город",
    "улица|улица|Ова улица је дуга.|Город",
    "пут|дорога;путь|Ово је дуг пут.|Город",
    "мост|мост|Научи ову реч: „мост“.|Дом и город",
    "продавница|магазин|Продавница је близу.|Город",
    "супермаркет|супермаркет|Научи ову реч: „супермаркет“.|Транспорт и путешествия",
    "пијаца|рынок|Идем на пијацу.|Город",
    "пекара|пекарня|Научи ову реч: „пекара“.|Транспорт и путешествия",
    "апотека|аптека|Где је најближа апотека?|Город",
    "банка|банк|Научи ову реч: „банка“.|Транспорт и путешествия",
    "болница|больница|Болница је далеко.|Город",
    "дом здравља|поликлиника|Научи ову реч: „дом здравља“.|Транспорт и путешествия",
    "факултет|факультет|Научи ову реч: „факултет“.|Транспорт и путешествия",
    "библиотека|библиотека|Научи ову реч: „библиотека“.|Транспорт и путешествия",
    "музеј|музей|Научи ову реч: „музеј“.|Транспорт и путешествия",
    "парк|парк|Научи ову реч: „парк“.|Транспорт и путешествия",
    "ресторан|ресторан|Научи ову реч: „ресторан“.|Транспорт и путешествия",
    "кафић|кафе|Научи ову реч: „кафић“.|Транспорт и путешествия",
    "хотел|отель|Научи ову реч: „хотел“.|Транспорт и путешествия",
    "станица|станция;остановка|Аутобуска станица је овде.|Город",
    "аутобуска станица|автовокзал|Научи ову реч: „аутобуска станица“.|Транспорт и путешествия",
    "железничка станица|железнодорожный вокзал|Научи ову реч: „железничка станица“.|Транспорт и путешествия",
    "аеродром|аэропорт|Научи ову реч: „аеродром“.|Транспорт и путешествия",
    "такси|такси|Позовите ми такси.|Город",
    "аутобус|автобус|Аутобус стиже за пет минута.|Город",
    "воз|поезд|Воз полази у девет.|Город",
    "аутомобил|автомобиль|Научи ову реч: „аутомобил“.|Транспорт и путешествия",
    "бицикл|велосипед|Научи ову реч: „бицикл“.|Транспорт и путешествия",
    "мотор|мотоцикл|Научи ову реч: „мотор“.|Транспорт и путешествия",
    "авион|самолёт|Научи ову реч: „авион“.|Транспорт и путешествия",
    "брод|корабль|Научи ову реч: „брод“.|Транспорт и путешествия",
    "карта|карта;билет|Треба ми карта за воз.|Город",
    "улаз|вход|Научи ову реч: „улаз“.|Транспорт и путешествия",
    "излаз|выход|Научи ову реч: „излаз“.|Транспорт и путешествия",
    "лево|налево|Скрените лево.|Направления",
    "десно|направо|Скрените десно.|Направления",
    "право|прямо|Идите право.|Направления",
    "близу|близко|Станица је близу.|Направления",
    "далеко|далеко|Море није далеко.|Направления",
    "горе|вверх|Научи ову реч: „горе“.|Транспорт и путешествия",
    "доле|вниз|Научи ову реч: „доле“.|Транспорт и путешествия",
    "унутра|внутри|Уђи унутра.|Направления",
    "напољу|снаружи;на улице|Напољу је хладно.|Направления",
    "испред|перед|Научи ову реч: „испред“.|Транспорт и путешествия",
    "иза|за|Научи ову реч: „иза“.|Транспорт и путешествия",
    "поред|рядом|Научи ову реч: „поред“.|Транспорт и путешествия",
    "између|между|Научи ову реч: „између“.|Транспорт и путешествия",
    "преко|через|Научи ову реч: „преко“.|Транспорт и путешествия",
    "кроз|сквозь|Научи ову реч: „кроз“.|Транспорт и путешествия",
    "до|до|Научи ову реч: „до“.|Транспорт и путешествия",
    "од|от|Научи ову реч: „од“.|Транспорт и путешествия",
    "из|из|Научи ову реч: „из“.|Транспорт и путешествия",
    "у|в;на|Научи ову реч: „у“.|Транспорт и путешествия",
    "на|на|Научи ову реч: „на“.|Транспорт и путешествия",
    "са|с|Научи ову реч: „са“.|Транспорт и путешествия",
    "без|без|Научи ову реч: „без“.|Еда и напитки",
    "за|для;за|Научи ову реч: „за“.|Еда и напитки",
    "код|у;около|Научи ову реч: „код“.|Еда и напитки",
    "по|по|Научи ову реч: „по“.|Еда и напитки",
    "о|о|Научи ову реч: „о“.|Еда и напитки",
    "при|при|Научи ову реч: „при“.|Еда и напитки",
    "храна|еда|Храна је у кухињи.|Еда",
    "вода|вода|Молим чашу воде.|Еда",
    "хлеб|хлеб|Купујем свеж хлеб.|Еда",
    "млеко|молоко|Пијем млеко.|Еда",
    "сир|сыр|Хлеб и сир су на столу.|Еда",
    "јаје|яйцо|Научи ову реч: „јаје“.|Еда и напитки",
    "месо|мясо|Не једем месо.|Еда",
    "пилетина|курица|Пилетина је готова.|Еда",
    "риба|рыба|Риба је свежа.|Еда",
    "свињетина|свинина|Научи ову реч: „свињетина“.|Еда и напитки",
    "говедина|говядина|Научи ову реч: „говедина“.|Еда и напитки",
    "супа|суп|Супа је топла.|Еда",
    "салата|салат|Научи ову реч: „салата“.|Еда и напитки",
    "пиринач|рис|Научи ову реч: „пиринач“.|Еда и напитки",
    "кромпир|картофель|Научи ову реч: „кромпир“.|Еда и напитки",
    "парадајз|помидор|Научи ову реч: „парадајз“.|Еда и напитки",
    "краставац|огурец|Научи ову реч: „краставац“.|Еда и напитки",
    "лук|лук|Научи ову реч: „лук“.|Еда и напитки",
    "шаргарепа|морковь|Научи ову реч: „шаргарепа“.|Еда и напитки",
    "јабука|яблоко|Желим једну јабуку.|Еда",
    "крушка|груша|Научи ову реч: „крушка“.|Еда и напитки",
    "банана|банан|Научи ову реч: „банана“.|Еда и напитки",
    "поморанџа|апельсин|Научи ову реч: „поморанџа“.|Еда и напитки",
    "лимун|лимон|Научи ову реч: „лимун“.|Еда и напитки",
    "грожђе|виноград|Научи ову реч: „грожђе“.|Еда и напитки",
    "јагода|клубника|Научи ову реч: „јагода“.|Еда и напитки",
    "воће|фрукты|Научи ову реч: „воће“.|Еда и напитки",
    "поврће|овощи|Научи ову реч: „поврће“.|Еда и напитки",
    "шећер|сахар|Без шећера, молим.|Еда",
    "со|соль|Додај мало соли.|Еда",
    "бибер|перец|Научи ову реч: „бибер“.|Еда и напитки",
    "уље|масло|Научи ову реч: „уље“.|Еда и напитки",
    "путер|сливочное масло|Научи ову реч: „путер“.|Еда и напитки",
    "брашно|мука|Научи ову реч: „брашно“.|Еда и напитки",
    "колач|пирог;торт|Научи ову реч: „колач“.|Еда и напитки",
    "чоколада|шоколад|Научи ову реч: „чоколада“.|Еда и напитки",
    "сладолед|мороженое|Научи ову реч: „сладолед“.|Еда и напитки",
    "доручак|завтрак|Доручак је у осам.|Еда",
    "ручак|обед|Ручак је спреман.|Еда",
    "вечера|ужин;ужин/вечеря|Вечерамо код куће.|Еда",
    "ужина|перекус|Научи ову реч: „ужина“.|Еда и напитки",
    "кафа|кофе|Једну кафу, молим.|Еда",
    "чај|чай|Волим црни чај.|Еда",
    "сок|сок|Научи ову реч: „сок“.|Еда и напитки",
    "пиво|пиво|Научи ову реч: „пиво“.|Календарь и время",
    "вино|вино|Научи ову реч: „вино“.|Календарь и время",
    "мени|меню|Научи ову реч: „мени“.|Календарь и время",
    "рачун|счёт; чек|Рачун, молим.|Покупки",
    "чаша|стакан|Научи ову реч: „чаша“.|Календарь и время",
    "шоља|чашка|Научи ову реч: „шоља“.|Календарь и время",
    "тањир|тарелка|Научи ову реч: „тањир“.|Календарь и время",
    "виљушка|вилка|Научи ову реч: „виљушка“.|Календарь и время",
    "нож|нож|Научи ову реч: „нож“.|Календарь и время",
    "кашика|ложка|Научи ову реч: „кашика“.|Календарь и время",
    "доручковати|завтракать|Научи ову реч: „доручковати“.|Календарь и время",
    "гладан|голодный|Гладан сам.|Чувства",
    "жедан|испытывающий жажду|Жедан сам, желим воду.|Чувства",
    "укусан|вкусный|Научи ову реч: „укусан“.|Календарь и время",
    "свеж|свежий|Научи ову реч: „свеж“.|Календарь и время",
    "љут|острый|Научи ову реч: „љут“.|Календарь и время",
    "сладак|сладкий|Научи ову реч: „сладак“.|Календарь и время",
    "кисео|кислый|Научи ову реч: „кисео“.|Календарь и время",
    "слано|солёный|Научи ову реч: „слано“.|Календарь и время",
    "дан|день|Данас је леп дан.|Время",
    "ноћ|ночь|Ноћ је тиха.|Время",
    "јутро|утро|Ујутру пијем чај.|Время",
    "вече|вечер|Видимо се вечерас.|Время",
    "недеља|неделя|Остајем овде недељу дана.|Время",
    "понедељак|понедельник|Научи ову реч: „понедељак“.|Календарь и время",
    "уторак|вторник|Научи ову реч: „уторак“.|Календарь и время",
    "среда|среда|Научи ову реч: „среда“.|Календарь и время",
    "четвртак|четверг|Научи ову реч: „четвртак“.|Календарь и время",
    "петак|пятница|Научи ову реч: „петак“.|Календарь и время",
    "субота|суббота|Научи ову реч: „субота“.|Календарь и время",
    "викенд|выходные|Научи ову реч: „викенд“.|Календарь и время",
    "месец|месяц|Следећег месеца путујем.|Время",
    "година|год|Имам двадесет три године.|Время",
    "сат|час;часы|Колико је сати?|Время",
    "минут|минута|Чекај један минут.|Время",
    "секунда|секунда|Научи ову реч: „секунда“.|Календарь и время",
    "датум|дата|Научи ову реч: „датум“.|Календарь и время",
    "време|время;погода|Немам времена.|Основы",
    "рано|рано|Научи ову реч: „рано“.|Календарь и время",
    "касно|поздно|Научи ову реч: „касно“.|Календарь и время",
    "пролеће|весна|Научи ову реч: „пролеће“.|Календарь и время",
    "лето|лето|Научи ову реч: „лето“.|Календарь и время",
    "јесен|осень|Научи ову реч: „јесен“.|Календарь и время",
    "зима|зима|Научи ову реч: „зима“.|Календарь и время",
    "јануар|январь|Научи ову реч: „јануар“.|Календарь и время",
    "фебруар|февраль|Научи ову реч: „фебруар“.|Календарь и время",
    "март|март|Научи ову реч: „март“.|Календарь и время",
    "април|апрель|Научи ову реч: „април“.|Календарь и время",
    "мај|май|Научи ову реч: „мај“.|Календарь и время",
    "јун|июнь|Научи ову реч: „јун“.|Календарь и время",
    "јул|июль|Научи ову реч: „јул“.|Числа и прилагательные",
    "август|август|Научи ову реч: „август“.|Числа и прилагательные",
    "септембар|сентябрь|Научи ову реч: „септембар“.|Числа и прилагательные",
    "октобар|октябрь|Научи ову реч: „октобар“.|Числа и прилагательные",
    "новембар|ноябрь|Научи ову реч: „новембар“.|Числа и прилагательные",
    "децембар|декабрь|Научи ову реч: „децембар“.|Числа и прилагательные",
    "један|один|Имам један пасош.|Числа",
    "два|два|Имам два брата.|Числа",
    "три|три|Три кафе, молим.|Числа",
    "четири|четыре|Четири карте, молим.|Числа",
    "пет|пять|Чекам пет минута.|Числа",
    "шест|шесть|Научи ову реч: „шест“.|Числа и прилагательные",
    "седам|семь|Научи ову реч: „седам“.|Числа и прилагательные",
    "осам|восемь|Научи ову реч: „осам“.|Числа и прилагательные",
    "девет|девять|Научи ову реч: „девет“.|Числа и прилагательные",
    "десет|десять|Имам десет књига.|Числа",
    "једанаест|одиннадцать|Научи ову реч: „једанаест“.|Числа и прилагательные",
    "дванаест|двенадцать|Научи ову реч: „дванаест“.|Числа и прилагательные",
    "тринаест|тринадцать|Научи ову реч: „тринаест“.|Числа и прилагательные",
    "четрнаест|четырнадцать|Научи ову реч: „четрнаест“.|Числа и прилагательные",
    "петнаест|пятнадцать|Научи ову реч: „петнаест“.|Числа и прилагательные",
    "шеснаест|шестнадцать|Научи ову реч: „шеснаест“.|Числа и прилагательные",
    "седамнаест|семнадцать|Научи ову реч: „седамнаест“.|Числа и прилагательные",
    "осамнаест|восемнадцать|Научи ову реч: „осамнаест“.|Числа и прилагательные",
    "деветнаест|девятнадцать|Научи ову реч: „деветнаест“.|Числа и прилагательные",
    "двадесет|двадцать|Научи ову реч: „двадесет“.|Числа и прилагательные",
    "тридесет|тридцать|Научи ову реч: „тридесет“.|Числа и прилагательные",
    "четрдесет|сорок|Научи ову реч: „четрдесет“.|Числа и прилагательные",
    "педесет|пятьдесят|Научи ову реч: „педесет“.|Числа и прилагательные",
    "шездесет|шестьдесят|Научи ову реч: „шездесет“.|Числа и прилагательные",
    "седамдесет|семьдесят|Научи ову реч: „седамдесет“.|Числа и прилагательные",
    "осамдесет|восемьдесят|Научи ову реч: „осамдесет“.|Числа и прилагательные",
    "деведесет|девяносто|Научи ову реч: „деведесет“.|Числа и прилагательные",
    "сто|стол|Књига је на столу.|Дом",
    "хиљаду|тысяча|Научи ову реч: „хиљаду“.|Числа и прилагательные",
    "први|первый|Ово је мој први дан.|Числа",
    "трећи|третий|Научи ову реч: „трећи“.|Числа и прилагательные",
    "последњи|последний|Ово је последњи аутобус.|Числа",
    "пола|половина|Научи ову реч: „пола“.|Числа и прилагательные",
    "више|больше|Научи ову реч: „више“.|Числа и прилагательные",
    "мање|меньше|Научи ову реч: „мање“.|Числа и прилагательные",
    "довољно|достаточно|Научи ову реч: „довољно“.|Числа и прилагательные",
    "велики|большой|Ово је велики град.|Прилагательные",
    "мали|маленький|Имам малу мачку.|Прилагательные",
    "дугачак|длинный|Научи ову реч: „дугачак“.|Числа и прилагательные",
    "кратак|короткий|Научи ову реч: „кратак“.|Числа и прилагательные",
    "висок|высокий|Научи ову реч: „висок“.|Числа и прилагательные",
    "низак|низкий|Научи ову реч: „низак“.|Числа и прилагательные",
    "широк|широкий|Научи ову реч: „широк“.|Числа и прилагательные",
    "узак|узкий|Научи ову реч: „узак“.|Числа и прилагательные",
    "нов|новый|Имам нов телефон.|Прилагательные",
    "стар|старый|Ово је стара кућа.|Прилагательные",
    "млад|молодой|Она је млада.|Прилагательные",
    "добар|хороший|Он је добар учитељ.|Прилагательные",
    "лош|плохой|Научи ову реч: „лош“.|Прилагательные и чувства",
    "леп|красивый|Ово је леп дан.|Прилагательные",
    "ружан|некрасивый|Научи ову реч: „ружан“.|Прилагательные и чувства",
    "важан|важный|Научи ову реч: „важан“.|Прилагательные и чувства",
    "занимљив|интересный|Научи ову реч: „занимљив“.|Прилагательные и чувства",
    "досадан|скучный|Научи ову реч: „досадан“.|Прилагательные и чувства",
    "лак|лёгкий|Ово је лако питање.|Прилагательные",
    "тежак|тяжёлый;трудный|Ово је тежак посао.|Прилагательные",
    "топао|тёплый|Чај је топао.|Прилагательные",
    "хладан|холодный|Вода је хладна.|Прилагательные",
    "врућ|горячий|Научи ову реч: „врућ“.|Прилагательные и чувства",
    "чист|чистый|Научи ову реч: „чист“.|Прилагательные и чувства",
    "прљав|грязный|Научи ову реч: „прљав“.|Прилагательные и чувства",
    "пун|полный|Научи ову реч: „пун“.|Прилагательные и чувства",
    "празан|пустой|Научи ову реч: „празан“.|Прилагательные и чувства",
    "отворен|открытый|Научи ову реч: „отворен“.|Прилагательные и чувства",
    "затворен|закрытый|Научи ову реч: „затворен“.|Прилагательные и чувства",
    "скуп|дорогой|Овај стан је скуп.|Прилагательные",
    "јефтин|дешёвый|Ова књига је јефтина.|Прилагательные",
    "бесплатан|бесплатный|Научи ову реч: „бесплатан“.|Прилагательные и чувства",
    "срећан|счастливый|Данас сам срећан.|Чувства",
    "тужан|грустный|Научи ову реч: „тужан“.|Прилагательные и чувства",
    "уморан|уставший|Веома сам уморан.|Чувства",
    "болестан|больной|Данас сам болестан.|Здоровье",
    "здрав|здоровый|Научи ову реч: „здрав“.|Прилагательные и чувства",
    "миран|спокойный|Научи ову реч: „миран“.|Прилагательные и чувства",
    "заузет|занятый|Научи ову реч: „заузет“.|Прилагательные и чувства",
    "слободан|свободный|Научи ову реч: „слободан“.|Прилагательные и чувства",
    "спреман|готовый|Научи ову реч: „спреман“.|Прилагательные и чувства",
    "сигуран|безопасный;уверенный|Научи ову реч: „сигуран“.|Прилагательные и чувства",
    "лепо|красиво;хорошо|Научи ову реч: „лепо“.|Прилагательные и чувства",
    "црвен|красный|Научи ову реч: „црвен“.|Прилагательные и чувства",
    "плав|синий|Научи ову реч: „плав“.|Прилагательные и чувства",
    "зелен|зелёный|Научи ову реч: „зелен“.|Прилагательные и чувства",
    "жут|жёлтый|Научи ову реч: „жут“.|Прилагательные и чувства",
    "црн|чёрный|Научи ову реч: „црн“.|Прилагательные и чувства",
    "бео|белый|Научи ову реч: „бео“.|Прилагательные и чувства",
    "сив|серый|Научи ову реч: „сив“.|Прилагательные и чувства",
    "браон|коричневый|Научи ову реч: „браон“.|Прилагательные и чувства",
    "розе|розовый|Научи ову реч: „розе“.|Прилагательные и чувства",
    "боја|цвет|Научи ову реч: „боја“.|Прилагательные и чувства",
    "сунце|солнце|Сунце сија.|Природа",
    "киша|дождь|Данас пада киша.|Природа",
    "снег|снег|Снег је бео.|Природа",
    "ветар|ветер|Дува јак ветар.|Природа",
    "облак|облако|Научи ову реч: „облак“.|Прилагательные и чувства",
    "небо|небо|Научи ову реч: „небо“.|Тело и одежда",
    "море|море|Лети идем на море.|Природа",
    "река|река|Научи ову реч: „река“.|Тело и одежда",
    "планина|гора|Планина је висока.|Природа",
    "дрво|дерево|Ово дрво је високо.|Природа",
    "цвет|цветок|Овај цвет је леп.|Природа",
    "трава|трава|Научи ову реч: „трава“.|Тело и одежда",
    "животиња|животное|Научи ову реч: „животиња“.|Тело и одежда",
    "пас|собака|Мој пас је мали.|Животные",
    "мачка|кошка|Мачка спава на кревету.|Животные",
    "птица|птица|Птица лети.|Животные",
    "коњ|лошадь|Коњ трчи.|Животные",
    "крава|корова|Научи ову реч: „крава“.|Тело и одежда",
    "овца|овца|Научи ову реч: „овца“.|Тело и одежда",
    "глава|голова|Научи ову реч: „глава“.|Тело и одежда",
    "лице|лицо|Научи ову реч: „лице“.|Тело и одежда",
    "око|глаз|Научи ову реч: „око“.|Тело и одежда",
    "ухо|ухо|Научи ову реч: „ухо“.|Тело и одежда",
    "нос|нос|Научи ову реч: „нос“.|Тело и одежда",
    "уста|рот|Научи ову реч: „уста“.|Тело и одежда",
    "зуб|зуб|Научи ову реч: „зуб“.|Тело и одежда",
    "коса|волосы|Научи ову реч: „коса“.|Тело и одежда",
    "рука|рука|Научи ову реч: „рука“.|Тело и одежда",
    "прст|палец|Научи ову реч: „прст“.|Тело и одежда",
    "нога|нога|Научи ову реч: „нога“.|Тело и одежда",
    "стопало|ступня|Научи ову реч: „стопало“.|Тело и одежда",
    "леђа|спина|Научи ову реч: „леђа“.|Тело и одежда",
    "стомак|живот|Научи ову реч: „стомак“.|Тело и одежда",
    "срце|сердце|Научи ову реч: „срце“.|Тело и одежда",
    "крв|кровь|Научи ову реч: „крв“.|Тело и одежда",
    "тело|тело|Научи ову реч: „тело“.|Тело и одежда",
    "здравље|здоровье|Здравље је важно.|Здоровье",
    "бол|боль|Имам бол у леђима.|Здоровье",
    "лек|лекарство|Научи ову реч: „лек“.|Тело и одежда",
    "температура|температура|Научи ову реч: „температура“.|Тело и одежда",
    "болети|болеть|Научи ову реч: „болети“.|Тело и одежда",
    "главобоља|головная боль|Научи ову реч: „главобоља“.|Тело и одежда",
    "прехлада|простуда|Научи ову реч: „прехлада“.|Тело и одежда",
    "апетит|аппетит|Научи ову реч: „апетит“.|Тело и одежда",
    "одећа|одежда|Научи ову реч: „одећа“.|Тело и одежда",
    "мајица|футболка|Научи ову реч: „мајица“.|Тело и одежда",
    "кошуља|рубашка|Научи ову реч: „кошуља“.|Тело и одежда",
    "панталоне|брюки|Научи ову реч: „панталоне“.|Тело и одежда",
    "фармерке|джинсы|Научи ову реч: „фармерке“.|Тело и одежда",
    "хаљина|платье|Научи ову реч: „хаљина“.|Тело и одежда",
    "сукња|юбка|Научи ову реч: „сукња“.|Тело и одежда",
    "јакна|куртка|Научи ову реч: „јакна“.|Тело и одежда",
    "капут|пальто|Научи ову реч: „капут“.|Тело и одежда",
    "џемпер|свитер|Научи ову реч: „џемпер“.|Тело и одежда",
    "ципеле|туфли;обувь|Научи ову реч: „ципеле“.|Тело и одежда",
    "патике|кроссовки|Научи ову реч: „патике“.|Путешествия и язык",
    "чизме|сапоги|Научи ову реч: „чизме“.|Путешествия и язык",
    "чарапе|носки|Научи ову реч: „чарапе“.|Путешествия и язык",
    "доњи веш|нижнее бельё|Научи ову реч: „доњи веш“.|Путешествия и язык",
    "шешир|шляпа|Научи ову реч: „шешир“.|Путешествия и язык",
    "капа|шапка|Научи ову реч: „капа“.|Путешествия и язык",
    "рукавице|перчатки|Научи ову реч: „рукавице“.|Путешествия и язык",
    "кишобран|зонт|Научи ову реч: „кишобран“.|Путешествия и язык",
    "величина|размер|Научи ову реч: „величина“.|Путешествия и язык",
    "цена|цена|Која је цена?|Покупки",
    "колико кошта|сколько стоит|Колико кошта ово?|Путешествия и язык",
    "јефтино|дёшево|Научи ову реч: „јефтино“.|Путешествия и язык",
    "скупо|дорого|Научи ову реч: „скупо“.|Путешествия и язык",
    "попуст|скидка|Научи ову реч: „попуст“.|Путешествия и язык",
    "платити|платить|Могу ли да платим картицом?|Покупки",
    "продавати|продавать|Научи ову реч: „продавати“.|Путешествия и язык",
    "отворено|открыто|Да ли је продавница отворена?|Покупки",
    "затворено|закрыто|Музеј је затворен.|Покупки",
    "карта за превоз|проездной|Научи ову реч: „карта за превоз“.|Путешествия и язык",
    "повратна карта|обратный билет|Научи ову реч: „повратна карта“.|Путешествия и язык",
    "путовање|путешествие|Научи ову реч: „путовање“.|Путешествия и язык",
    "одмор|отдых;отпуск|Научи ову реч: „одмор“.|Путешествия и язык",
    "резервација|бронирование|Научи ову реч: „резервација“.|Путешествия и язык",
    "смештај|жильё|Научи ову реч: „смештај“.|Путешествия и язык",
    "граница|граница|Научи ову реч: „граница“.|Путешествия и язык",
    "царина|таможня|Научи ову реч: „царина“.|Путешествия и язык",
    "полиција|полиция|Научи ову реч: „полиција“.|Путешествия и язык",
    "ватрогасци|пожарные|Научи ову реч: „ватрогасци“.|Путешествия и язык",
    "хитна помоћ|скорая помощь|Научи ову реч: „хитна помоћ“.|Путешествия и язык",
    "опасност|опасность|Научи ову реч: „опасност“.|Путешествия и язык",
    "изгубљен|потерявшийся|Научи ову реч: „изгубљен“.|Путешествия и язык",
    "извините, где је...|извините, где находится...|Научи ову реч: „извините, где је...“.|Путешествия и язык",
    "колико је сати|который час|Извините, колико је сати?|Путешествия и язык",
    "лична карта|удостоверение личности|Научи ову реч: „лична карта“.|Путешествия и язык",
    "дозвола|разрешение|Научи ову реч: „дозвола“.|Путешествия и язык",
    "потпис|подпись|Научи ову реч: „потпис“.|Путешествия и язык",
    "образац|бланк|Научи ову реч: „образац“.|Путешествия и язык",
    "имејл|электронная почта|Научи ову реч: „имејл“.|Путешествия и язык",
    "разговор|разговор|Научи ову реч: „разговор“.|Путешествия и язык",
    "језик|язык|Српски језик је занимљив.|Учёба",
    "реч|слово;речь|Ово је нова реч.|Учёба",
    "реченица|предложение|Научи ову реч: „реченица“.|Путешествия и язык",
    "питање|вопрос|Имам једно питање.|Учёба",
    "одговор|ответ|Знам одговор.|Учёба",
    "значење|значение|Научи ову реч: „значење“.|Путешествия и язык",
    "изговор|произношение|Научи ову реч: „изговор“.|Путешествия и язык",
    "српски|сербский язык|Научи ову реч: „српски“.|Путешествия и язык",
    "руски|русский язык|Научи ову реч: „руски“.|Путешествия и язык",
    "енглески|английский язык|Научи ову реч: „енглески“.|Путешествия и язык",
    "страни језик|иностранный язык|Научи ову реч: „страни језик“.|Путешествия и язык",
    "говорим српски|я говорю по-сербски|Говорим мало српски.|Полезные фразы",
    "полако, молим|помедленнее, пожалуйста|Говорите полако, молим.|Полезные фразы",
    "можете ли да поновите|можете повторить|Можете ли да поновите?|Полезные фразы",
    "како се каже...|как сказать...|Како се каже ово на српском?|Полезные фразы",
    "шта значи...|что значит...|Шта значи ова реч?|Полезные фразы",
    "не знам|я не знаю|Не знам одговор.|Полезные фразы",
    "знам|я знаю|Знам где је.|Полезные фразы",
    "схватам|я понимаю|Научи ову реч: „схватам“.|Полезные фразы",
    "не могу|я не могу|Научи ову реч: „не могу“.|Полезные фразы",
    "немам|у меня нет|Немам времена.|Полезные фразы",
    "имам|у меня есть|Имам једно питање.|Полезные фразы",
    "желим|я хочу|Научи ову реч: „желим“.|Полезные фразы",
    "волео бих|я бы хотел (м.)|Научи ову реч: „волео бих“.|Полезные фразы",
    "волела бих|я бы хотела (ж.)|Научи ову реч: „волела бих“.|Полезные фразы",
    "свиђа ми се|мне нравится|Свиђа ми се Србија.|Полезные фразы",
    "не свиђа ми се|мне не нравится|Не свиђа ми се хладно време.|Полезные фразы",
    "не слажем се|я не согласен|Научи ову реч: „не слажем се“.|Полезные фразы",
    "мислим да|я думаю, что|Научи ову реч: „мислим да“.|Полезные фразы",
    "на пример|например|Научи ову реч: „на пример“.|Полезные фразы",
    "зато|поэтому|Научи ову реч: „зато“.|Полезные фразы",
    "зато што|потому что|Научи ову реч: „зато што“.|Полезные фразы",
    "иако|хотя|Научи ову реч: „иако“.|Полезные фразы",
    "као|как;в качестве|Научи ову реч: „као“.|Полезные фразы",
    "него|чем|Научи ову реч: „него“.|Полезные фразы",
    "доктор|доктор|Научи ову реч: „доктор“.|Полезные фразы",
    "господин|господин|Научи ову реч: „господин“.|Полезные фразы",
    "госпођа|госпожа|Научи ову реч: „госпођа“.|Полезные фразы",
    "госпођица|мисс|Научи ову реч: „госпођица“.|Полезные фразы",
    "молим вас|пожалуйста|Научи ову реч: „молим вас“.|Полезные фразы",
    "изволите|пожалуйста;вот|Изволите, ваша кафа.|Полезные фразы",
    "трг|площадь|Видимо се на тргу.|Город",
    "универзитет|университет|Студирам на универзитету.|Город",
    "брз|быстрый|Ово је брз воз.|Прилагательные",
    "спор|медленный|Интернет је спор.|Прилагательные",
    "пример|пример|Молим те, дај пример.|Учёба",
    "речник|словарь|Користим српски речник.|Учёба",
    "дневна соба|гостиная|Ово је дневна соба.|Дом и быт",
    "спаваћа соба|спальня|Ово је спаваћа соба.|Дом и быт",
    "трпезарија|столовая|Ово је трпезарија.|Дом и быт",
    "балкон|балкон|Ово је балкон.|Дом и быт",
    "тераса|терраса|Ово је тераса.|Дом и быт",
    "двориште|двор|Ово је двориште.|Дом и быт",
    "ограда|забор|Ово је ограда.|Дом и быт",
    "брава|замок|Ово је брава.|Дом и быт",
    "степенице|лестница|Ово су степенице.|Дом и быт",
    "завеса|занавеска|Ово је завеса.|Дом и быт",
    "тепих|ковёр|Ово је тепих.|Дом и быт",
    "јастук|подушка|Ово је јастук.|Дом и быт",
    "ћебе|одеяло|Ово је ћебе.|Дом и быт",
    "чаршав|простыня|Ово је чаршав.|Дом и быт",
    "душек|матрас|Ово је душек.|Дом и быт",
    "фиока|ящик|Ово је фиока.|Дом и быт",
    "полица|полка|Ово је полица.|Дом и быт",
    "огледало|зеркало|Ово је огледало.|Дом и быт",
    "сијалица|лампочка|Ово је сијалица.|Дом и быт",
    "утикач|вилка; штепсель|Ово је утикач.|Дом и быт",
    "утичница|розетка|Ово је утичница.|Дом и быт",
    "прекидач|выключатель|Ово је прекидач.|Дом и быт",
    "усисивач|пылесос|Ово је усисивач.|Дом и быт",
    "метла|метла|Ово је метла.|Дом и быт",
    "канта|ведро|Ово је канта.|Дом и быт",
    "крпа|тряпка|Ово је крпа.|Дом и быт",
    "сунђер|губка|Ово је сунђер.|Дом и быт",
    "сапун|мыло|Ово је сапун.|Дом и быт",
    "детерџент|моющее средство|Ово је детерџент.|Дом и быт",
    "пегла|утюг|Ово је пегла.|Дом и быт",
    "даљински управљач|пульт дистанционного управления|Ово је даљински управљач.|Дом и быт",
    "пуњач|зарядное устройство|Ово је пуњач.|Дом и быт",
    "батерија|батарейка; аккумулятор|Ово је батерија.|Дом и быт",
    "кабл|кабель|Ово је кабл.|Дом и быт",
    "уређај|устройство|Ово је уређај.|Дом и быт",
    "апарат|прибор; аппарат|Ово је апарат.|Дом и быт",
    "машина за прање веша|стиральная машина|Ово је машина за прање веша.|Дом и быт",
    "фрижидер|холодильник|Ово је фрижидер.|Дом и быт",
    "замрзивач|морозильник|Ово је замрзивач.|Дом и быт",
    "шпорет|плита|Ово је шпорет.|Дом и быт",
    "рерна|духовка|Ово је рерна.|Дом и быт",
    "микроталасна пећница|микроволновка|Ово је микроталасна пећница.|Дом и быт",
    "судопера|раковина|Ово је судопера.|Дом и быт",
    "славина|кран|Ово је славина.|Дом и быт",
    "цев|труба|Ово је цев.|Дом и быт",
    "канализација|канализация|Ово је канализација.|Дом и быт",
    "грејање|отопление|Ово је грејање.|Дом и быт",
    "клима-уређај|кондиционер|Ово је клима-уређај.|Дом и быт",
    "вентилација|вентиляция|Ово је вентилација.|Дом и быт",
    "рачун за струју|счёт за электричество|Ово је рачун за струју.|Дом и быт",
    "вода из чесме|вода из-под крана|Ово је вода из чесме.|Дом и быт",
    "рецепт|рецепт|Ово је рецепт.|Еда и кулинария",
    "састојак|ингредиент|Ово је састојак.|Еда и кулинария",
    "порција|порция|Ово је порција.|Еда и кулинария",
    "јеловник|меню|Ово је јеловник.|Еда и кулинария",
    "предјело|закуска|Ово је предјело.|Еда и кулинария",
    "главно јело|основное блюдо|Ово је главно јело.|Еда и кулинария",
    "прилог|гарнир|Ово је прилог.|Еда и кулинария",
    "десерт|десерт|Ово је десерт.|Еда и кулинария",
    "сос|соус|Ово је сос.|Еда и кулинария",
    "чорба|похлёбка; суп|Ово је чорба.|Еда и кулинария",
    "чорбица|супчик|Ово је чорбица.|Еда и кулинария",
    "чорбаст пасуљ|фасолевый суп|Ово је чорбаст пасуљ.|Еда и кулинария",
    "пире|пюре|Ово је пире.|Еда и кулинария",
    "тесто|тесто|Ово је тесто.|Еда и кулинария",
    "резанци|лапша|Ово су резанци.|Еда и кулинария",
    "макароне|макароны|Ово је макароне.|Еда и кулинария",
    "пасуљ|фасоль|Ово је пасуљ.|Еда и кулинария",
    "грашак|горох|Ово је грашак.|Еда и кулинария",
    "кукуруз|кукуруза|Ово је кукуруз.|Еда и кулинария",
    "пшеница|пшеница|Ово је пшеница.|Еда и кулинария",
    "шећер у праху|сахарная пудра|Ово је шећер у праху.|Еда и кулинария",
    "зачин|специя|Ово је зачин.|Еда и кулинария",
    "цимет|корица|Ово је цимет.|Еда и кулинария",
    "паприка|паприка|Ово је паприка.|Еда и кулинария",
    "сирће|уксус|Ово је сирће.|Еда и кулинария",
    "маслиново уље|оливковое масло|Ово је маслиново уље.|Еда и кулинария",
    "маргарин|маргарин|Ово је маргарин.|Еда и кулинария",
    "павлака|сметана|Ово је павлака.|Еда и кулинария",
    "јогурт|йогурт|Ово је јогурт.|Еда и кулинария",
    "кефир|кефир|Ово је кефир.|Еда и кулинария",
    "качкаваљ|кашкавал|Ово је качкаваљ.|Еда и кулинария",
    "урда|творог; мягкий сыр|Ово је урда.|Еда и кулинария",
    "жуманце|желток|Ово је жуманце.|Еда и кулинария",
    "беланце|белок|Ово је беланце.|Еда и кулинария",
    "јунетина|телятина; говядина|Ово је јунетина.|Еда и кулинария",
    "ћуретина|индейка|Ово је ћуретина.|Еда и кулинария",
    "патка|утка|Ово је патка.|Еда и кулинария",
    "кобасица|колбаса|Ово је кобасица.|Еда и кулинария",
    "шунка|ветчина|Ово је шунка.|Еда и кулинария",
    "сланина|бекон; сало|Ово је сланина.|Еда и кулинария",
    "млевено месо|фарш|Ово је млевено месо.|Еда и кулинария",
    "туњевина|тунец|Ово је туњевина.|Еда и кулинария",
    "лосос|лосось|Ово је лосос.|Еда и кулинария",
    "шкампи|креветки|Ово је шкампи.|Еда и кулинария",
    "дагње|мидии|Ово је дагње.|Еда и кулинария",
    "шкољке|ракушки; моллюски|Ово је шкољке.|Еда и кулинария",
    "сардина|сардина|Ово је сардина.|Еда и кулинария",
    "хлебне мрвице|панировочные сухари|Ово су хлебне мрвице.|Еда и кулинария",
    "пециво|выпечка; булочка|Ово је пециво.|Еда и кулинария",
    "кифла|рогалик; булочка|Ово је кифла.|Еда и кулинария",
    "пита са сиром|пирог с сыром|Ово је пита са сиром.|Еда и кулинария",
    "палачинка|блин|Ово је палачинка.|Еда и кулинария",
    "крофна|пончик|Ово је крофна.|Еда и кулинария",
    "торта|торт|Ово је торта.|Еда и кулинария",
    "мед|мёд|Ово је мед.|Еда и кулинария",
    "џем|варенье|Ово је џем.|Еда и кулинария",
    "ораси|грецкие орехи|Ово су ораси.|Еда и кулинария",
    "бадем|миндаль|Ово је бадем.|Еда и кулинария",
    "лешник|фундук|Ово је лешник.|Еда и кулинария",
    "суво грожђе|изюм|Ово је суво грожђе.|Еда и кулинария",
    "суво воће|сухофрукты|Ово је суво воће.|Еда и кулинария",
    "тржни центар|торговый центр|Ово је тржни центар.|Покупки и деньги",
    "касир|кассир|Ово је касир.|Покупки и деньги",
    "купац|покупатель|Ово је купac.|Покупки и деньги",
    "муштерија|клиент; покупатель|Ово је муштерија.|Покупки и деньги",
    "корпа|корзина|Ово је корпа.|Покупки и деньги",
    "колица|тележка|Ово су колица.|Покупки и деньги",
    "фискални рачун|кассовый чек|Ово је фискални рачун.|Покупки и деньги",
    "кусур|сдача|Ово је кусур.|Покупки и деньги",
    "акција|акция; распродажа|Ово је акција.|Покупки и деньги",
    "трошак|расход|Ово је трошак.|Покупки и деньги",
    "приход|доход|Ово је приход.|Покупки и деньги",
    "готовина|наличные|Ово је готовина.|Покупки и деньги",
    "банковни рачун|банковский счёт|Ово је банковни рачун.|Покупки и деньги",
    "банкомат|банкомат|Ово је банкомат.|Покупки и деньги",
    "кредит|кредит|Ово је кредит.|Покупки и деньги",
    "дуг|долг|Ово је дуг.|Покупки и деньги",
    "камата|процент; процентная ставка|Ово је камата.|Покупки и деньги",
    "штедња|сбережения|Ово је штедња.|Покупки и деньги",
    "плата|оплата; плата|Ово је плата.|Покупки и деньги",
    "плаћање|платёж|Ово је плаћање.|Покупки и деньги",
    "повраћај новца|возврат денег|Ово је повраћај новца.|Покупки и деньги",
    "гаранција|гарантия|Ово је гаранција.|Покупки и деньги",
    "рачуноводство|бухгалтерия|Ово је рачуноводство.|Покупки и деньги",
    "раскрсница|перекрёсток|Ово је раскрсница.|Город и услуги",
    "тротоар|тротуар|Ово је тротоар.|Город и услуги",
    "пешачки прелаз|пешеходный переход|Ово је пешачки прелаз.|Город и услуги",
    "семафор|светофор|Ово је семафор.|Город и услуги",
    "знак|знак|Ово је знак.|Город и услуги",
    "зграда|здание|Ово је зграда.|Город и услуги",
    "спрат|этаж|Ово је спрат.|Город и услуги",
    "приземље|первый этаж; цокольный уровень|Ово је приземље.|Город и услуги",
    "лифт|лифт|Ово је лифт.|Город и услуги",
    "степениште|лестничная клетка|Ово је степениште.|Город и услуги",
    "пошиљка|отправление|Ово је пошиљка.|Город и услуги",
    "пакет|посылка; пакет|Ово је пакет.|Город и услуги",
    "коверат|конверт|Ово је коверат.|Город и услуги",
    "марка|марка|Ово је марка.|Город и услуги",
    "поштански број|почтовый индекс|Ово је поштански број.|Город и услуги",
    "општина|муниципалитет|Ово је општина.|Город и услуги",
    "градска управа|городская администрация|Ово је градска управа.|Город и услуги",
    "полицијска станица|полицейский участок|Ово је полицијска станица.|Город и услуги",
    "ватрогасна станица|пожарная часть|Ово је ватрогасна станица.|Город и услуги",
    "амбуланта|амбулатория; кабинет врача|Ово је амбуланта.|Город и услуги",
    "лабораторија|лаборатория|Ово је лабораторија.|Город и услуги",
    "позориште|театр|Ово је позориште.|Город и услуги",
    "биоскоп|кинотеатр|Ово је биоскоп.|Город и услуги",
    "концертна дворана|концертный зал|Ово је концертна дворана.|Город и услуги",
    "галерија|галерея|Ово је галерија.|Город и услуги",
    "стадион|стадион|Ово је стадион.|Город и услуги",
    "теретана|спортзал|Ово је теретана.|Город и услуги",
    "базен|бассейн|Ово је базен.|Город и услуги",
    "игралиште|игровая площадка|Ово је игралиште.|Город и услуги",
    "гробље|кладбище|Ово је гробље.|Город и услуги",
    "црква|церковь|Ово је црква.|Город и услуги",
    "манастир|монастырь|Ово је манастир.|Город и услуги",
    "месара|мясная лавка|Ово је месара.|Город и услуги",
    "фризер|парикмахер|Ово је фризер.|Город и услуги",
    "берберница|барбершоп|Ово је берберница.|Город и услуги",
    "перионица|прачечная; автомойка|Ово је перионица.|Город и услуги",
    "сервис|сервис; мастерская|Ово је сервис.|Город и услуги",
    "радионица|мастерская|Ово је радионица.|Город и услуги",
    "смеће|мусор|Ово су смеће.|Город и услуги",
    "контејнер|контейнер|Ово је контејнер.|Город и услуги",
    "канта за смеће|мусорное ведро|Ово је канта за смеће.|Город и услуги",
    "рециклажа|переработка отходов|Ово је рециклажа.|Город и услуги",
    "саобраћај|дорожное движение; транспорт|Ово је саобраћај.|Транспорт и путешествия",
    "превоз|перевозка; транспорт|Ово је превоз.|Транспорт и путешествия",
    "ауто|машина|Ово је ауто.|Транспорт и путешествия",
    "камион|грузовик|Ово је камион.|Транспорт и путешествия",
    "комби|микроавтобус; фургон|Ово је комби.|Транспорт и путешествия",
    "мотоцикл|мотоцикл|Ово је мотоцикл.|Транспорт и путешествия",
    "тротинет|самокат|Ово је тротинет.|Транспорт и путешествия",
    "лука|порт|Ово је лука.|Транспорт и путешествия",
    "пристаниште|пристань|Ово је пристаниште.|Транспорт и путешествия",
    "перон|платформа|Ово је перон.|Транспорт и путешествия",
    "колосек|железнодорожный путь|Ово је колосек.|Транспорт и путешествия",
    "једносмерна карта|билет в одну сторону|Ово је једносмерна карта.|Транспорт и путешествия",
    "полазак|отправление|Ово је полазак.|Транспорт и путешествия",
    "долазак|прибытие|Ово је долазак.|Транспорт и путешествия",
    "кашњење|задержка|Ово је кашњење.|Транспорт и путешествия",
    "преседање|пересадка|Ово је преседање.|Транспорт и путешествия",
    "путник|пассажир|Ово је путник.|Транспорт и путешествия",
    "кондуктер|кондуктор|Ово је кондуктер.|Транспорт и путешествия",
    "саобраћајна дозвола|свидетельство о регистрации автомобиля|Ово је саобраћајна дозвола.|Транспорт и путешествия",
    "возачка дозвола|водительское удостоверение|Ово је возачка дозвола.|Транспорт и путешествия",
    "регистарска таблица|номерной знак|Ово је регистарска таблица.|Транспорт и путешествия",
    "точак|колесо|Ово је точак.|Транспорт и путешествия",
    "гума|шина|Ово је гума.|Транспорт и путешествия",
    "кочница|тормоз|Ово је кочница.|Транспорт и путешествия",
    "волан|руль|Ово је волан.|Транспорт и путешествия",
    "резервоар|топливный бак|Ово је резервоар.|Транспорт и путешествия",
    "гориво|топливо|Ово је гориво.|Транспорт и путешествия",
    "бензинска пумпа|заправка|Ово је бензинска пумпа.|Транспорт и путешествия",
    "паркинг|парковка|Ово је паркинг.|Транспорт и путешествия",
    "паркинг место|парковочное место|Ово је паркинг место.|Транспорт и путешествия",
    "путарина|плата за проезд по дороге|Ово је путарина.|Транспорт и путешествия",
    "аутопут|автомагистраль|Ово је аутопут.|Транспорт и путешествия",
    "магистрални пут|шоссе|Ово је магистрални пут.|Транспорт и путешествия",
    "тунел|туннель|Ово је тунел.|Транспорт и путешествия",
    "гранични прелаз|пограничный переход|Ово је гранични прелаз.|Транспорт и путешествия",
    "виза|виза|Ово је виза.|Транспорт и путешествия",
    "путно осигурање|туристическая страховка|Ово је путно осигурање.|Транспорт и путешествия",
    "пртљаг|багаж|Ово је пртљаг.|Транспорт и путешествия",
    "кофер|чемодан|Ово је кофер.|Транспорт и путешествия",
    "ранац|рюкзак|Ово је ранац.|Транспорт и путешествия",
    "хостел|хостел|Ово је хостел.|Транспорт и путешествия",
    "камп|кемпинг|Ово је камп.|Транспорт и путешествия",
    "туриста|турист|Ово је туриста.|Транспорт и путешествия",
    "водич|гид|Ово је водич.|Транспорт и путешествия",
    "разгледање|осмотр достопримечательностей|Ово је разгледање.|Транспорт и путешествия",
    "учионица|класс; учебная аудитория|Ово је учионица.|Учёба и работа",
    "табла|доска|Ово је табла.|Учёба и работа",
    "креда|мел|Ово је креда.|Учёба и работа",
    "маркер|маркер|Ово је маркер.|Учёба и работа",
    "уџбеник|учебник|Ово је уџбеник.|Учёба и работа",
    "радна свеска|рабочая тетрадь|Ово је радна свеска.|Учёба и работа",
    "гумица|ластик|Ово је гумица.|Учёба и работа",
    "лењир|линейка|Ово је лењир.|Учёба и работа",
    "ранец|ранец|Ово је ранец.|Учёба и работа",
    "распоред|расписание|Ово је распоред.|Учёба и работа",
    "час|урок; час|Ово је час.|Учёба и работа",
    "домаћи задатак|домашнее задание|Ово је домаћи задатак.|Учёба и работа",
    "контролни задатак|контрольная работа|Ово је контролни задатак.|Учёба и работа",
    "испит|экзамен|Ово је испит.|Учёба и работа",
    "оцена|оценка|Ово је оцена.|Учёба и работа",
    "сведочанство|аттестат; свидетельство|Ово је сведочанство.|Учёба и работа",
    "диплома|диплом|Ово је диплома.|Учёба и работа",
    "професор|учитель; профессор|Ово је професор.|Учёба и работа",
    "директор|директор|Ово је директор.|Учёба и работа",
    "колегиница|коллега (жен.)|Ово је колегиница.|Учёба и работа",
    "запослење|трудоустройство|Ово је запослење.|Учёба и работа",
    "радно место|рабочее место|Ово је радно место.|Учёба и работа",
    "канцеларија|офис|Ово је канцеларија.|Учёба и работа",
    "састанак|встреча; совещание|Ово је састанак.|Учёба и работа",
    "договор|соглашение|Ово је договор.|Учёба и работа",
    "уговор о раду|трудовой договор|Ово је уговор о раду.|Учёба и работа",
    "плата за рад|заработная плата|Ово је плата за рад.|Учёба и работа",
    "радно време|рабочее время|Ово је радно време.|Учёба и работа",
    "смена|смена|Ово је смена.|Учёба и работа",
    "пауза|перерыв|Ово је паузa.|Учёба и работа",
    "одмор од посла|отпуск|Ово је одмор од посла.|Учёба и работа",
    "пријава|заявление; регистрация|Ово је пријава.|Учёба и работа",
    "пријава за посао|заявление о приёме на работу|Ово је пријава за посао.|Учёба и работа",
    "биографија|резюме; биография|Ово је биографија.|Учёба и работа",
    "интервју|собеседование; интервью|Ово је интервју.|Учёба и работа",
    "искуство|опыт|Ово је искуство.|Учёба и работа",
    "вештина|навык|Ово је вештина.|Учёба и работа",
    "задатак|задание|Ово је задатак.|Учёба и работа",
    "обавеза|обязанность|Ово је обавеза.|Учёба и работа",
    "рок|срок|Ово је рок.|Учёба и работа",
    "пројекат|проект|Ово је пројекат.|Учёба и работа",
    "извештај|отчёт|Ово је извештај.|Учёба и работа",
    "печат|печать|Ово је печат.|Учёба и работа",
    "екран|экран|Ово је екран.|Технологии и связь",
    "тастатура|клавиатура|Ово је тастатура.|Технологии и связь",
    "миш|мышь|Ово је миш.|Технологии и связь",
    "штампач|принтер|Ово је штампач.|Технологии и связь",
    "скенер|сканер|Ово је скенер.|Технологии и связь",
    "фасцикла|папка|Ово је фасцикла.|Технологии и связь",
    "фајл|файл|Ово је фајл.|Технологии и связь",
    "датотека|файл; данные|Ово је датотека.|Технологии и связь",
    "програм|программа|Ово је програм.|Технологии и связь",
    "апликација|приложение|Ово је апликација.|Технологии и связь",
    "оперативни систем|операционная система|Ово је оперативни систем.|Технологии и связь",
    "ажурирање|обновление|Ово је ажурирање.|Технологии и связь",
    "инсталација|установка|Ово је инсталација.|Технологии и связь",
    "поставка|настройка|Ово је поставка.|Технологии и связь",
    "лозинка|пароль|Ово је лозинка.|Технологии и связь",
    "корисничко име|имя пользователя|Ово је корисничко име.|Технологии и связь",
    "налог|аккаунт; учётная запись|Ово је налог.|Технологии и связь",
    "профил|профиль|Ово је профил.|Технологии и связь",
    "мрежа|сеть|Ово је мрежа.|Технологии и связь",
    "интернет веза|интернет-соединение|Ово је интернет веза.|Технологии и связь",
    "бежична мрежа|беспроводная сеть|Ово је бежична мрежа.|Технологии и связь",
    "рутер|роутер|Ово је рутер.|Технологии и связь",
    "модем|модем|Ово је модем.|Технологии и связь",
    "сигнал|сигнал|Ово је сигнал.|Технологии и связь",
    "текстуална порука|текстовое сообщение|Ово је текстуална порука.|Технологии и связь",
    "позив|звонок|Ово је позив.|Технологии и связь",
    "видео-позив|видеозвонок|Ово је видео-позив.|Технологии и связь",
    "говорна пошта|голосовая почта|Ово је говорна пошта.|Технологии и связь",
    "адреса е-поште|адрес электронной почты|Ово је адреса е-поште.|Технологии и связь",
    "претраживач|браузер|Ово је претраживач.|Технологии и связь",
    "претрага|поиск|Ово је претрага.|Технологии и связь",
    "резултат|результат|Ово је резултат.|Технологии и связь",
    "линк|ссылка|Ово је линк.|Технологии и связь",
    "веб-сајт|веб-сайт|Ово је веб-сајт.|Технологии и связь",
    "страница|страница|Ово је страница.|Технологии и связь",
    "преузимање|скачивание|Ово је преузимање.|Технологии и связь",
    "отпремање|загрузка; отправка файла|Ово је отпремање.|Технологии и связь",
    "резервна копија|резервная копия|Ово је резервна копија.|Технологии и связь",
    "меморија|память|Ово је меморија.|Технологии и связь",
    "складиште|хранилище|Ово је складиште.|Технологии и связь",
    "приватност|конфиденциальность|Ово је приватност.|Технологии и связь",
    "безбедност|безопасность|Ово је безбедност.|Технологии и связь",
    "вирус|вирус|Ово је вирус.|Технологии и связь",
    "грешка|ошибка|Ово је грешка.|Технологии и связь",
    "обавештење|уведомление|Ово је обавештење.|Технологии и связь",
    "симптом|симптом|Ово је симптом.|Здоровье и тело",
    "зубобоља|зубная боль|Ово је зубобоља.|Здоровье и тело",
    "кашаљ|кашель|Ово је кашаљ.|Здоровье и тело",
    "кијање|чихание|Ово је кијање.|Здоровье и тело",
    "цурење из носа|насморк|Ово је цурење из носа.|Здоровье и тело",
    "грлобоља|боль в горле|Ово је грлобоља.|Здоровье и тело",
    "упала|воспаление|Ово је упала.|Здоровье и тело",
    "рана|рана|Ово је рана.|Здоровье и тело",
    "модрица|синяк|Ово је модрица.|Здоровье и тело",
    "опекотина|ожог|Ово је опекотина.|Здоровье и тело",
    "алергија|аллергия|Ово је алергија.|Здоровье и тело",
    "таблета|таблетка|Ово је таблета.|Здоровье и тело",
    "сируп|сироп|Ово је сируп.|Здоровье и тело",
    "рецепт за лек|рецепт на лекарство|Ово је рецепт за лек.|Здоровье и тело",
    "преглед|осмотр|Ово је преглед.|Здоровье и тело",
    "заказивање|запись; назначение|Ово је заказивање.|Здоровье и тело",
    "термин код лекара|приём у врача|Ово је термин код лекара.|Здоровье и тело",
    "пацијент|пациент|Ово је пацијент.|Здоровье и тело",
    "зубар|стоматолог|Ово је зубар.|Здоровье и тело",
    "стоматолог|стоматолог|Ово је стоматолог.|Здоровье и тело",
    "притисак|давление|Ово је притисак.|Здоровье и тело",
    "пулс|пульс|Ово је пулс.|Здоровье и тело",
    "дисање|дыхание|Ово је дисање.|Здоровье и тело",
    "плућа|лёгкие|Ово су плућа.|Здоровье и тело",
    "желудац|желудок|Ово је желудац.|Здоровье и тело",
    "црево|кишечник|Ово је црево.|Здоровье и тело",
    "јетра|печень|Ово је јетра.|Здоровье и тело",
    "бубрег|почка|Ово је бубрег.|Здоровье и тело",
    "кожа|кожа|Ово је кожа.|Здоровье и тело",
    "мишић|мышца|Ово је мишић.|Здоровье и тело",
    "кост|кость|Ово је кост.|Здоровье и тело",
    "зглоб|сустав|Ово је зглоб.|Здоровье и тело",
    "раме|плечо|Ово је раме.|Здоровье и тело",
    "лакат|локоть|Ово је лакат.|Здоровье и тело",
    "колено|колено|Ово је колено.|Здоровье и тело",
    "скочни зглоб|голеностоп|Ово је скочни зглоб.|Здоровье и тело",
    "пета|пятка|Ово је пета.|Здоровье и тело",
    "длан|ладонь|Ово је длан.|Здоровье и тело",
    "нокат|ноготь|Ово је нокат.|Здоровье и тело",
    "обрва|бровь|Ово је обрва.|Здоровье и тело",
    "трепавица|ресница|Ово је трепавица.|Здоровье и тело",
    "грло|горло|Ово је грло.|Здоровье и тело",
    "врат|шея|Ово је врат.|Здоровье и тело",
    "груди|грудь|Ово су груди.|Здоровье и тело",
    "кук|бедро; тазобедренный сустав|Ово је кук.|Здоровье и тело",
    "лист|икра ноги|Ово је лист.|Здоровье и тело",
    "осећање|чувство|Ово је осећање.|Эмоции и общение",
    "расположење|настроение|Ово је расположење.|Эмоции и общение",
    "радост|радость|Ово је радост.|Эмоции и общение",
    "срећа|счастье|Ово је срећа.|Эмоции и общение",
    "туга|печаль|Ово је туга.|Эмоции и общение",
    "страх|страх|Ово је страх.|Эмоции и общение",
    "брига|забота; беспокойство|Ово је брига.|Эмоции и общение",
    "бес|ярость|Ово је бес.|Эмоции и общение",
    "љутња|злость|Ово је љутња.|Эмоции и общение",
    "стид|стыд|Ово је стид.|Эмоции и общение",
    "понос|гордость|Ово је понос.|Эмоции и общение",
    "нада|надежда|Ово је нада.|Эмоции и общение",
    "поверење|доверие|Ово је поверење.|Эмоции и общение",
    "сумња|сомнение|Ово је сумња.|Эмоции и общение",
    "љубав|любов|Ово је љубав.|Эмоции и общение",
    "мржња|ненависть|Ово је мржња.|Эмоции и общение",
    "пријатељство|дружба|Ово је пријатељство.|Эмоции и общение",
    "поштовање|уважение|Ово је поштовање.|Эмоции и общение",
    "подршка|поддержка|Ово је подршка.|Эмоции и общение",
    "савет|совет|Ово је савет.|Эмоции и общение",
    "молба|просьба|Ово је молба.|Эмоции и общение",
    "обећање|обещание|Ово је обећање.|Эмоции и общение",
    "извињење|извинение|Ово је извињење.|Эмоции и общение",
    "поздрав|приветствие|Ово је поздрав.|Эмоции и общение",
    "расправа|спор; дискуссия|Ово је расправа.|Эмоции и общение",
    "свађа|ссора|Ово је свађа.|Эмоции и общение",
    "шала|шутка|Ово је шала.|Эмоции и общение",
    "смех|смех|Ово је смех.|Эмоции и общение",
    "осмех|улыбка|Ово је осмех.|Эмоции и общение",
    "сузе|слёзы|Ово су сузе.|Эмоции и общение",
    "глас|голос|Ово је глас.|Эмоции и общение",
    "бука|шум|Ово је бука.|Эмоции и общение",
    "тишина|тишина|Ово је тишина.|Эмоции и общение",
    "звук|звук|Ово је звук.|Эмоции и общение",
    "израз|выражение|Ово је израз.|Эмоции и общение",
    "објашњење|объяснение|Ово је објашњење.|Эмоции и общение",
    "мишљење|мнение|Ово је мишљење.|Эмоции и общение",
    "идеја|идея|Ово је идеја.|Эмоции и общение",
    "истина|правда|Ово је истина.|Эмоции и общение",
    "лаж|ложь|Ово је лаж.|Эмоции и общение",
    "разлог|причина|Ово је разлог.|Эмоции и общение",
    "животна средина|окружающая среда|Ово је животна средина.|Природа и экология",
    "природа|природа|Ово је природа.|Природа и экология",
    "шума|лес|Ово је шума.|Природа и экология",
    "шумица|лесок|Ово је шумица.|Природа и экология",
    "грана|ветка|Ово је грана.|Природа и экология",
    "корен|корень|Ово је корен.|Природа и экология",
    "кора|кора|Ово је кора.|Природа и экология",
    "семе|семя|Ово је семе.|Природа и экология",
    "тло|почва|Ово је тло.|Природа и экология",
    "песак|песок|Ово је песак.|Природа и экология",
    "камен|камень|Ово је камен.|Природа и экология",
    "стена|скала|Ово је стена.|Природа и экология",
    "брдо|холм|Ово је брдо.|Природа и экология",
    "долина|долина|Ово је долина.|Природа и экология",
    "равница|равнина|Ово је равница.|Природа и экология",
    "поток|ручей|Ово је поток.|Природа и экология",
    "водопад|водопад|Ово је водопад.|Природа и экология",
    "језеро|озеро|Ово је језеро.|Природа и экология",
    "обала|берег|Ово је обала.|Природа и экология",
    "острво|остров|Ово је острво.|Природа и экология",
    "талас|волна|Ово је талас.|Природа и экология",
    "плима|прилив|Ово је плима.|Природа и экология",
    "плима и осека|приливы и отливы|Ово је плима и осека.|Природа и экология",
    "извор|источник; родник|Ово је извор.|Природа и экология",
    "ваздух|воздух|Ово је ваздух.|Природа и экология",
    "загађење|загрязнение|Ово је загађење.|Природа и экология",
    "отпад|отходы|Ово је отпад.|Природа и экология",
    "пластика|пластик|Ово је пластика.|Природа и экология",
    "стакло|стекло|Ово је стакло.|Природа и экология",
    "метал|металл|Ово је метал.|Природа и экология",
    "батерија за рециклажу|батарейка для переработки|Ово је батерија за рециклажу.|Природа и экология",
    "штетан|вредный|Ово је штетан.|Природа и экология",
    "користан|полезный|Ово је користан.|Природа и экология",
    "обновљиви извори енергије|возобновляемые источники энергии|Ово је обновљиви извори енергије.|Природа и экология",
    "соларна енергија|солнечная энергия|Ово је соларна енергија.|Природа и экология",
    "ветроелектрана|ветроэлектростанция|Ово је ветроелектрана.|Природа и экология",
    "електрана|электростанция|Ово је електрана.|Природа и экология",
    "потрошња енергије|потребление энергии|Ово је потрошња енергије.|Природа и экология",
    "уштеда енергије|экономия энергии|Ово је уштеда енергије.|Природа и экология",
    "клима|климат|Ово је клима.|Природа и экология",
    "климатске промене|изменение климата|Ово је климатске промене.|Природа и экология",
    "олуја|буря|Ово је олуја.|Природа и экология",
    "грмљавина|гроза|Ово је грмљавина.|Природа и экология",
    "муња|молния|Ово је муња.|Природа и экология",
    "магла|туман|Ово је магла.|Природа и экология",
    "мраз|мороз|Ово је мраз.|Природа и экология",
    "суша|засуха|Ово је суша.|Природа и экология",
    "поплава|наводнение|Ово је поплава.|Природа и экология",
    "пожар|пожар|Ово је пожар.|Природа и экология",
    "љубимац|домашний питомец|Ово је љубимац.|Животные",
    "кућни љубимац|домашний питомец|Ово је кућни љубимац.|Животные",
    "маче|котёнок|Ово је маче.|Животные",
    "штене|щенок|Ово је штене.|Животные",
    "зец|кролик|Ово је зец.|Животные",
    "хрчак|хомяк|Ово је хрчак.|Животные",
    "пацов|крыса|Ово је пацов.|Животные",
    "лисица|лиса|Ово је лисица.|Животные",
    "вук|волк|Ово је вук.|Животные",
    "медвед|медведь|Ово је медвед.|Животные",
    "јелен|олень|Ово је јелен.|Животные",
    "срна|косуля|Ово је срна.|Животные",
    "дивља свиња|дикий кабан|Ово је дивља свиња.|Животные",
    "веверица|белка|Ово је веверица.|Животные",
    "јеж|ёж|Ово је јеж.|Животные",
    "слепи миш|летучая мышь|Ово је слепи миш.|Животные",
    "орао|орёл|Ово је орао.|Животные",
    "сова|сова|Ово је сова.|Животные",
    "врана|ворона|Ово је врана.|Животные",
    "голуб|голубь|Ово је голуб.|Животные",
    "врабац|воробей|Ово је врабац.|Животные",
    "ластавица|ласточка|Ово је ластaвица.|Животные",
    "сврака|сорока|Ово је сврака.|Животные",
    "петао|петух|Ово је петао.|Животные",
    "кокошка|курица|Ово је кокошка.|Животные",
    "пиле|цыплёнок|Ово је пиле.|Животные",
    "гуска|гусь|Ово је гуска.|Животные",
    "ћурка|индейка|Ово је ћурка.|Животные",
    "магарац|осёл|Ово је магарац.|Животные",
    "коза|коза|Ово је коза.|Животные",
    "јагње|ягнёнок|Ово је јагње.|Животные",
    "пчела|пчела|Ово је пчела.|Животные",
    "лептир|бабочка|Ово је лептир.|Животные",
    "мрав|муравей|Ово је мрав.|Животные",
    "комарац|комар|Ово је комарац.|Животные",
    "муха|муха|Ово је муха.|Животные",
    "паук|паук|Ово је паук.|Животные",
    "змија|змея|Ово је змија.|Животные",
    "гуштер|ящерица|Ово је гуштер.|Животные",
    "корњача|черепаха|Ово је корњача.|Животные",
    "жаба|лягушка|Ово је жаба.|Животные",
    "делфин|дельфин|Ово је делфин.|Животные",
    "кит|кит|Ово је кит.|Животные",
    "ајкула|акула|Ово је ајкула.|Животные",
    "тачан|точный; правильный|Он је тачан.|Прилагательные",
    "нетачан|неверный|Он је нетачан.|Прилагательные",
    "могућ|возможный|Он је могућ.|Прилагательные",
    "немогућ|невозможный|Он је немогућ.|Прилагательные",
    "неопходан|необходимый|Он је неопходан.|Прилагательные",
    "бескористан|бесполезный|Он је бескористан.|Прилагательные",
    "опасан|опасный|Он је опасан.|Прилагательные",
    "безбедан|безопасный|Он је безбедан.|Прилагательные",
    "несигуран|неуверенный|Он је несигуран.|Прилагательные",
    "љубазан|вежливый; доброжелательный|Он је љубазан.|Прилагательные",
    "нељубазан|невежливый|Он је нељубазан.|Прилагательные",
    "стрпљив|терпеливый|Он је стрпљив.|Прилагательные",
    "нестрпљив|нетерпеливый|Он је нестрпљив.|Прилагательные",
    "пажљив|внимательный|Он је пажљив.|Прилагательные",
    "непажљив|невнимательный|Он је непажљив.|Прилагательные",
    "искрен|искренний|Он је искрен.|Прилагательные",
    "поштен|честный|Он је поштен.|Прилагательные",
    "непоштен|нечестный|Он је непоштен.|Прилагательные",
    "паметан|умный|Он је паметан.|Прилагательные",
    "глуп|глупый|Он је глуп.|Прилагательные",
    "радознао|любопытный|Он је радознао.|Прилагательные",
    "вредан|трудолюбивый|Он је вредан.|Прилагательные",
    "лењ|ленивый|Он је лењ.|Прилагательные",
    "марљив|старательный|Он је марљив.|Прилагательные",
    "одговоран|ответственный|Он је одговоран.|Прилагательные",
    "неодговоран|безответственный|Он је неодговоран.|Прилагательные",
    "озбиљан|серьёзный|Он је озбиљан.|Прилагательные",
    "опуштен|расслабленный|Он је опуштен.|Прилагательные",
    "нервозан|нервный|Он је нервозан.|Прилагательные",
    "забринут|обеспокоенный|Он је забринут.|Прилагательные",
    "изненађен|удивлённый|Он је изненађен.|Прилагательные",
    "задовољан|довольный|Он је задовољан.|Прилагательные",
    "незадовољан|недовольный|Он је незадовољан.|Прилагательные",
    "поносан|гордый|Он је поносан.|Прилагательные",
    "усамљен|одинокий|Он је усамљен.|Прилагательные",
    "друштвен|общительный|Он је друштвен.|Прилагательные",
    "стидљив|застенчивый|Он је стидљив.|Прилагательные",
    "храбар|смелый|Он је храбар.|Прилагательные",
    "слаб|слабый|Он је слаб.|Прилагательные",
    "снажан|сильный|Он је снажан.|Прилагательные",
    "мек|мягкий|Он је мек.|Прилагательные",
    "тврд|твёрдый|Он је тврд.|Прилагательные",
    "гладак|гладкий|Он је гладак.|Прилагательные",
    "храпав|шероховатый|Он је храпав.|Прилагательные",
    "дебео|толстый|Он је дебео.|Прилагательные",
    "мршав|худой|Он је мршав.|Прилагательные",
    "дубок|глубокий|Он је дубок.|Прилагательные",
    "плитак|мелкий; неглубокий|Он је плитак.|Прилагательные",
    "тесан|тесный|Он је тесан.|Прилагательные",
    "простран|просторный|Он је простран.|Прилагательные",
    "удобан|удобный|Он је удобан.|Прилагательные",
    "неудобан|неудобный|Он је неудобан.|Прилагательные",
    "савремен|современный|Он је савремен.|Прилагательные",
    "традиционалан|традиционный|Он је традиционалан.|Прилагательные",
    "познат|известный; знакомый|Он је познат.|Прилагательные",
    "непознат|неизвестный|Он је непознат.|Прилагательные",
    "популаран|популярный|Он је популаран.|Прилагательные",
    "чест|частый|Он је чест.|Прилагательные",
    "редак|редкий|Он је редак.|Прилагательные",
    "заједнички|общий; совместный|Он је заједнички.|Прилагательные",
    "посебан|особенный|Он је посебан.|Прилагательные",
    "различит|различный|Он је различит.|Прилагательные",
    "једноставан|простой|Он је једноставан.|Прилагательные",
    "сложен|сложный|Он је сложен.|Прилагательные",
    "доступан|доступный|Он је доступан.|Прилагательные",
    "недоступан|недоступный|Он је недоступан.|Прилагательные",
    "прихватити|принять|Потребно је прихватити.|Глаголы",
    "одбити|отказаться; отклонить|Потребно је одбити.|Глаголы",
    "изабрати|выбрать|Потребно је изабрати.|Глаголы",
    "одлучити|решить|Потребно је одлучити.|Глаголы",
    "планирати|планировать|Потребно је планирати.|Глаголы",
    "припремити|подготовить|Потребно је припремити.|Глаголы",
    "организовати|организовать|Потребно је организовати.|Глаголы",
    "објаснити|объяснить|Потребно је објаснити.|Глаголы",
    "описати|описать|Потребно је описати.|Глаголы",
    "упоредити|сравнить|Потребно је упоредити.|Глаголы",
    "проверити|проверить|Потребно је проверити.|Глаголы",
    "потврдити|подтвердить|Потребно је потврдити.|Глаголы",
    "променити|изменить|Потребно је променити.|Глаголы",
    "поправити|исправить; починить|Потребно је поправити.|Глаголы",
    "успети|преуспеть; суметь|Потребно је успети.|Глаголы",
    "пропустити|пропустить|Потребно је пропустити.|Глаголы",
    "наставити|продолжить|Потребно је наставити.|Глаголы",
    "прекинути|прервать|Потребно је прекинути.|Глаголы",
    "поновити|повторить|Потребно је поновити.|Глаголы",
    "запамтити|запомнить|Потребно је запамтити.|Глаголы",
    "научити|научить|Потребно је научити.|Глаголы",
    "вежбати|тренироваться|Потребно је вежбати.|Глаголы",
    "вежбати се|упражняться|Потребно је вежбати се.|Глаголы",
    "развијати|развивать|Потребно је развијати.|Глаголы",
    "напредовати|продвигаться|Потребно је напредовати.|Глаголы",
    "побољшати|улучшить|Потребно је побољшати.|Глаголы",
    "смањити|уменьшить|Потребно је смањити.|Глаголы",
    "повећати|увеличить|Потребно је повећати.|Глаголы",
    "уштедети|сэкономить|Потребно је уштедети.|Глаголы",
    "потрошити|потратить|Потребно је потрошити.|Глаголы",
    "зарадити|заработать|Потребно је зарадити.|Глаголы",
    "позајмити|одолжить|Потребно је позајмити.|Глаголы",
    "вратити|вернуть|Потребно је вратити.|Глаголы",
    "наручити|заказать|Потребно је наручити.|Глаголы",
    "резервисати|забронировать|Потребно је резервисати.|Глаголы",
    "отказати|отменить|Потребно је отказати.|Глаголы",
    "испоручити|доставить|Потребно је испоручити.|Глаголы",
    "послати|отправить|Потребно је послати.|Глаголы",
    "примити|получить; принять|Потребно је примити.|Глаголы",
    "поделити|разделить; поделиться|Потребно је поделити.|Глаголы",
    "припадати|принадлежать|Потребно је припадати.|Глаголы",
    "садржати|содержать|Потребно је садржати.|Глаголы",
    "укључити|включить|Потребно је укључити.|Глаголы",
    "искључити|выключить|Потребно је искључити.|Глаголы",
    "прикључити|подключить|Потребно је прикључити.|Глаголы",
    "ископирати|скопировать|Потребно је ископирати.|Глаголы",
    "сачувати|сохранить|Потребно је сачувати.|Глаголы",
    "обрисати|удалить; стереть|Потребно је обрисати.|Глаголы",
    "преузети|скачать; взять на себя|Потребно је преузети.|Глаголы",
    "отпремити|загрузить; отправить|Потребно је отпремити.|Глаголы",
    "покренути|запустить|Потребно је покренути.|Глаголы",
    "инсталирати|установить|Потребно је инсталирати.|Глаголы",
    "пријавити се|войти; зарегистрироваться|Потребно је пријавити се.|Глаголы",
    "одјавити се|выйти из аккаунта|Потребно је одјавити се.|Глаголы",
    "јавити се|откликнуться; связаться|Потребно је јавити се.|Глаголы",
    "контактирати|связаться|Потребно је контактирати.|Глаголы",
    "разговарати|разговаривать|Потребно је разговарати.|Глаголы",
    "споменути|упомянуть|Потребно је споменути.|Глаголы",
    "предложити|предложить|Потребно је предложити.|Глаголы",
    "обећати|пообещать|Потребно је обећати.|Глаголы",
    "дозволити|разрешить|Потребно је дозволити.|Глаголы",
    "забранити|запретить|Потребно је забранити.|Глаголы",
    "поклонити|подарить|Потребно је поклонити.|Глаголы",
    "прославити|отпраздновать|Потребно је прославити.|Глаголы",
    "посетити|посетить|Потребно је посетити.|Глаголы",
    "срести|встретить|Потребно је срести.|Глаголы",
    "срести се|встретиться|Потребно је срести се.|Глаголы",
    "упозорити|предупредить|Потребно је упозорити.|Глаголы",
    "избегавати|избегать|Потребно је избегавати.|Глаголы",
    "заштитити|защитить|Потребно је заштитити.|Глаголы",
    "спречити|предотвратить|Потребно је спречити.|Глаголы",
    "помирити се|помириться|Потребно је помирити се.|Глаголы",
    "расправљати|обсуждать; спорить|Потребно је расправљати.|Глаголы",
    "сложити се|согласиться|Потребно је сложити се.|Глаголы",
    "не сложити се|не согласиться|Потребно је не сложити се.|Глаголы",
    "веровати|верить|Потребно је веровати.|Глаголы",
    "надати се|надеяться|Потребно је надати се.|Глаголы",
    "бринути се|беспокоиться; заботиться|Потребно је бринути се.|Глаголы",
    "осмехнути се|улыбнуться|Потребно је осмехнути се.|Глаголы",
    "насмејати се|рассмеяться|Потребно је насмејати се.|Глаголы",
    "недостајати|не хватать; скучать по|Потребно је недостајати.|Глаголы",
    "уживати|наслаждаться|Потребно је уживати.|Глаголы",
    "одмарати се|отдыхать|Потребно је одмарати се.|Глаголы",
    "опустити се|расслабиться|Потребно је опустити се.|Глаголы",
    "пожурити|поторопиться|Потребно је пожурити.|Глаголы",
    "каснити|опаздывать|Потребно је каснити.|Глаголы",
    "стићи|успеть; прибыть|Потребно је стићи.|Глаголы",
    "кренути|отправиться|Потребно је кренути.|Глаголы",
    "скренути|повернуть|Потребно је скренути.|Глаголы",
    "прећи|перейти|Потребно је прећи.|Глаголы",
    "зауставити|остановить|Потребно је зауставити.|Глаголы",
    "паркирати|припарковать|Потребно је паркирати.|Глаголы",
    "попети се|подняться|Потребно је попети се.|Глаголы",
    "сићи|спуститься|Потребно је сићи.|Глаголы",
    "ући|войти|Потребно је ући.|Глаголы",
    "изаћи|выйти|Потребно је изаћи.|Глаголы",
    "преселити се|переехать|Потребно је преселити се.|Глаголы",
    "изнајмити|арендовать|Потребно је изнајмити.|Глаголы",
    "изнајмљивати|сдавать в аренду|Потребно је изнајмљивати.|Глаголы",
    "поправљати|чинить|Потребно је поправљати.|Глаголы",
    "испрати|прополоскать|Потребно је испрати.|Глаголы",
    "испржити|поджарить|Потребно је испржити.|Глаголы",
    "пећи|печь; жарить|Потребно је пећи.|Глаголы",
    "сецкати|нарезать|Потребно је сецкати.|Глаголы",
    "мешати|мешать|Потребно је мешати.|Глаголы",
    "додати|добавить|Потребно је додати.|Глаголы",
    "уклонити|убрать; удалить|Потребно је уклонити.|Глаголы",
    "послужити|подать; послужить|Потребно је послужити.|Глаголы",
    "пробати|попробовать|Потребно је пробати.|Глаголы",
    "мирисати|пахнуть|Потребно је мирисати.|Глаголы",
    "имати укус|иметь вкус|Потребно је имати укус.|Глаголы",
    "нарезати|нарезать|Потребно је нарезати.|Глаголы",
    "пунити|наполнять; заряжать|Потребно је пунити.|Глаголы",
    "испразнити|опустошить|Потребно је испразнити.|Глаголы",
    "покрити|накрыть|Потребно је покрити.|Глаголы",
    "открити|открыть; обнаружить|Потребно је открити.|Глаголы",
    "вероватно|вероятно|Он то ради вероватно.|Наречия и предлоги/связки",
    "заиста|действительно|Он то ради заиста.|Наречия и предлоги/связки",
    "нарочито|намеренно|Он то ради нарочито.|Наречия и предлоги/связки",
    "случајно|случайно|Он то ради случајно.|Наречия и предлоги/связки",
    "одвојено|отдельно|Он то ради одвојено.|Наречия и предлоги/связки",
    "углавном|в основном|Он то ради углавном.|Наречия и предлоги/связки",
    "посебно|особенно; отдельно|Он то ради посебно.|Наречия и предлоги/связки",
    "барем|по крайней мере|Он то ради барем.|Наречия и предлоги/связки",
    "скоро|скоро|Он то ради скоро.|Наречия и предлоги/связки",
    "управо|именно; только что|Он то ради управо.|Наречия и предлоги/связки",
    "тренутно|в данный момент|Он то ради тренутно.|Наречия и предлоги/связки",
    "коначно|наконец|Он то ради коначно.|Наречия и предлоги/связки",
    "одједном|внезапно|Он то ради одједном.|Наречия и предлоги/связки",
    "пажљиво|внимательно|Он то ради пажљиво.|Наречия и предлоги/связки",
    "тачно|точно; ровно|Он то ради тачно.|Наречия и предлоги/связки",
    "приближно|приблизительно|Он то ради приближно.|Наречия и предлоги/связки",
    "превише|слишком много|Он то ради превише.|Наречия и предлоги/связки",
    "мање-више|более-менее|Он то ради мање-више.|Наречия и предлоги/связки",
    "иначе|иначе|Он то ради иначе.|Наречия и предлоги/связки",
    "ипак|всё же|Он то ради ипак.|Наречия и предлоги/связки",
    "међутим|однако|Он то ради међутим.|Наречия и предлоги/связки",
    "дакле|итак|Он то ради дакле.|Наречия и предлоги/связки",
    "наиме|а именно|Он то ради наиме.|Наречия и предлоги/связки",
    "осим|кроме|Он то ради осим.|Наречия и предлоги/связки",
    "уместо|вместо|Он то ради уместо.|Наречия и предлоги/связки",
    "током|в течение|Он то ради током.|Наречия и предлоги/связки",
    "због|из-за; ради|Он то ради због.|Наречия и предлоги/связки",
    "према|по отношению к; согласно|Он то ради према.|Наречия и предлоги/связки",
    "испод|под; ниже|Он то ради испод.|Наречия и предлоги/связки",
    "изнад|над; выше|Он то ради изнад.|Наречия и предлоги/связки",
    "унутар|внутри|Он то ради унутар.|Наречия и предлоги/связки",
    "ван|вне|Он то ради ван.|Наречия и предлоги/связки",
    "наспрам|напротив|Он то ради наспрам.|Наречия и предлоги/связки",
    "дуж|вдоль|Он то ради дуж.|Наречия и предлоги/связки",
    "седмица|неделя|Ово је седмица.|Время и количество",
    "деценија|десятилетие|Ово је деценија.|Время и количество",
    "век|век|Ово је век.|Время и количество",
    "календар|календарь|Ово је календар.|Время и количество",
    "период|период|Ово је период.|Время и количество",
    "тренутак|момент|Ово је тренутак.|Время и количество",
    "почетак|начало|Ово је почетак.|Время и количество",
    "крај|конец|Ово је крај.|Время и количество",
    "трајање|длительность|Ово је трајање.|Время и количество",
    "учесталост|частота|Ово је учесталост.|Время и количество",
    "количина|количество|Ово је количина.|Время и количество",
    "број|число|Ово је број.|Время и количество",
    "пар|пара; несколько|Ово је пар.|Время и количество",
    "неколико|несколько|Ово је неколико.|Время и количество",
    "мноштво|множество|Ово је мноштво.|Время и количество",
    "већина|большинство|Ово је већина.|Время и количество",
    "мањина|меньшинство|Ово је мањина.|Время и количество",
    "сваки пут|каждый раз|Ово је сваки пут.|Время и количество",
    "једном|один раз|Ово је једном.|Время и количество",
    "двапут|дважды|Ово је двапут.|Время и количество",
    "поново|снова|Ово је поново.|Время и количество",
    "роман|роман|Ово је роман.|Культура и досуг",
    "песма|песня; стихотворение|Ово је песма.|Культура и досуг",
    "стих|стих|Ово је стих.|Культура и досуг",
    "приповетка|рассказ|Ово је приповетка.|Культура и досуг",
    "прича|история; рассказ|Ово је прича.|Культура и досуг",
    "писац|писатель|Ово је писац.|Культура и досуг",
    "песник|поэт|Ово је песник.|Культура и досуг",
    "читалац|читатель|Ово је читалац.|Культура и досуг",
    "издавач|издатель|Ово је издавач.|Культура и досуг",
    "издање|издание|Ово је издање.|Культура и досуг",
    "наслов|заглавие|Ово је наслов.|Культура и досуг",
    "поглавље|глава книги|Ово је поглавље.|Культура и досуг",
    "страница књиге|страница книги|Ово је страница књиге.|Культура и досуг",
    "глумац|актёр|Ово је глумац.|Культура и досуг",
    "глумица|актриса|Ово је глумица.|Культура и досуг",
    "редитељ|режиссёр|Ово је редитељ.|Культура и досуг",
    "представа|спектакль|Ово је представа.|Культура и досуг",
    "филм|фильм|Ово је филм.|Культура и досуг",
    "серија|сериал|Ово је серија.|Культура и досуг",
    "епизода|эпизод|Ово је епизода.|Культура и досуг",
    "сценарио|сценарий|Ово је сценарио.|Культура и досуг",
    "музика|музыка|Ово је музика.|Культура и досуг",
    "музичар|музыкант|Ово је музичар.|Культура и досуг",
    "певач|певец|Ово је певач.|Культура и досуг",
    "певачица|певица|Ово је певачица.|Культура и досуг",
    "гитара|гитара|Ово је гитара.|Культура и досуг",
    "клавир|пианино|Ово је клавир.|Культура и досуг",
    "виолина|скрипка|Ово је виолина.|Культура и досуг",
    "бубањ|барабан|Ово је бубањ.|Культура и досуг",
    "позорница|сцена|Ово је позорница.|Культура и досуг",
    "публика|публика|Ово је публика.|Культура и досуг",
    "уметност|искусство|Ово је уметност.|Культура и досуг",
    "сликарство|живопись|Ово је сликарство.|Культура и досуг",
    "сликар|художник|Ово је сликар.|Культура и досуг",
    "слика|картина; изображение|Ово је слика.|Культура и досуг",
    "изложба|выставка|Ово је изложба.|Культура и досуг",
    "фотографија|фотография|Ово је фотографија.|Культура и досуг",
    "фотограф|фотограф|Ово је фотограф.|Культура и досуг",
    "камера|камера|Ово је камера.|Культура и досуг",
    "објектив|объектив|Ово је објектив.|Культура и досуг",
    "хоби|хобби|Ово је хоби.|Культура и досуг",
    "шетња|прогулка|Ово је шетња.|Культура и досуг",
    "планинарење|поход в горы|Ово је планинарење.|Культура и досуг",
    "риболов|рыбалка|Ово је риболов.|Культура и досуг",
    "башта|сад|Ово је башта.|Культура и досуг",
    "баштованство|садоводство|Ово је баштованство.|Культура и досуг",
    "кућни послови|домашние дела|Ово је кућни послови.|Культура и досуг",
    "друштвена игра|настольная игра|Ово је друштвена игра.|Культура и досуг",
    "шах|шахматы|Ово је шах.|Культура и досуг",
    "карта за игру|игральная карта|Ово је карта за игру.|Культура и досуг",
    "како сте?|как вы поживаете?|Како сте?.|Частые полезные фразы",
    "како си?|как ты?|Како си?.|Частые полезные фразы",
    "добро сам|у меня всё хорошо|Добро сам.|Частые полезные фразы",
    "нисам лоше|неплохо|Нисам лоше.|Частые полезные фразы",
    "како се каже?|как это сказать?|Како се каже?.|Частые полезные фразы",
    "шта то значи?|что это значит?|Шта то значи?.|Частые полезные фразы",
    "можете ли да поновите?|не могли бы вы повторить?|Можете ли да поновите?.|Частые полезные фразы",
    "говорите спорије|говорите медленнее|Говорите спорије.|Частые полезные фразы",
    "говорим мало српски|я немного говорю по-сербски|Говорим мало српски.|Частые полезные фразы",
    "учим српски|я учу сербский|Учим српски.|Частые полезные фразы",
    "како се пише?|как это пишется?|Како се пише?.|Частые полезные фразы",
    "можете ли да ми помогнете?|не могли бы вы мне помочь?|Можете ли да ми помогнете?.|Частые полезные фразы",
    "где је тоалет?|где туалет?|Где је тоалет?.|Частые полезные фразы",
    "колико кошта?|сколько стоит?|Колико кошта?.|Частые полезные фразы",
    "може ли картицом?|можно картой?|Може ли картицом?.|Частые полезные фразы",
    "плаћам готовином|я плачу наличными|Плаћам готовином.|Частые полезные фразы",
    "само гледам|я просто смотрю|Само гледам.|Частые полезные фразы",
    "тражим ово|я ищу это|Тражим ово.|Частые полезные фразы",
    "имате ли ово?|у вас есть это?|Имате ли ово?.|Частые полезные фразы",
    "желим ово|я хочу это|Желим ово.|Частые полезные фразы",
    "не треба, хвала|не нужно, спасибо|Не треба, хвала.|Частые полезные фразы",
    "може рачун?|можно счёт?|Може рачун?.|Частые полезные фразы",
    "без шећера|без сахара|Без шећера.|Частые полезные фразы",
    "без млека|без молока|Без млека.|Частые полезные фразы",
    "са собом|с собой|Са собом.|Частые полезные фразы",
    "овде, молим|здесь, пожалуйста|Овде, молим.|Частые полезные фразы",
    "за понети|на вынос|За понети.|Частые полезные фразы",
    "резервисано је|это забронировано|Резервисано је.|Частые полезные фразы",
    "имам резервацију|у меня бронь|Имам резервацију.|Частые полезные фразы",
    "касним мало|я немного опаздываю|Касним мало.|Частые полезные фразы",
    "видимо се касније|увидимся позже|Видимо се касније.|Частые полезные фразы",
    "чујемо се|будем на связи|Чујемо се.|Частые полезные фразы",
    "срећан пут|счастливого пути|Срећан пут.|Частые полезные фразы",
    "срећан рођендан|с днём рождения|Срећан рођендан.|Частые полезные фразы",
    "све најбоље|всего наилучшего|Све најбоље.|Частые полезные фразы",
    "нема проблема|нет проблем|Нема проблема.|Частые полезные фразы",
    "у реду је|всё в порядке|У реду је.|Частые полезные фразы",
    "није важно|неважно|Није важно.|Частые полезные фразы",
    "мислим да да|думаю, что да|Мислим да да.|Частые полезные фразы",
    "мислим да не|думаю, что нет|Мислим да не.|Частые полезные фразы",
    "можда касније|может быть, позже|Можда касније.|Частые полезные фразы",
    "свакако|обязательно; безусловно|Свакако.|Частые полезные фразы",
    "само тренутак|одну минуту|Само тренутак.|Частые полезные фразы",
    "чекајте мало|подождите немного|Чекајте мало.|Частые полезные фразы",
    "пазите!|осторожно!|Пазите!.|Частые полезные фразы",
    "помоћ!|помогите!|Помоћ!.|Частые полезные фразы",
    "зовите хитну помоћ|вызовите скорую помощь|Зовите хитну помоћ.|Частые полезные фразы",
    "изгубио сам се|я заблудился (муж.)|Изгубио сам се.|Частые полезные фразы",
    "изгубила сам се|я заблудилась (жен.)|Изгубила сам се.|Частые полезные фразы",
    "где могу да купим...|где я могу купить...|Где могу да купим....|Частые полезные фразы",
    "аутобус касни|автобус опаздывает|Аутобус касни.|Частые полезные фразы",
    "који је ваш број телефона?|какой у вас номер телефона?|Који је ваш број телефона?.|Частые полезные фразы",
    "можете ли да ми пошаљете поруку?|можете отправить мне сообщение?|Можете ли да ми пошаљете поруку?.|Частые полезные фразы",
    "немам интернет|у меня нет интернета|Немам интернет.|Частые полезные фразы",
    "батерија је празна|батарея разряжена|Батерија је празна.|Частые полезные фразы",
    "не ради|не работает|Не ради.|Частые полезные фразы",
    "ради добро|работает хорошо|Ради добро.|Частые полезные фразы",
    "захтев|заявление; запрос|Ово је захтев.|Цифровая повседневность и документы",
    "потврда|подтверждение; справка|Ово је потврда.|Цифровая повседневность и документы",
    "уверење|справка; удостоверение|Ово је уверење.|Цифровая повседневность и документы",
    "копија документа|копия документа|Ово је копија документа.|Цифровая повседневность и документы",
    "оригинал|оригинал|Ово је оригинал.|Цифровая повседневность и документы",
    "превод|перевод|Ово је превод.|Цифровая повседневность и документы",
    "судски тумач|судебный переводчик|Ово је судски тумач.|Цифровая повседневность и документы",
    "овера|заверение|Ово је овера.|Цифровая повседневность и документы",
    "нотар|нотариус|Ово је нотар.|Цифровая повседневность и документы",
    "адреса становања|адрес проживания|Ово је адреса становања.|Цифровая повседневность и документы",
    "пребивалиште|место постоянного проживания|Ово је пребивалиште.|Цифровая повседневность и документы",
    "боравиште|место временного пребывания|Ово је боравиште.|Цифровая повседневность и документы",
    "дозвола боравка|вид на жительство|Ово је дозвола боравка.|Цифровая повседневность и документы",
    "радна дозвола|разрешение на работу|Ово је радна дозвола.|Цифровая повседневность и документы",
    "држављанство|гражданство|Ово је држављанство.|Цифровая повседневность и документы",
    "странац|иностранец|Ово је странац.|Цифровая повседневность и документы",
    "пријава боравка|регистрация пребывания|Ово је пријава боравка.|Цифровая повседневность и документы",
    "порез|налог|Ово је порез.|Цифровая повседневность и документы",
    "пореска пријава|налоговая декларация|Ово је пореска пријава.|Цифровая повседневность и документы",
    "здравствено осигурање|медицинская страховка|Ово је здравствено осигурање.|Цифровая повседневность и документы",
    "пензијско осигурање|пенсионное страхование|Ово је пензијско осигурање.|Цифровая повседневность и документы",
    "уговор|договор|Ово је уговор.|Цифровая повседневность и документы",
    "станарина|арендная плата|Ово је станарина.|Цифровая повседневность и документы",
    "власник|владелец|Ово је власник.|Цифровая повседневность и документы",
    "закупац|арендатор|Ово је закупац.|Цифровая повседневность и документы",
    "изнајмљивање стана|аренда квартиры|Ово је изнајмљивање стана.|Цифровая повседневность и документы",
    "комуналије|коммунальные услуги|Ово су комуналије.|Цифровая повседневность и документы",
    "занимање|профессия; занятие|Ово је занимање.|Профессии и общество",
    "професија|профессия|Ово је професија.|Профессии и общество",
    "педагог|педагог|Ово је педагог.|Профессии и общество",
    "научник|учёный|Ово је научник.|Профессии и общество",
    "историчар|историк|Ово је историчар.|Профессии и общество",
    "биолог|биолог|Ово је биолог.|Профессии и общество",
    "инжењер|инженер|Ово је инжењер.|Профессии и общество",
    "електричар|электрик|Ово је електричар.|Профессии и общество",
    "водоинсталатер|сантехник|Ово је водоинсталатер.|Профессии и общество",
    "столар|столяр|Ово је столар.|Профессии и общество",
    "механичар|механик|Ово је механичар.|Профессии и общество",
    "пекар|пекарь|Ово је пекар.|Профессии и общество",
    "конобар|официант|Ово је конобар.|Профессии и общество",
    "конобарица|официантка|Ово је конобарица.|Профессии и общество",
    "чистач|уборщик|Ово је чистач.|Профессии и общество",
    "возач аутобуса|водитель автобуса|Ово је возач аутобуса.|Профессии и общество",
    "курир|курьер|Ово је курир.|Профессии и общество",
    "поштар|почтальон|Ово је поштар.|Профессии и общество",
    "новинар|журналист|Ово је новинар.|Профессии и общество",
    "уредник|редактор|Ово је уредник.|Профессии и общество",
    "програмер|программист|Ово је програмер.|Профессии и общество",
    "дизајнер|дизайнер|Ово је дизајнер.|Профессии и общество",
    "преводилац|переводчик|Ово је преводилац.|Профессии и общество",
    "тумач|устный переводчик|Ово је тумач.|Профессии и общество",
    "адвокат|адвокат|Ово је адвокат.|Профессии и общество",
    "судија|судья|Ово је судија.|Профессии и общество",
    "медицинар|медик|Ово је медицинар.|Профессии и общество",
    "ветеринар|ветеринар|Ово је ветеринар.|Профессии и общество",
    "пољопривредник|фермер|Ово је пољопривредник.|Профессии и общество",
    "радник|рабочий|Ово је радник.|Профессии и общество",
    "послодавац|работодатель|Ово је послодавац.|Профессии и общество",
    "запослени|сотрудник|Ово је запослени.|Профессии и общество",
    "незапослен|безработный|Ово је незапослен.|Профессии и общество",
    "пензионер|пенсионер|Ово је пензионер.|Профессии и общество",
    "волонтер|волонтёр|Ово је волонтер.|Профессии и общество",
    "удружење|общественная организация|Ово је удружење.|Профессии и общество",
    "заједница|сообщество|Ово је заједница.|Профессии и общество",
    "сусед|сосед|Ово је сусед.|Профессии и общество",
    "станар|житель дома; арендатор|Ово је станар.|Профессии и общество",
    "рођак|родственник|Ово је рођак.|Профессии и общество",
    "супружник|супруг|Ово је супружник.|Профессии и общество",
    "брак|брак|Ово је брак.|Профессии и общество",
    "венчање|свадьба; венчание|Ово је венчање.|Профессии и общество",
    "развод|развод|Ово је развод.|Профессии и общество",
    "расти|расти|Потребно је расти.|Глаголы",
    "опасти|упасть; снизиться|Потребно је опасти.|Глаголы",
    "порасти|вырасти|Потребно је порасти.|Глаголы",
    "зависити|зависеть|Потребно је зависити.|Глаголы",
    "доказати|доказать|Потребно је доказати.|Глаголы",
    "показати|показать|Потребно је показати.|Глаголы",
    "сакрити|спрятать|Потребно је сакрити.|Глаголы",
    "пронаћи|найти|Потребно је пронаћи.|Глаголы",
    "изгубити|потерять|Потребно је изгубити.|Глаголы",
    "препознати|узнать; распознать|Потребно је препознати.|Глаголы",
    "одредити|определить|Потребно је одредити.|Глаголы",
    "измерити|измерить|Потребно је измерити.|Глаголы",
    "израчунати|вычислить|Потребно је израчунати.|Глаголы",
    "решити|решить|Потребно је решити.|Глаголы",
    "предвидети|предвидеть|Потребно је предвидети.|Глаголы",
    "сазнати|узнать|Потребно је сазнати.|Глаголы",
    "истраживати|исследовать|Потребно је истраживати.|Глаголы",
    "посматрати|наблюдать|Потребно је посматрати.|Глаголы",
    "приметити|заметить|Потребно је приметити.|Глаголы",
    "пратити|следить; сопровождать|Потребно је пратити.|Глаголы",
    "појавити се|появиться|Потребно је појавити се.|Глаголы",
    "нестати|исчезнуть|Потребно је нестати.|Глаголы",
    "десити се|случиться|Потребно је десити се.|Глаголы",
    "настати|возникнуть|Потребно је настати.|Глаголы",
    "постојати|существовать|Потребно је постојати.|Глаголы",
    "припремати|готовить; подготавливать|Потребно је припремати.|Глаголы",
    "обухватити|охватить|Потребно је обухватити.|Глаголы",
    "обезбедити|обеспечить|Потребно је обезбедити.|Глаголы",
    "пружити|предоставить; протянуть|Потребно је пружити.|Глаголы",
    "захтевати|требовать|Потребно је захтевати.|Глаголы",
    "заслужити|заслужить|Потребно је заслужити.|Глаголы",
    "одговарати|отвечать; подходить|Потребно је одговарати.|Глаголы",
    "решавати|решать|Потребно је решавати.|Глаголы",
    "изгледати|выглядеть|Потребно је изгледати.|Глаголы",
    "деловати|казаться; действовать|Потребно је деловати.|Глаголы",
    "значити|значить|Потребно је значити.|Глаголы",
    "представљати|представлять|Потребно је представљати.|Глаголы",
    "укључивати|включать в себя|Потребно је укључивати.|Глаголы",
    "искључивати|исключать|Потребно је искључивати.|Глаголы",
    "омогућити|дать возможность|Потребно је омогућити.|Глаголы",
    "покушавати|пытаться|Потребно је покушавати.|Глаголы",
    "настављати|продолжать|Потребно је настављати.|Глаголы",
    "појачати|усилить|Потребно је појачати.|Глаголы",
    "ослабити|ослабить|Потребно је ослабити.|Глаголы",
    "променити се|измениться|Потребно је променити се.|Глаголы",
    "прилагодити се|адаптироваться|Потребно је прилагодити се.|Глаголы",
    "навикнути се|привыкнуть|Потребно је навикнути се.|Глаголы",
    "могућност|возможность|Ово је могућност.|Полезные существительные",
    "прилика|случай; возможность|Ово је прилика.|Полезные существительные",
    "избор|выбор|Ово је избор.|Полезные существительные",
    "одлука|решение|Ово је одлука.|Полезные существительные",
    "план|план|Ово је план.|Полезные существительные",
    "циљ|цель|Ово је циљ.|Полезные существительные",
    "успех|успех|Ово је успех.|Полезные существительные",
    "неуспех|неудача|Ово је неуспех.|Полезные существительные",
    "напредак|прогресс|Ово је напредак.|Полезные существительные",
    "промена|изменение|Ово је промена.|Полезные существительные",
    "развој|развитие|Ово је развој.|Полезные существительные",
    "утицај|влияние|Ово је утицај.|Полезные существительные",
    "узрок|причина|Ово је узрок.|Полезные существительные",
    "последица|последствие|Ово је последица.|Полезные существительные",
    "услов|условие|Ово је услов.|Полезные существительные",
    "правило|правило|Ово је правило.|Полезные существительные",
    "закон|закон|Ово је закон.|Полезные существительные",
    "дужност|обязанность|Ово је дужност.|Полезные существительные",
    "одговорност|ответственность|Ово је одговорност.|Полезные существительные",
    "слобода|свобода|Ово је слобода.|Полезные существительные",
    "једнакост|равенство|Ово је једнакост.|Полезные существительные",
    "друштво|общество|Ово је друштво.|Полезные существительные",
    "култура|культура|Ово је култура.|Полезные существительные",
    "историја|история|Ово је историја.|Полезные существительные",
    "наука|наука|Ово је наука.|Полезные существительные",
    "знање|знание|Ово је знање.|Полезные существительные",
    "образовање|образование|Ово је образовање.|Полезные существительные",
    "подаци|данные|Ово су подаци.|Полезные существительные",
    "информација|информация|Ово је информација.|Полезные существительные",
    "извор информација|источник информации|Ово је извор информација.|Полезные существительные",
    "доказ|доказательство|Ово је доказ.|Полезные существительные",
    "чињеница|факт|Ово је чињеница.|Полезные существительные",
    "закључак|вывод|Ово је закључак.|Полезные существительные",
    "сврха|цель; назначение|Ово је сврха.|Полезные существительные",
    "вредност|ценность|Ово је вредност.|Полезные существительные",
    "квалитет|качество|Ово је квалитет.|Полезные существительные",
    "ниво|уровень|Ово је ниво.|Полезные существительные",
    "степен|степень|Ово је степен.|Полезные существительные",
    "облик|форма|Ово је облик.|Полезные существительные",
    "врста|вид; тип|Ово је врста.|Полезные существительные",
    "начин|способ|Ово је начин.|Полезные существительные",
    "систем|система|Ово је систем.|Полезные существительные",
    "процес|процесс|Ово је процес.|Полезные существительные",
    "метод|метод|Ово је метод.|Полезные существительные",
    "средство|средство|Ово је средство.|Полезные существительные",
    "алат|инструмент|Ово је алат.|Полезные существительные",
    "опрема|оборудование|Ово је опрема.|Полезные существительные",
    "материјал|материал|Ово је материјал.|Полезные существительные",
    "производ|продукт; изделие|Ово је производ.|Полезные существительные",
    "услуга|услуга|Ово је услуга.|Полезные существительные",
    "понуда|предложение|Ово је понуда.|Полезные существительные",
    "потражња|спрос|Ово је потражња.|Полезные существительные",
    "какво је време?|какая погода?|Какво је време?.|Время, погода и город",
    "лепо је време|хорошая погода|Лепо је време.|Время, погода и город",
    "пада киша|идёт дождь|Пада киша.|Время, погода и город",
    "снег пада|идёт снег|Снег пада.|Время, погода и город",
    "дува ветар|дует ветер|Дува ветар.|Время, погода и город",
    "веома је хладно|очень холодно|Веома је хладно.|Время, погода и город",
    "веома је топло|очень тепло|Веома је топло.|Время, погода и город",
    "данас је облачно|сегодня облачно|Данас је облачно.|Время, погода и город",
    "сунчано је|солнечно|Сунчано је.|Время, погода и город",
    "магла је густа|густой туман|Магла је густа.|Время, погода и город",
    "имате ли ситно?|у вас есть мелочь?|Имате ли ситно?.|Покупки и бытовые фразы",
    "можете ли да ми вратите кусур?|можете дать сдачу?|Можете ли да ми вратите кусур?.|Покупки и бытовые фразы",
    "где је најближа апотека?|где ближайшая аптека?|Где је најближа апотека?.|Покупки и бытовые фразы",
    "где је најближи банкомат?|где ближайший банкомат?|Где је најближи банкомат?.|Покупки и бытовые фразы",
    "треба ми помоћ|мне нужна помощь|Треба ми помоћ.|Покупки и бытовые фразы",
    "не осећам се добро|я плохо себя чувствую|Не осећам се добро.|Покупки и бытовые фразы",
    "имам заказан термин|у меня назначен приём|Имам заказан термин.|Покупки и бытовые фразы",
    "боли ме глава|у меня болит голова|Боли ме глава.|Покупки и бытовые фразы",
    "боли ме стомак|у меня болит живот|Боли ме стомак.|Покупки и бытовые фразы",
    "алергичан сам на...|у меня аллергия на... (муж.)|Алергичан сам на....|Покупки и бытовые фразы",
    "алергична сам на...|у меня аллергия на... (жен.)|Алергична сам на....|Покупки и бытовые фразы",
    "без меса, молим|без мяса, пожалуйста|Без меса, молим.|Покупки и бытовые фразы",
    "да ли је љуто?|это острое?|Да ли је љуто?.|Покупки и бытовые фразы",
    "да ли садржи орахе?|это содержит орехи?|Да ли садржи орахе?.|Покупки и бытовые фразы",
    "вегетаријанско јело|вегетарианское блюдо|Вегетаријанско јело.|Покупки и бытовые фразы",
    "може чаша воде?|можно стакан воды?|Може чаша воде?.|Покупки и бытовые фразы",
    "где могу да напуним телефон?|где я могу зарядить телефон?|Где могу да напуним телефон?.|Покупки и бытовые фразы",
    "можете ли да ми помогнете да нађем адресу?|поможете найти адрес?|Можете ли да ми помогнете да нађем адресу?.|Покупки и бытовые фразы",
    "потребан ми је такси|мне нужно такси|Потребан ми је такси.|Покупки и бытовые фразы",
    "станите овде, молим|остановите здесь, пожалуйста|Станите овде, молим.|Покупки и бытовые фразы",
    "желим карту до Београда|я хочу билет до Белграда|Желим карту до Београда.|Покупки и бытовые фразы",
    "у ком правцу је центар?|в какой стороне центр?|У ком правцу је центар?.|Покупки и бытовые фразы",
    "колико траје пут?|сколько длится поездка?|Колико траје пут?.|Покупки и бытовые фразы",
    "да ли је далеко?|это далеко?|Да ли је далеко?.|Покупки и бытовые фразы",
    "могу ли да платим бесконтактно?|можно оплатить бесконтактно?|Могу ли да платим бесконтактно?.|Покупки и бытовые фразы",
    "можете ли да ми издате рачун?|можете выдать чек?|Можете ли да ми издате рачун?.|Покупки и бытовые фразы",
    "где могу да оставим пртљаг?|где можно оставить багаж?|Где могу да оставим пртљаг?.|Покупки и бытовые фразы",
    "имам једно питање|у меня один вопрос|Имам једно питање.|Покупки и бытовые фразы",
    "можете ли да говорите енглески?|вы говорите по-английски?|Можете ли да говорите енглески?.|Покупки и бытовые фразы",
    "не говорим добро српски|я плохо говорю по-сербски|Не говорим добро српски.|Покупки и бытовые фразы",
    "можете ли да напишете?|можете написать?|Можете ли да напишете?.|Покупки и бытовые фразы",
    "хвала на стрпљењу|спасибо за терпение|Хвала на стрпљењу.|Покупки и бытовые фразы",
    "бели лук|чеснок|Ово је бели лук.|More food/ingredients",
    "црни лук|репчатый лук|Ово је црни лук.|More food/ingredients",
    "млади лук|зелёный лук|Ово је млади лук.|More food/ingredients",
    "празилук|лук-порей|Ово је празилук.|More food/ingredients",
    "цвекла|свёкла|Ово је цвекла.|More food/ingredients",
    "купус|капуста|Ово је купус.|More food/ingredients",
    "карфиол|цветная капуста|Ово је карфиол.|More food/ingredients",
    "броколи|брокколи|Ово је броколи.|More food/ingredients",
    "спанаћ|шпинат|Ово је спанаћ.|More food/ingredients",
    "зелена салата|листовой салат|Ово је зелена салата.|More food/ingredients",
    "љута паприка|острый перец|Ово је љута паприка.|More food/ingredients",
    "батат|батат|Ово је батат.|More food/ingredients",
    "печурка|гриб|Ово је печурка.|More food/ingredients",
    "тиква|тыква|Ово је тиква.|More food/ingredients",
    "тиквица|кабачок|Ово је тиквица.|More food/ingredients",
    "патлиџан|баклажан|Ово је патлиџан.|More food/ingredients",
    "маслина|оливка|Ово је маслина.|More food/ingredients",
    "авокадо|авокадо|Ово је авокадо.|More food/ingredients",
    "лимета|лайм|Ово је лимета.|More food/ingredients",
    "мандарина|мандарин|Ово је мандарина.|More food/ingredients",
    "грејпфрут|грейпфрут|Ово је грејпфрут.|More food/ingredients",
    "бресква|персик|Ово је бресква.|More food/ingredients",
    "кајсија|абрикос|Ово је кајсија.|More food/ingredients",
    "шљива|слива|Ово је шљива.|More food/ingredients",
    "трешња|черешня|Ово је трешња.|More food/ingredients",
    "вишња|вишня|Ово је вишња.|More food/ingredients",
    "малина|малина|Ово су малина.|More food/ingredients",
    "купина|ежевика|Ово је купина.|More food/ingredients",
    "боровница|черника|Ово је боровница.|More food/ingredients",
    "лубеница|арбуз|Ово је лубеница.|More food/ingredients",
    "диња|дыня|Ово је диња.|More food/ingredients",
    "ананас|ананас|Ово је ананас.|More food/ingredients",
    "киви|киви|Ово је киви.|More food/ingredients",
    "манго|манго|Ово је манго.|More food/ingredients",
    "нар|гранат|Ово је нар.|More food/ingredients",
    "обућа|обувь|Ово је обућа.|Clothes and appearance",
    "блуза|блузка|Ово је блуза.|Clothes and appearance",
    "дуксерица|толстовка|Ово је дуксерица.|Clothes and appearance",
    "кишни мантил|плащ|Ово је кишни мантил.|Clothes and appearance",
    "шортс|шорты|Ово је шортс.|Clothes and appearance",
    "одело|костюм|Ово је одело.|Clothes and appearance",
    "пиџама|пижама|Ово је пиџама.|Clothes and appearance",
    "сандале|сандалии|Ово су сандале.|Clothes and appearance",
    "папуче|тапочки|Ово су папуче.|Clothes and appearance",
    "шал|шарф|Ово је шал.|Clothes and appearance",
    "качкет|кепка|Ово је качкет.|Clothes and appearance",
    "каиш|ремень|Ово је каиш.|Clothes and appearance",
    "новчаник|кошелёк|Ово је новчаник.|Clothes and appearance",
    "наочаре|очки|Ово су наочаре.|Clothes and appearance",
    "сунчане наочаре|солнцезащитные очки|Ово су сунчане наочаре.|Clothes and appearance",
    "накит|украшения|Ово је накит.|Clothes and appearance",
    "прстен|кольцо|Ово је прстен.|Clothes and appearance",
    "огрлица|ожерелье|Ово је огрлица.|Clothes and appearance",
    "наруквица|браслет|Ово је наруквица.|Clothes and appearance",
    "минђуше|серьги|Ово су минђуше.|Clothes and appearance",
    "пробање|примерка|Ово је пробање.|Clothes and appearance",
    "свлачионица|примерочная|Ово је свлачионица.|Clothes and appearance",
    "влажан|влажный|Он је влажан.|More common adjectives",
    "сув|сухой|Он је сув.|More common adjectives",
    "мокар|мокрый|Он је мокар.|More common adjectives",
    "слан|солёный|Он је слан.|More common adjectives",
    "горак|горький|Он је горак.|More common adjectives",
    "зрео|спелый|Он је зрео.|More common adjectives",
    "незрео|незрелый|Он је незрео.|More common adjectives",
    "мекан|мягкий|Он је мекан.|More common adjectives",
    "хрскав|хрустящий|Он је хрскав.|More common adjectives",
    "масан|жирный|Он је масан.|More common adjectives",
    "немасан|нежирный|Он је немасан.|More common adjectives",
    "нездрав|нездоровый|Он је нездрав.|More common adjectives",
    "свакодневни|повседневный|Он је свакодневни.|More common adjectives",
    "недељни|еженедельный|Он је недељни.|More common adjectives",
    "месечни|ежемесячный|Он је месечни.|More common adjectives",
    "годишњи|ежегодный|Он је годишњи.|More common adjectives",
    "локалан|местный|Он је локалан.|More common adjectives",
    "међународни|международный|Он је међународни.|More common adjectives",
    "домаћи|домашний; отечественный|Он је домаћи.|More common adjectives",
    "страни|иностранный|Он је страни.|More common adjectives",
    "јавни|общественный; публичный|Он је јавни.|More common adjectives",
    "приватни|частный|Он је приватни.|More common adjectives",
    "лични|личный|Он је лични.|More common adjectives",
    "званичан|официальный|Он је званичан.|More common adjectives",
    "незваничан|неофициальный|Он је незваничан.|More common adjectives",
    "планета|планета|Ово је планета.|More animals/nature",
    "свемир|космос|Ово је свемир.|More animals/nature",
    "звезда|звезда|Ово је звезда.|More animals/nature",
    "сунчева светлост|солнечный свет|Ово је сунчева светлост.|More animals/nature",
    "сенка|тень|Ово је сенка.|More animals/nature",
    "роса|роса|Ово је роса.|More animals/nature",
    "земљотрес|землетрясение|Ово је земљотрес.|More animals/nature",
    "вулкан|вулкан|Ово је вулкан.|More animals/nature",
    "глечер|ледник|Ово је глечер.|More animals/nature",
    "пећина|пещера|Ово је пећина.|More animals/nature",
    "мочвара|болото|Ово је мочвара.|More animals/nature",
    "ливада|луг|Ово је ливада.|More animals/nature",
    "поље|поле|Ово је поље.|More animals/nature",
    "усев|урожай; посев|Ово је усев.|More animals/nature",
    "жетва|жатва|Ово је жетва.|More animals/nature",
    "семенка|семечко|Ово је семенка.|More animals/nature",
    "ручати|обедать|Желим да ручати.|Действия с едой",
    "вечерати|ужинать|Желим да вечерати.|Действия с едой",
    "грицкати|перекусывать; грызть|Желим да грицкати.|Действия с едой",
    "гутати|глотать|Желим да гутати.|Действия с едой",
    "жвакати|жевать|Желим да жвакати.|Действия с едой",
    "зачинити|приправить|Желим да зачинити.|Действия с едой",
    "посолити|посолить|Желим да посолити.|Действия с едой",
    "засладити|подсластить|Желим да засладити.|Действия с едой",
    "охладити|охладить|Желим да охладити.|Действия с едой",
    "замрзнути|заморозить; замёрзнуть|Желим да замрзнути.|Действия с едой",
    "одмрзнути|разморозить|Желим да одмрзнути.|Действия с едой",
    "подгрејати|подогреть|Желим да подгрејати.|Действия с едой",
    "прокувати|вскипятить|Желим да прокувати.|Действия с едой",
    "исцедити|выжать; процедить|Желим да исцедити.|Действия с едой",
    "исецкати|нарезать|Желим да исецкати.|Действия с едой",
    "изрендати|натереть на тёрке|Желим да изрендати.|Действия с едой",
    "огулити|очистить от кожуры|Желим да огулити.|Действия с едой",
    "сервирати|сервировать|Желим да сервирати.|Действия с едой",
    "по мом мишљењу|по моему мнению|По мом мишљењу.|Common connectors and speech",
    "ако сам добро разумео|если я правильно понял (муж.)|Ако сам добро разумео.|Common connectors and speech",
    "ако сам добро разумела|если я правильно поняла (жен.)|Ако сам добро разумела.|Common connectors and speech",
    "колико ја знам|насколько я знаю|Колико ја знам.|Common connectors and speech",
    "с једне стране|с одной стороны|С једне стране.|Common connectors and speech",
    "с друге стране|с другой стороны|С друге стране.|Common connectors and speech",
    "у ствари|на самом деле|У ствари.|Common connectors and speech",
    "у сваком случају|в любом случае|У сваком случају.|Common connectors and speech",
    "зависи од ситуације|зависит от ситуации|Зависи од ситуације.|Common connectors and speech",
    "нема смисла|нет смысла|Нема смисла.|Common connectors and speech",
    "то има смисла|это имеет смысл|То има смисла.|Common connectors and speech",
    "није сигурно|неизвестно; не точно|Није сигурно.|Common connectors and speech",
    "сигуран сам|я уверен (муж.)|Сигуран сам.|Common connectors and speech",
    "сигурна сам|я уверена (жен.)|Сигурна сам.|Common connectors and speech",
    "нисам сигуран|я не уверен (муж.)|Нисам сигуран.|Common connectors and speech",
    "нисам сигурна|я не уверена (жен.)|Нисам сигурна.|Common connectors and speech",
    "колико год је могуће|насколько возможно|Колико год је могуће.|Common connectors and speech",
    "то је добра идеја|это хорошая идея|То је добра идеја.|Common connectors and speech",
    "имаш право|ты прав|Имаш право.|Common connectors and speech",
    "у праву сте|вы правы|У праву сте.|Common connectors and speech",
    "све зависи|всё зависит|Све зависи.|Common connectors and speech",
    "немам појма|понятия не имею|Немам појма.|Common connectors and speech",
    "не могу да се сетим|не могу вспомнить|Не могу да се сетим.|Common connectors and speech",
    "сад ми је јасно|теперь мне понятно|Сад ми је јасно.|Common connectors and speech",
    "то ми је познато|мне это знакомо|То ми је познато.|Common connectors and speech",
    "нисам чуо за то|я об этом не слышал (муж.)|Нисам чуо за то.|Common connectors and speech",
    "нисам чула за то|я об этом не слышала (жен.)|Нисам чула за то.|Common connectors and speech",
    "можда грешим|возможно, я ошибаюсь|Можда грешим.|Common connectors and speech",
    "погрешио сам|я ошибся (муж.)|Погрешио сам.|Common connectors and speech",
    "погрешила сам|я ошиблась (жен.)|Погрешила сам.|Common connectors and speech",
    "немојте да бринете|не беспокойтесь|Немојте да бринете.|Common connectors and speech",
    "све ће бити у реду|всё будет хорошо|Све ће бити у реду.|Common connectors and speech"
).map { line ->
    val p = line.split('|')
    DictionaryEntry(p[0], p[1], p[2], p[3])
}.distinctBy { it.serbian.lowercase() }

private fun cyrillicToLatin(text: String): String {
    val map = mapOf('а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'ђ' to "đ", 'е' to "e", 'ж' to "ž", 'з' to "z", 'и' to "i", 'ј' to "j", 'к' to "k", 'л' to "l", 'љ' to "lj", 'м' to "m", 'н' to "n", 'њ' to "nj", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'ћ' to "ć", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "c", 'ч' to "č", 'џ' to "dž", 'ш' to "š")
    return buildString { text.forEach { ch -> append(map[ch.lowercaseChar()]?.let { if (ch.isUpperCase()) it.replaceFirstChar(Char::uppercase) else it } ?: ch) } }
}

@Composable
private fun DictionaryScreen(
    decks: List<StudyDeck>, language: String, query: String, onQuery: (String) -> Unit,
    onAddWord: (String, DictionaryEntry) -> Unit, onCreateSetAndAdd: (DictionaryEntry) -> Unit
) {
    var mode by remember { mutableStateOf(0) }
    var targetDeckId by remember(decks) { mutableStateOf(decks.firstOrNull()?.id) }
    var expanded by remember { mutableStateOf(false) }
    val q = query.trim().lowercase()
    val cardResults = decks.flatMap { d -> d.cards.map { c -> Triple(d, c, "${c.front} ${c.back} ${c.note} ${cyrillicToLatin(c.front)}") } }
        .filter { q.isEmpty() || it.third.lowercase().contains(q) }
        .take(100)
    val dictionaryResults = offlineSerbianDictionary.filter { e ->
        q.isEmpty() || e.serbian.lowercase().contains(q) || cyrillicToLatin(e.serbian).lowercase().contains(q) || e.russian.lowercase().contains(q) || e.example.lowercase().contains(q) || cyrillicToLatin(e.example).lowercase().contains(q) || e.category.lowercase().contains(q)
    }.take(150)
    Column(Modifier.fillMaxSize()) {
        BrandHeader(language, tx(language, "dictionary_subtitle"))
        Text(tx(language, "dictionary_title"), fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 20.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), placeholder = { Text(tx(language, "dictionary_search_hint")) }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) }, trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { onQuery("") }) { Icon(Icons.Filled.Close, null) } }, shape = RoundedCornerShape(18.dp), singleLine = true, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFFE3EAE2), focusedBorderColor = Green))
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text(tx(language, "my_cards_search")) }, leadingIcon = { Icon(Icons.Filled.Search, null, modifier = Modifier.size(17.dp)) })
            FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text(tx(language, "offline_dictionary")) }, leadingIcon = { Icon(Icons.Filled.MenuBook, null, modifier = Modifier.size(17.dp)) })
        }
        if (mode == 0) {
            Text("${cardResults.size} ${tx(language, "search_results")}", fontSize = 12.sp, color = Muted, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
            if (cardResults.isEmpty()) EmptyState(language, tx(language, "nothing_here"), tx(language, "search_cards_hint"), Icons.Filled.Search)
            else LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
                items(cardResults, key = { "${it.first.id}:${it.second.id}" }) { (deck, card, _) ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp).clip(RoundedCornerShape(17.dp)).background(Color.White).padding(14.dp)) {
                        Text(card.front, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(card.back, fontSize = 14.sp, color = DeepGreen, modifier = Modifier.padding(top = 3.dp))
                        if (card.note.isNotBlank()) Text(card.note, fontSize = 12.sp, color = Muted, modifier = Modifier.padding(top = 4.dp))
                        Text(deck.title, fontSize = 11.sp, color = Muted, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${offlineSerbianDictionary.size} ${tx(language, "dictionary_words")}", fontSize = 12.sp, color = Muted, modifier = Modifier.weight(1f))
                Box {
                    OutlinedButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)) {
                        Text(decks.firstOrNull { it.id == targetDeckId }?.title ?: tx(language, "choose_set"), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                        Icon(Icons.Filled.ArrowDropDown, null)
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        decks.forEach { deck -> DropdownMenuItem(text = { Text(deck.title) }, onClick = { targetDeckId = deck.id; expanded = false }) }
                    }
                }
            }
            if (dictionaryResults.isEmpty()) EmptyState(language, tx(language, "nothing_here"), tx(language, "search_dictionary_hint"), Icons.Filled.MenuBook)
            else LazyColumn(contentPadding = PaddingValues(bottom = 18.dp)) {
                items(dictionaryResults, key = { it.serbian }) { entry ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Color.White).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text(entry.serbian, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = DeepGreen)
                                Text(cyrillicToLatin(entry.serbian), fontSize = 12.sp, color = Muted)
                                Text(entry.russian, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 5.dp))
                            }
                            Text(entry.category, fontSize = 10.sp, color = DeepGreen, modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(Mint).padding(horizontal = 7.dp, vertical = 4.dp))
                        }
                        Text(entry.example, fontSize = 13.sp, modifier = Modifier.padding(top = 9.dp))
                        Text(cyrillicToLatin(entry.example), fontSize = 12.sp, color = Muted)
                        Row(Modifier.fillMaxWidth().padding(top = 9.dp), horizontalArrangement = Arrangement.End) {
                            FilledTonalButton(onClick = { if (targetDeckId != null) onAddWord(targetDeckId!!, entry) else onCreateSetAndAdd(entry) }) {
                                Icon(Icons.Filled.Add, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(5.dp)); Text(tx(language, "add_to_set"))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressScreen(decks: List<StudyDeck>, language: String) {
    val total = decks.sumOf { it.cards.size }
    val learned = decks.sumOf { d -> d.cards.count { it.learned } }
    val percent = if (total == 0) 0 else learned * 100 / total
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            BrandHeader(language, tx(language, "your_progress"))
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(tx(language, "progress"), fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(tx(language, "progress_subtitle"), color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(27.dp)).background(DeepGreen).padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(language, "overall_progress"), color = Color.White.copy(alpha = .8f), fontSize = 13.sp)
                            Text("$percent%", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
                            Text("$learned ${tx(language, "of_words")} $total", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                        }
                        Box(Modifier.size(84.dp).clip(CircleShape).background(Color.White.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.TrendingUp, null, tint = Color.White, modifier = Modifier.size(42.dp)) }
                    }
                }
                Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatPill(Modifier.weight(1f), Icons.Filled.CollectionsBookmark, decks.size.toString(), tx(language, "sets"), Purple)
                    StatPill(Modifier.weight(1f), Icons.Filled.Style, total.toString(), tx(language, "cards"), Orange)
                    StatPill(Modifier.weight(1f), Icons.Filled.CheckCircle, learned.toString(), tx(language, "known"), Green)
                }
                val errorsCount = decks.sumOf { d -> d.cards.count { it.needsReview } }
                if (errorsCount > 0) Text("${tx(language, "mistakes_folder")}: $errorsCount", color = Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                Text(tx(language, "by_set"), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 25.dp, bottom = 8.dp))
            }
        }
        items(decks, key = { it.id }) { deck ->
            val count = deck.cards.count { it.learned }
            val progress = if (deck.cards.isEmpty()) 0f else count.toFloat() / deck.cards.size
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(19.dp)).background(Color.White).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(deck.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${(progress * 100).toInt()}%", color = DeepGreen, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(7.dp).clip(CircleShape), color = Color(deck.color), trackColor = Color(deck.color).copy(alpha = .13f))
                Text("$count ${tx(language, "of_words")} ${deck.cards.size}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
            }
        }
    }
}

@Composable
private fun SettingsScreen(language: String, onLanguage: (String) -> Unit, onImport: () -> Unit, onExport: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader(language, tx(language, "settings"))
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text(tx(language, "settings"), fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(tx(language, "personalize"), color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
            Text(tx(language, "interface_language"), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 9.dp))
            listOf("ru" to "🇷🇺 Русский", "en" to "🇬🇧 English", "sr" to "🇷🇸 Српски").forEach { (code, title) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { onLanguage(code) }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, modifier = Modifier.weight(1f), fontWeight = if (language == code) FontWeight.Bold else FontWeight.Medium)
                    if (language == code) Icon(Icons.Filled.CheckCircle, null, tint = Green)
                }
            }
            Text(tx(language, "data_backup"), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 8.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Color.White).clickable(onClick = onImport).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Mint), contentAlignment = Alignment.Center) { Icon(Icons.Filled.FileUpload, null, tint = DeepGreen) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(tx(language, "import_csv"), fontWeight = FontWeight.Bold); Text(tx(language, "import_hint"), fontSize = 12.sp, color = Muted) }
                Icon(Icons.Filled.ChevronRight, null, tint = Muted)
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(17.dp)).background(Color.White).clickable(onClick = onExport).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFFFF0D8)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.FileDownload, null, tint = Color(0xFFB87813)) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(tx(language, "export_csv"), fontWeight = FontWeight.Bold); Text(tx(language, "export_hint"), fontSize = 12.sp, color = Muted) }
                Icon(Icons.Filled.ChevronRight, null, tint = Muted)
            }
            Text("Leksi 1.0.0", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 28.dp))
            Text(tx(language, "offline_note"), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun EmptyState(language: String, title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 34.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green, modifier = Modifier.size(32.dp)) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 14.dp))
        Text(subtitle, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, initial: String = "", confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember(title, initial) { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)) }, confirmButton = { TextButton(onClick = { onConfirm(value) }, enabled = value.isNotBlank()) { Text(confirm, color = DeepGreen) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun CardEditorDialog(card: StudyCard?, language: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var front by remember(card?.id) { mutableStateOf(card?.front ?: "") }
    var back by remember(card?.id) { mutableStateOf(card?.back ?: "") }
    var note by remember(card?.id) { mutableStateOf(card?.note ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (card == null) tx(language, "new_card") else tx(language, "edit_card")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(front, { front = it }, label = { Text(tx(language, "front_side")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(back, { back = it }, label = { Text(tx(language, "back_side")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text(tx(language, "note_optional")) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(front, back, note) }, enabled = front.isNotBlank() && back.isNotBlank()) { Text(tx(language, "save"), color = DeepGreen) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "cancel")) } }
    )
}

private fun modeLabel(language: String, mode: StudyMode): String = when (mode) {
    StudyMode.DAILY -> tx(language, "daily_challenge")
    StudyMode.CARDS -> tx(language, "flashcards")
    StudyMode.TEST -> tx(language, "test")
    StudyMode.WRITE -> tx(language, "write_answer")
    StudyMode.MATCH -> tx(language, "matching")
}

private fun tx(lang: String, key: String): String {
    val ru = mapOf(
        "home" to "Главная", "sets" to "Наборы", "progress" to "Прогресс", "settings" to "Настройки", "dictionary" to "Словарь", "dictionary_title" to "Словарь сербского", "dictionary_subtitle" to "Ищи слова и добавляй их в наборы", "dictionary_search_hint" to "Сербское слово, латиница или перевод…", "my_cards_search" to "Мои карточки", "offline_dictionary" to "Офлайн-словарь", "search_results" to "результатов", "search_cards_hint" to "Попробуй другое слово или перевод", "search_dictionary_hint" to "Попробуй поискать по-сербски или по-русски", "dictionary_words" to "слов в словаре", "choose_set" to "Выбрать набор", "add_to_set" to "В набор", "word_added" to "Добавлено", "word_exists" to "Это слово уже есть в наборе", "dictionary_set" to "Сербский: слова из словаря", "learn_play" to "Учись играя", "hello" to "Привет! 👋", "small_steps" to "Немного каждый день — большой результат.", "ready_today" to "ТВОЙ ШАГ НА СЕГОДНЯ", "little_every_day" to "5 минут — и ты ближе к цели", "cards_learned" to "карточек уже освоено", "start" to "Начать", "daily_challenge" to "5 минут — и ты ближе к цели", "daily_subtitle" to "20 случайных заданий: карточки, тест, ввод и пары", "daily_step" to "ЗАДАНИЕ", "pair_game" to "Найди пару", "cards" to "Карточки", "known" to "Знаю", "mistakes_folder" to "Работа над ошибками", "mastery_label" to "Уровень знания", "your_sets" to "Твои наборы", "see_all" to "Все", "no_sets" to "Пока пусто", "make_first_set" to "Создай первый набор в разделе «Наборы»", "your_library" to "Твоя библиотека", "search_sets" to "Найти набор…", "nothing_here" to "Ничего не найдено", "create_or_search" to "Создай набор или измени поиск", "new_set" to "Новый набор", "set_name" to "Название набора", "create" to "Создать", "study_set" to "НАБОР ДЛЯ ОБУЧЕНИЯ", "cards_small" to "карточек", "known_small" to "знаю", "start_learning" to "Учить", "practice_modes" to "Режимы тренировки", "flashcards" to "Карточки", "test" to "Тест", "write_answer" to "Ввод ответа", "matching" to "Пары", "cards_in_set" to "Карточки набора", "add_card" to "Добавить", "empty_set" to "В этом наборе пока нет карточек", "add_first_card" to "Добавь первую карточку кнопкой выше", "rename_set" to "Переименовать набор", "set_color" to "Выбери цвет набора", "save" to "Сохранить", "delete_set" to "Удалить набор?", "delete_set_warning" to "Все карточки этого набора будут удалены. Это действие нельзя отменить.", "delete" to "Удалить", "cancel" to "Отмена", "tap_to_reveal" to "Вспомни ответ, прежде чем открыть карточку", "answer" to "ОТВЕТ", "question" to "ВОПРОС", "tap_card" to "Нажми, чтобы перевернуть", "show_answer" to "Показать ответ", "again" to "Не помню", "know_it" to "Уже знаю", "session_done" to "Отличная работа!", "keep_it_up" to "Каждая повторённая карточка приближает тебя к цели.", "finish" to "Завершить", "choose_translation" to "Выбери правильный перевод", "correct" to "Верно! Отлично!", "incorrect" to "Не совсем. Правильный ответ:", "next" to "Далее", "type_translation" to "Напиши ответ самостоятельно", "your_answer" to "Твой ответ…", "correct_answer" to "Правильный ответ", "check_answer" to "Проверить", "match_instruction" to "Соедини слово слева с его переводом справа.", "your_progress" to "Как идут занятия", "progress_subtitle" to "Маленькие победы складываются в большой прогресс.", "overall_progress" to "ОБЩИЙ ПРОГРЕСС", "of_words" to "из", "by_set" to "Прогресс по наборам", "personalize" to "Настрой приложение под себя.", "interface_language" to "Язык интерфейса", "data_backup" to "Импорт и резервная копия", "import_csv" to "Импортировать CSV", "import_hint" to "Добавить карточки из таблицы", "export_csv" to "Экспортировать CSV", "export_hint" to "Сохранить все наборы и карточки", "offline_note" to "Работает офлайн. Твои данные остаются на устройстве.", "new_card" to "Новая карточка", "edit_card" to "Изменить карточку", "front_side" to "Вопрос / слово", "back_side" to "Ответ / перевод", "note_optional" to "Подсказка (необязательно)", "notice" to "Готово", "ok" to "ОК", "imported" to "Импортировано наборов/карточек", "nothing_imported" to "В файле не найдено карточек", "import_error" to "Не удалось импортировать файл", "exported" to "Резервная копия сохранена", "export_error" to "Не удалось сохранить файл"
    )
    val en = mapOf(
        "home" to "Home", "sets" to "Sets", "progress" to "Progress", "settings" to "Settings", "dictionary" to "Dictionary", "dictionary_title" to "Serbian dictionary", "dictionary_subtitle" to "Search words and add them to sets", "dictionary_search_hint" to "Serbian, Latin spelling, or translation…", "my_cards_search" to "My cards", "offline_dictionary" to "Offline dictionary", "search_results" to "results", "search_cards_hint" to "Try another word or translation", "search_dictionary_hint" to "Search in Serbian or Russian", "dictionary_words" to "dictionary entries", "choose_set" to "Choose a set", "add_to_set" to "Add to set", "word_added" to "Added", "word_exists" to "This word is already in the set", "dictionary_set" to "Serbian: dictionary words", "learn_play" to "Learn by playing", "hello" to "Hey there! 👋", "small_steps" to "A little every day adds up.", "ready_today" to "YOUR DAILY STEP", "little_every_day" to "5 minutes closer to your goal", "cards_learned" to "cards learned", "start" to "Start", "daily_challenge" to "5 minutes closer to your goal", "daily_subtitle" to "20 random challenges: cards, quiz, typing and pairs", "daily_step" to "CHALLENGE", "pair_game" to "Find the pair", "cards" to "Cards", "known" to "Known", "mistakes_folder" to "Review mistakes", "mastery_label" to "Mastery", "your_sets" to "Your sets", "see_all" to "See all", "no_sets" to "Nothing here yet", "make_first_set" to "Create your first set in the Sets tab", "your_library" to "Your library", "search_sets" to "Search sets…", "nothing_here" to "Nothing found", "create_or_search" to "Create a set or change your search", "new_set" to "New set", "set_name" to "Set name", "create" to "Create", "study_set" to "STUDY SET", "cards_small" to "cards", "known_small" to "known", "start_learning" to "Study", "practice_modes" to "Practice modes", "flashcards" to "Flashcards", "test" to "Test", "write_answer" to "Type answer", "matching" to "Match pairs", "cards_in_set" to "Cards in this set", "add_card" to "Add", "empty_set" to "This set has no cards yet", "add_first_card" to "Add your first card above", "rename_set" to "Rename set", "set_color" to "Choose set color", "save" to "Save", "delete_set" to "Delete set?", "delete_set_warning" to "All cards in this set will be deleted. This cannot be undone.", "delete" to "Delete", "cancel" to "Cancel", "tap_to_reveal" to "Try to remember before revealing", "answer" to "ANSWER", "question" to "QUESTION", "tap_card" to "Tap to flip", "show_answer" to "Show answer", "again" to "Not yet", "know_it" to "I know it", "session_done" to "Great work!", "keep_it_up" to "Every review brings you closer to your goal.", "finish" to "Finish", "choose_translation" to "Choose the correct answer", "correct" to "Correct! Nice work!", "incorrect" to "Not quite. Correct answer:", "next" to "Next", "type_translation" to "Type the answer yourself", "your_answer" to "Your answer…", "correct_answer" to "Correct answer", "check_answer" to "Check answer", "match_instruction" to "Match each word on the left with its translation.", "your_progress" to "Your learning journey", "progress_subtitle" to "Small wins add up to real progress.", "overall_progress" to "OVERALL PROGRESS", "of_words" to "of", "by_set" to "Progress by set", "personalize" to "Make the app yours.", "interface_language" to "Interface language", "data_backup" to "Import & backup", "import_csv" to "Import CSV", "import_hint" to "Add cards from a spreadsheet", "export_csv" to "Export CSV", "export_hint" to "Save all sets and cards", "offline_note" to "Works offline. Your data stays on your device.", "new_card" to "New card", "edit_card" to "Edit card", "front_side" to "Question / word", "back_side" to "Answer / translation", "note_optional" to "Hint (optional)", "notice" to "Done", "ok" to "OK", "imported" to "Imported cards", "nothing_imported" to "No cards found in the file", "import_error" to "Could not import this file", "exported" to "Backup saved", "export_error" to "Could not save the file"
    )
    val sr = mapOf(
        "home" to "Почетна", "sets" to "Сетови", "progress" to "Напредак", "settings" to "Подешавања", "dictionary" to "Речник", "dictionary_title" to "Речник српског", "dictionary_subtitle" to "Тражи речи и додај их у сетове", "dictionary_search_hint" to "Српска реч, латиница или превод…", "my_cards_search" to "Моје картице", "offline_dictionary" to "Речник ван мреже", "search_results" to "резултата", "search_cards_hint" to "Пробај другу реч или превод", "search_dictionary_hint" to "Претражи на српском или руском", "dictionary_words" to "речи у речнику", "choose_set" to "Изабери сет", "add_to_set" to "Додај у сет", "word_added" to "Додато", "word_exists" to "Ова реч је већ у сету", "dictionary_set" to "Српски: речи из речника", "learn_play" to "Учи кроз игру", "hello" to "Здраво! 👋", "small_steps" to "Мало сваког дана доноси много.", "ready_today" to "ТВОЈ ДНЕВНИ КОРАК", "little_every_day" to "5 минута ближе циљу", "cards_learned" to "научених картица", "start" to "Почни", "daily_challenge" to "5 минута ближе циљу", "daily_subtitle" to "20 насумичних задатака: картице, тест, унос и парови", "daily_step" to "ЗАДАТАК", "pair_game" to "Пронађи пар", "cards" to "Картице", "known" to "Знам", "mistakes_folder" to "Рад на грешкама", "mastery_label" to "Ниво знања", "your_sets" to "Твоји сетови", "see_all" to "Сви", "no_sets" to "Још нема ничега", "make_first_set" to "Направи први сет у одељку Сетови", "your_library" to "Твоја библиотека", "search_sets" to "Претражи сетове…", "nothing_here" to "Ништа није пронађено", "create_or_search" to "Направи сет или промени претрагу", "new_set" to "Нови сет", "set_name" to "Назив сета", "create" to "Направи", "study_set" to "СЕТ ЗА УЧЕЊЕ", "cards_small" to "картица", "known_small" to "знам", "start_learning" to "Учи", "practice_modes" to "Начини вежбања", "flashcards" to "Картице", "test" to "Тест", "write_answer" to "Унеси одговор", "matching" to "Спари парове", "cards_in_set" to "Картице у сету", "add_card" to "Додај", "empty_set" to "Овај сет још нема картица", "add_first_card" to "Додај прву картицу изнад", "rename_set" to "Преименуј сет", "set_color" to "Изабери боју сета", "save" to "Сачувај", "delete_set" to "Обриши сет?", "delete_set_warning" to "Све картице из овог сета биће обрисане.", "delete" to "Обриши", "cancel" to "Откажи", "tap_to_reveal" to "Покушај да се сетиш пре откривања", "answer" to "ОДГОВОР", "question" to "ПИТАЊЕ", "tap_card" to "Додирни да окренеш", "show_answer" to "Прикажи одговор", "again" to "Не знам", "know_it" to "Знам", "session_done" to "Одличан посао!", "keep_it_up" to "Свако понављање те приближава циљу.", "finish" to "Заврши", "choose_translation" to "Изабери тачан одговор", "correct" to "Тачно! Браво!", "incorrect" to "Није сасвим. Тачан одговор:", "next" to "Даље", "type_translation" to "Самостално упиши одговор", "your_answer" to "Твој одговор…", "correct_answer" to "Тачан одговор", "check_answer" to "Провери", "match_instruction" to "Повежи реч са леве стране са преводом.", "your_progress" to "Твој напредак", "progress_subtitle" to "Мале победе доносе велики напредак.", "overall_progress" to "УКУПАН НАПРЕДАК", "of_words" to "од", "by_set" to "Напредак по сетовима", "personalize" to "Прилагоди апликацију себи.", "interface_language" to "Језик интерфејса", "data_backup" to "Увоз и резервна копија", "import_csv" to "Увези CSV", "import_hint" to "Додај картице из табеле", "export_csv" to "Извези CSV", "export_hint" to "Сачувај све сетове и картице", "offline_note" to "Ради без интернета. Подаци остају на уређају.", "new_card" to "Нова картица", "edit_card" to "Измени картицу", "front_side" to "Питање / реч", "back_side" to "Одговор / превод", "note_optional" to "Напомена (опционо)", "notice" to "Готово", "ok" to "У реду", "imported" to "Увезене картице", "nothing_imported" to "У датотеци нема картица", "import_error" to "Увоз датотеке није успео", "exported" to "Резервна копија је сачувана", "export_error" to "Чување датотеке није успело"
    )
    return when (lang) { "en" -> en[key] ?: ru[key] ?: key; "sr" -> sr[key] ?: ru[key] ?: key; else -> ru[key] ?: key }
}

private fun seedDecks(): List<StudyDeck> = listOf(
    StudyDeck(title = "Сербский: первые слова", color = 0xFF49B96B, cards = listOf(
        StudyCard(front = "здраво", back = "привет / здравствуйте"),
        StudyCard(front = "хвала", back = "спасибо"),
        StudyCard(front = "молим", back = "пожалуйста / прошу"),
        StudyCard(front = "кућа", back = "дом"),
        StudyCard(front = "вода", back = "вода"),
        StudyCard(front = "чај", back = "чай"),
        StudyCard(front = "мачка", back = "кошка"),
        StudyCard(front = "волети", back = "любить")
    )),
    StudyDeck(title = "История: базовые понятия", color = 0xFF8B78DB, cards = listOf(
        StudyCard(front = "Монархия", back = "Форма правления, при которой власть обычно передаётся по наследству"),
        StudyCard(front = "Колония", back = "Территория, находящаяся под властью другого государства"),
        StudyCard(front = "Республика", back = "Форма правления, при которой высшие органы власти избираются"),
        StudyCard(front = "Хронология", back = "Последовательность исторических событий во времени")
    ))
)

private fun loadLanguage(context: Context): String = context.getSharedPreferences("leksi", Context.MODE_PRIVATE).getString("language", "ru") ?: "ru"

private fun loadDecks(context: Context): List<StudyDeck> {
    val raw = context.getSharedPreferences("leksi", Context.MODE_PRIVATE).getString("decks", null) ?: return seedDecks()
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val d = arr.getJSONObject(i)
            val cardArr = d.optJSONArray("cards") ?: JSONArray()
            val cards = (0 until cardArr.length()).map { j ->
                val c = cardArr.getJSONObject(j)
                StudyCard(
                    id = c.optString("id", UUID.randomUUID().toString()), front = c.optString("front"), back = c.optString("back"),
                    note = c.optString("note"), learned = c.optBoolean("learned", false), dueAt = c.optLong("dueAt", 0L),
                    mastery = c.optInt("mastery", if (c.optBoolean("learned", false)) 3 else 0).coerceIn(0, 5),
                    wrongStreak = c.optInt("wrongStreak", 0), correctStreak = c.optInt("correctStreak", 0),
                    mistakeCount = c.optInt("mistakeCount", 0), needsReview = c.optBoolean("needsReview", false)
                )
            }
            StudyDeck(id = d.optString("id", UUID.randomUUID().toString()), title = d.optString("title", "Набор"), color = d.optLong("color", 0xFF49B96B), cards = cards)
        }
    }.getOrElse { seedDecks() }
}

private fun saveDecks(context: Context, decks: List<StudyDeck>) {
    val arr = JSONArray()
    decks.forEach { deck ->
        val d = JSONObject().put("id", deck.id).put("title", deck.title).put("color", deck.color)
        val cards = JSONArray()
        deck.cards.forEach { c -> cards.put(JSONObject().put("id", c.id).put("front", c.front).put("back", c.back).put("note", c.note).put("learned", c.learned).put("dueAt", c.dueAt).put("mastery", c.mastery).put("wrongStreak", c.wrongStreak).put("correctStreak", c.correctStreak).put("mistakeCount", c.mistakeCount).put("needsReview", c.needsReview)) }
        d.put("cards", cards); arr.put(d)
    }
    context.getSharedPreferences("leksi", Context.MODE_PRIVATE).edit().putString("decks", arr.toString()).apply()
}

private fun csvEscape(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
private fun toCsv(decks: List<StudyDeck>): String = buildString {
    appendLine("set,front,back,note,learned,mastery,wrongStreak,correctStreak,mistakeCount,needsReview,color,cardId,dueAt")
    decks.forEach { deck -> deck.cards.forEach { c ->
        appendLine(listOf(deck.title, c.front, c.back, c.note, c.learned.toString(), c.mastery.toString(), c.wrongStreak.toString(), c.correctStreak.toString(), c.mistakeCount.toString(), c.needsReview.toString(), deck.color.toString(), c.id, c.dueAt.toString()).joinToString(",") { csvEscape(it) })
    } }
}

private fun parseCsv(text: String): List<StudyDeck> {
    val lines = text.lineSequence().filter { it.isNotBlank() }.toList()
    if (lines.size < 2) return emptyList()
    val rows = lines.map { parseCsvLine(it) }
    val header = rows.first().map { it.trim().lowercase() }
    val frontIndex = header.indexOfFirst { it in listOf("front", "word", "question", "term", "слово", "вопрос", "сербский") }.let { if (it < 0) 1 else it }
    val backIndex = header.indexOfFirst { it in listOf("back", "translation", "answer", "definition", "перевод", "ответ", "значение", "русский") }.let { if (it < 0) 2 else it }
    val setIndex = header.indexOfFirst { it in listOf("set", "deck", "category", "folder", "набор", "категория", "папка") }
    val noteIndex = header.indexOfFirst { it in listOf("note", "hint", "примечание", "подсказка") }
    val learnedIndex = header.indexOfFirst { it in listOf("learned", "знаю", "выучено") }
    val masteryIndex = header.indexOfFirst { it in listOf("mastery", "уровень знания", "знание") }
    val wrongIndex = header.indexOfFirst { it in listOf("wrongstreak", "wrong_streak", "ошибки подряд") }
    val correctIndex = header.indexOfFirst { it in listOf("correctstreak", "correct_streak", "верно подряд") }
    val mistakesIndex = header.indexOfFirst { it in listOf("mistakecount", "mistake_count", "всего ошибок") }
    val reviewIndex = header.indexOfFirst { it in listOf("needsreview", "needs_review", "работа над ошибками") }
    val colorIndex = header.indexOfFirst { it in listOf("color", "цвет") }
    val idIndex = header.indexOfFirst { it in listOf("cardid", "card_id", "id карточки") }
    val dueIndex = header.indexOfFirst { it in listOf("dueat", "due_at", "дата повтора") }
    val grouped = linkedMapOf<String, MutableList<StudyCard>>()
    val colors = linkedMapOf<String, Long>()
    rows.drop(1).forEach { row ->
        val front = row.getOrNull(frontIndex)?.trim().orEmpty()
        val back = row.getOrNull(backIndex)?.trim().orEmpty()
        if (front.isNotBlank() && back.isNotBlank()) {
            val title = if (setIndex >= 0) row.getOrNull(setIndex)?.trim().orEmpty().ifBlank { "Импорт" } else "Импорт"
            val note = if (noteIndex >= 0) row.getOrNull(noteIndex).orEmpty() else ""
            val learned = if (learnedIndex >= 0) row.getOrNull(learnedIndex).orEmpty().lowercase() in listOf("true", "1", "yes", "да", "знаю") else false
            val mastery = if (masteryIndex >= 0) row.getOrNull(masteryIndex)?.toIntOrNull()?.coerceIn(0, 5) ?: if (learned) 3 else 0 else if (learned) 3 else 0
            val truthyReview = if (reviewIndex >= 0) row.getOrNull(reviewIndex).orEmpty().lowercase() in listOf("true", "1", "yes", "да") else false
            val cardId = row.getOrNull(idIndex)?.trim().orEmpty().ifBlank { UUID.randomUUID().toString() }
            grouped.getOrPut(title) { mutableListOf() }.add(StudyCard(
                id = cardId, front = front, back = back, note = note, learned = learned,
                dueAt = row.getOrNull(dueIndex)?.toLongOrNull() ?: 0L,
                mastery = mastery, wrongStreak = row.getOrNull(wrongIndex)?.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                correctStreak = row.getOrNull(correctIndex)?.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                mistakeCount = row.getOrNull(mistakesIndex)?.toIntOrNull()?.coerceAtLeast(0) ?: 0,
                needsReview = truthyReview
            ))
            if (colorIndex >= 0) row.getOrNull(colorIndex)?.toLongOrNull()?.let { colors[title] = it }
        }
    }
    return grouped.map { (title, cards) -> StudyDeck(title = title, color = colors[title] ?: 0xFF49B96B, cards = cards) }
}

private fun parseCsvLine(line: String): List<String> {
    val result = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
    while (i < line.length) {
        val ch = line[i]
        when {
            ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { cell.append('"'); i++ }
            ch == '"' -> quoted = !quoted
            ch == ',' && !quoted -> { result.add(cell.toString()); cell.setLength(0) }
            else -> cell.append(ch)
        }
        i++
    }
    result.add(cell.toString())
    return result
}

private fun mergeImported(existing: List<StudyDeck>, imported: List<StudyDeck>): List<StudyDeck> {
    var result = existing
    imported.forEach { incoming ->
        val match = result.firstOrNull { it.title.equals(incoming.title, ignoreCase = true) }
        if (match == null) {
            result = result + incoming
        } else {
            val mergedCards = match.cards.toMutableList()
            incoming.cards.forEach { importedCard ->
                val byId = mergedCards.indexOfFirst { it.id == importedCard.id }
                val byContent = if (byId < 0) mergedCards.indexOfFirst { it.front.equals(importedCard.front, true) && it.back.equals(importedCard.back, true) } else -1
                when {
                    byId >= 0 -> mergedCards[byId] = importedCard
                    byContent >= 0 -> Unit // Legacy CSV has no stable ID or learning fields: preserve the existing card and its progress.
                    else -> mergedCards.add(importedCard)
                }
            }
            result = result.map { d -> if (d.id == match.id) d.copy(color = if (incoming.color != 0xFF49B96B) incoming.color else d.color, cards = mergedCards) else d }
        }
    }
    return result
}

private fun createMistakesDeck(decks: List<StudyDeck>, language: String = "ru"): StudyDeck = StudyDeck(
    id = MISTAKES_DECK_ID,
    title = tx(language, "mistakes_folder"),
    color = 0xFFD94B4B,
    cards = decks.flatMap { it.cards }.filter { it.needsReview }
)

