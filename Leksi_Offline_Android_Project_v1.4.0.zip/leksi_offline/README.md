# Leksi Offline 1.2.0

Offline Android flashcard trainer built with Kotlin and Jetpack Compose.

## Version 1.2.0
- Adds a virtual **Review mistakes / Работа над ошибками** deck populated automatically after wrong answers.
- Tracks word mastery from 0 to 5, consecutive wrong/correct answers, total mistakes, and review status.
- A word is marked familiar only after reaching mastery 3/5 and clearing the review queue; three consecutive correct answers clear the mistake status. Five consecutive wrong answers reset mastery to 0 and mark the word as not learned.
- Exports an expanded CSV backup with card IDs, mastery data, deck colors, and review scheduling data.
- Continues to import legacy CSV files without the new columns; missing fields receive safe defaults. Duplicate cards from legacy backups are not added again.
- Existing on-device JSON data is migrated automatically: older cards keep their content and learned flag; learned cards start at mastery 3/5.

## Build
Use Java 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.


## Leksi 1.3.0 — поиск и офлайн-словарь

- Поиск по существующим карточкам: слово, перевод и заметка.
- Встроенный офлайн-словарь сербского языка с кириллицей, латинской транслитерацией, переводом на русский, примером и тематической категорией.
- Добавление слова из словаря в выбранный набор; если наборов нет, создаётся отдельный набор автоматически.
- Словарь хранится внутри приложения и работает без интернета.


## Leksi 1.4.0

- Расширен встроенный офлайн-словарь сербского языка: включены слова и выражения из учебного списка A1.
- Сохранены поиск по кириллице/латинице и русскому переводу, категории и добавление слов в наборы.
- Если у слова не было примера в исходном списке, добавлена нейтральная подсказка с самим словом; такие примеры стоит постепенно заменить на контекстные предложения.


## Serbian offline dictionary v1.4.0
The built-in dictionary now contains 1855 unique entries, including words and practical phrases. Search works offline and supports Cyrillic and Latin transliteration.
