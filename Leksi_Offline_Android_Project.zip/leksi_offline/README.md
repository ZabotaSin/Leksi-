# Leksi — offline learning cards

An original offline Android flashcard and study app. Its visual direction is playful and friendly, while the learning tools are inspired by common flashcard/study workflows. It does not use Quizlet or Duolingo code, branding, characters, artwork, or downloaded sets.

## Features in this starter build

- Fully offline storage on the device
- User-created study sets and cards
- Edit and delete cards; rename and delete sets
- Flashcard review with “Not yet / I know it” marking
- Multiple-choice test
- Type-the-answer practice
- Matching pairs game
- Per-set and overall progress
- Russian, English, and Serbian interface labels
- CSV import/export for backup and moving user-owned study material
- Starter examples for Serbian vocabulary and history concepts

## CSV format

`set,front,back,note,learned`

CSV import also accepts common alternate header names such as `category`, `word`, `translation`, `question`, and `answer`. If no set/category column is present, imported cards are placed in a set called `Импорт`.

Use content you created yourself, have permission to use, or that is otherwise legally reusable. Personal use does not automatically grant permission to copy another service's protected content or assets.

## Build APK on GitHub

1. Create a new GitHub repository.
2. Upload `Leksi_Offline_Android_Project.zip` to the repository root. The included workflow can unpack this project ZIP automatically. (You can also upload the *contents* of this folder directly; then `settings.gradle.kts` must be at the repository root.)
3. Open **Actions** and run **Build Leksi APK** (or push a commit to `main`/`master`).
4. Open the successful workflow run and download the `Leksi-debug-APK` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser or file manager.

This repository contains the source project and CI workflow; the APK is produced by GitHub Actions. The source ZIP itself is not an APK.
