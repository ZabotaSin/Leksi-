package app.leksi.offline

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.UUID

private val Green = Color(0xFF49B96B)
private val DeepGreen = Color(0xFF197A48)
private val Mint = Color(0xFFE3F7E8)
private val Ink = Color(0xFF20352A)
private val Muted = Color(0xFF78877D)
private val Page = Color(0xFFF5F8F4)
private val Orange = Color(0xFFFFB84D)
private val Red = Color(0xFFD94B4B)
private val Purple = Color(0xFF8B78DB)

private data class StudyCard(
    val id: String = UUID.randomUUID().toString(),
    val front: String,
    val back: String,
    val note: String = "",
    val learned: Boolean = false,
    val dueAt: Long = 0L
)

private data class StudyDeck(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val color: Long = 0xFF49B96B,
    val cards: List<StudyCard> = emptyList()
)

private enum class StudyMode { CARDS, TEST, WRITE, MATCH }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LeksiApp() }
    }
}

@Composable
private fun LeksiApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var decks by remember { mutableStateOf(loadDecks(context)) }
    var language by remember { mutableStateOf(loadLanguage(context)) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedDeckId by remember { mutableStateOf<String?>(null) }
    var activeStudyDeckId by remember { mutableStateOf<String?>(null) }
    var activeMode by remember { mutableStateOf(StudyMode.CARDS) }
    var showDeckDialog by remember { mutableStateOf(false) }
    var editingCard by remember { mutableStateOf<Pair<String, StudyCard?>?>(null) }
    var searchText by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(decks) { saveDecks(context, decks) }
    LaunchedEffect(language) { context.getSharedPreferences("leksi", Context.MODE_PRIVATE).edit().putString("language", language).apply() }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                val text = context.contentResolver.openInputStream(uri)?.use { input -> BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText() } ?: ""
                val imported = parseCsv(text)
                if (imported.isNotEmpty()) {
                    decks = mergeImported(decks, imported)
                    message = tx(language, "imported") + ": ${imported.sumOf { it.cards.size }}"
                } else message = tx(language, "nothing_imported")
            }.onFailure { message = tx(language, "import_error") }
        }
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) runCatching {
            context.contentResolver.openOutputStream(uri)?.use { it.write(toCsv(decks).toByteArray(Charsets.UTF_8)) }
            message = tx(language, "exported")
        }.onFailure { message = tx(language, "export_error") }
    }

    val activeStudyDeck = decks.firstOrNull { it.id == activeStudyDeckId }
    val selectedDeck = decks.firstOrNull { it.id == selectedDeckId }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Green, onPrimary = Color.White, secondary = DeepGreen, background = Page, surface = Color.White, onSurface = Ink),
        typography = Typography(bodyLarge = MaterialTheme.typography.bodyLarge.copy(color = Ink), titleLarge = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold, color = Ink))
    ) {
        if (activeStudyDeck != null) {
            StudyScreen(
                deck = activeStudyDeck,
                mode = activeMode,
                language = language,
                onExit = { activeStudyDeckId = null },
                onUpdateCard = { cardId, learned ->
                    decks = decks.map { d -> if (d.id == activeStudyDeck.id) d.copy(cards = d.cards.map { c -> if (c.id == cardId) c.copy(learned = learned, dueAt = if (learned) System.currentTimeMillis() + 86_400_000L else System.currentTimeMillis() + 300_000L) else c }) else d }
                }
            )
        } else {
            Scaffold(
                containerColor = Page,
                bottomBar = {
                    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
                        NavigationBarItem(selected = selectedTab == 0 && selectedDeckId == null, onClick = { selectedTab = 0; selectedDeckId = null }, icon = { Icon(Icons.Filled.Home, null) }, label = { Text(tx(language, "home")) })
                        NavigationBarItem(selected = selectedTab == 1 || selectedDeckId != null, onClick = { selectedTab = 1; selectedDeckId = null }, icon = { Icon(Icons.Filled.CollectionsBookmark, null) }, label = { Text(tx(language, "sets")) })
                        NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; selectedDeckId = null }, icon = { Icon(Icons.Filled.EmojiEvents, null) }, label = { Text(tx(language, "progress")) })
                        NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3; selectedDeckId = null }, icon = { Icon(Icons.Filled.Settings, null) }, label = { Text(tx(language, "settings")) })
                    }
                }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    if (selectedDeck != null) {
                        DeckDetailScreen(
                            deck = selectedDeck,
                            language = language,
                            onBack = { selectedDeckId = null },
                            onStudy = { mode -> activeStudyDeckId = selectedDeck.id; activeMode = mode },
                            onAddCard = { editingCard = selectedDeck.id to null },
                            onEditCard = { card -> editingCard = selectedDeck.id to card },
                            onDeleteCard = { card -> decks = decks.map { d -> if (d.id == selectedDeck.id) d.copy(cards = d.cards.filterNot { it.id == card.id }) else d } },
                            onRename = { newTitle -> decks = decks.map { if (it.id == selectedDeck.id) it.copy(title = newTitle) else it } },
                            onDeleteDeck = { decks = decks.filterNot { it.id == selectedDeck.id }; selectedDeckId = null }
                        )
                    } else when (selectedTab) {
                        0 -> HomeScreen(decks, language, onStudy = { deck -> activeStudyDeckId = deck.id; activeMode = StudyMode.CARDS }, onOpenDeck = { selectedDeckId = it.id; selectedTab = 1 }, onAllSets = { selectedTab = 1 })
                        1 -> SetsScreen(decks, language, searchText, onSearch = { searchText = it }, onAdd = { showDeckDialog = true }, onOpen = { selectedDeckId = it.id }, onStudy = { activeStudyDeckId = it.id; activeMode = StudyMode.CARDS })
                        2 -> ProgressScreen(decks, language)
                        else -> SettingsScreen(language, onLanguage = { language = it }, onImport = { importLauncher.launch(arrayOf("text/*", "application/csv", "application/vnd.ms-excel")) }, onExport = { exportLauncher.launch("leksi-backup.csv") })
                    }
                }
            }
        }

        if (showDeckDialog) {
            TextEntryDialog(title = tx(language, "new_set"), label = tx(language, "set_name"), confirm = tx(language, "create"), onDismiss = { showDeckDialog = false }) { title ->
                if (title.isNotBlank()) {
                    decks = decks + StudyDeck(title = title.trim(), color = listOf(0xFF49B96B, 0xFF8B78DB, 0xFFFFB84D, 0xFF4DA6D9).random())
                    showDeckDialog = false
                }
            }
        }
        editingCard?.let { (deckId, card) ->
            CardEditorDialog(card = card, language = language, onDismiss = { editingCard = null }) { front, back, note ->
                if (front.isNotBlank() && back.isNotBlank()) {
                    decks = decks.map { d ->
                        if (d.id != deckId) d else if (card == null) d.copy(cards = d.cards + StudyCard(front = front.trim(), back = back.trim(), note = note.trim()))
                        else d.copy(cards = d.cards.map { if (it.id == card.id) it.copy(front = front.trim(), back = back.trim(), note = note.trim()) else it })
                    }
                    editingCard = null
                }
            }
        }
        message?.let { msg ->
            AlertDialog(onDismissRequest = { message = null }, title = { Text(tx(language, "notice")) }, text = { Text(msg) }, confirmButton = { TextButton(onClick = { message = null }) { Text(tx(language, "ok")) } })
        }
    }
}

@Composable
private fun BrandHeader(language: String, subtitle: String? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(15.dp)).background(Green), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text("leksi", fontSize = 23.sp, fontWeight = FontWeight.Black, color = DeepGreen, letterSpacing = (-0.8).sp)
            Text(subtitle ?: tx(language, "learn_play"), fontSize = 12.sp, color = Muted)
        }
        Box(Modifier.clip(CircleShape).background(Mint).padding(horizontal = 11.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Filled.LocalFireDepartment, null, tint = Color(0xFFE89B24), modifier = Modifier.size(17.dp)); Spacer(Modifier.width(4.dp)); Text("1", fontWeight = FontWeight.Bold, color = DeepGreen, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun HomeScreen(decks: List<StudyDeck>, language: String, onStudy: (StudyDeck) -> Unit, onOpenDeck: (StudyDeck) -> Unit, onAllSets: () -> Unit) {
    val allCards = decks.sumOf { it.cards.size }
    val learned = decks.sumOf { d -> d.cards.count { it.learned } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            BrandHeader(language)
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(tx(language, "hello"), fontSize = 29.sp, fontWeight = FontWeight.Black, color = Ink)
                Text(tx(language, "small_steps"), color = Muted, fontSize = 15.sp, modifier = Modifier.padding(top = 3.dp, bottom = 18.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(Green).padding(20.dp)) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(tx(language, "ready_today"), color = Color.White.copy(alpha = .88f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                Text(tx(language, "little_every_day"), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 27.sp, modifier = Modifier.padding(top = 5.dp))
                            }
                            Box(Modifier.size(66.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.School, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("$learned / $allCards", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(tx(language, "cards_learned"), color = Color.White.copy(alpha = .84f), fontSize = 12.sp)
                            }
                            Button(onClick = { decks.firstOrNull { it.cards.isNotEmpty() }?.let(onStudy) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepGreen), shape = RoundedCornerShape(16.dp), enabled = decks.any { it.cards.isNotEmpty() }) {
                                Text(tx(language, "start"), fontWeight = FontWeight.Bold); Spacer(Modifier.width(4.dp)); Icon(Icons.Filled.ArrowForward, null, modifier = Modifier.size(17.dp))
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatPill(Modifier.weight(1f), Icons.Filled.CollectionsBookmark, decks.size.toString(), tx(language, "sets"), Purple)
                    StatPill(Modifier.weight(1f), Icons.Filled.Style, allCards.toString(), tx(language, "cards"), Orange)
                    StatPill(Modifier.weight(1f), Icons.Filled.CheckCircle, learned.toString(), tx(language, "known"), Green)
                }
                Row(Modifier.fillMaxWidth().padding(top = 17.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(language, "your_sets"), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onAllSets) { Text(tx(language, "see_all"), color = DeepGreen) }
                }
            }
        }
        if (decks.isEmpty()) item { EmptyState(language, tx(language, "no_sets"), tx(language, "make_first_set"), Icons.Filled.CollectionsBookmark) }
        items(decks.take(4), key = { it.id }) { deck -> DeckRow(deck, language, onClick = { onOpenDeck(deck) }, onStudy = { onStudy(deck) }) }
    }
}

@Composable
private fun StatPill(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, number: String, label: String, tint: Color) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).padding(horizontal = 12.dp, vertical = 14.dp)) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(19.dp))
        Text(number, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Ink, modifier = Modifier.padding(top = 8.dp))
        Text(label, fontSize = 11.sp, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun SetsScreen(decks: List<StudyDeck>, language: String, searchText: String, onSearch: (String) -> Unit, onAdd: () -> Unit, onOpen: (StudyDeck) -> Unit, onStudy: (StudyDeck) -> Unit) {
    val filtered = decks.filter { it.title.contains(searchText, ignoreCase = true) }
    Column(Modifier.fillMaxSize()) {
        BrandHeader(language, tx(language, "your_library"))
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tx(language, "your_sets"), fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            FilledIconButton(onClick = onAdd, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Green)) { Icon(Icons.Filled.Add, null, tint = Color.White) }
        }
        OutlinedTextField(value = searchText, onValueChange = onSearch, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), placeholder = { Text(tx(language, "search_sets")) }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) }, shape = RoundedCornerShape(18.dp), singleLine = true, colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFFE3EAE2), focusedBorderColor = Green))
        if (filtered.isEmpty()) {
            EmptyState(language, tx(language, "nothing_here"), tx(language, "create_or_search"), Icons.Filled.AutoAwesome)
        } else LazyColumn(contentPadding = PaddingValues(bottom = 20.dp)) { items(filtered, key = { it.id }) { DeckRow(it, language, onClick = { onOpen(it) }, onStudy = { onStudy(it) }) } }
    }
}

@Composable
private fun DeckRow(deck: StudyDeck, language: String, onClick: () -> Unit, onStudy: () -> Unit) {
    val color = Color(deck.color)
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(22.dp)).background(Color.White).clickable(onClick = onClick).padding(15.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(color.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Style, null, tint = color, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(deck.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${deck.cards.size} ${tx(language, "cards_small")}  •  ${deck.cards.count { it.learned }} ${tx(language, "known_small")}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                val progress = if (deck.cards.isEmpty()) 0f else deck.cards.count { it.learned }.toFloat() / deck.cards.size
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(5.dp).clip(CircleShape), color = color, trackColor = color.copy(alpha = .12f))
            }
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onStudy, enabled = deck.cards.isNotEmpty()) { Icon(Icons.Filled.PlayArrow, null, tint = if (deck.cards.isNotEmpty()) DeepGreen else Muted) }
        }
    }
}

@Composable
private fun DeckDetailScreen(deck: StudyDeck, language: String, onBack: () -> Unit, onStudy: (StudyMode) -> Unit, onAddCard: () -> Unit, onEditCard: (StudyCard) -> Unit, onDeleteCard: (StudyCard) -> Unit, onRename: (String) -> Unit, onDeleteDeck: () -> Unit) {
    var showRename by remember { mutableStateOf(false) }
    var showDelete by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null) }
                Text(deck.title, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                IconButton(onClick = { showRename = true }) { Icon(Icons.Filled.Edit, null, tint = Muted) }
                IconButton(onClick = { showDelete = true }) { Icon(Icons.Filled.DeleteOutline, null, tint = Red) }
            }
            Column(Modifier.padding(horizontal = 20.dp)) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Color(deck.color)).padding(20.dp)) {
                    Column {
                        Text(tx(language, "study_set"), color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                        Text(deck.title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 5.dp))
                        Text("${deck.cards.size} ${tx(language, "cards_small")}  •  ${deck.cards.count { it.learned }} ${tx(language, "known_small")}", color = Color.White.copy(alpha = .9f), modifier = Modifier.padding(top = 6.dp))
                        Button(onClick = { onStudy(StudyMode.CARDS) }, enabled = deck.cards.isNotEmpty(), modifier = Modifier.padding(top = 15.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = DeepGreen), shape = RoundedCornerShape(15.dp)) { Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(5.dp)); Text(tx(language, "start_learning"), fontWeight = FontWeight.Bold) }
                    }
                }
                Text(tx(language, "practice_modes"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    ModeTile(Modifier.weight(1f), Icons.Filled.Style, tx(language, "flashcards"), Purple, enabled = deck.cards.isNotEmpty()) { onStudy(StudyMode.CARDS) }
                    ModeTile(Modifier.weight(1f), Icons.Filled.Quiz, tx(language, "test"), Orange, enabled = deck.cards.isNotEmpty()) { onStudy(StudyMode.TEST) }
                }
                Row(Modifier.padding(top = 9.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    ModeTile(Modifier.weight(1f), Icons.Filled.Keyboard, tx(language, "write_answer"), Green, enabled = deck.cards.isNotEmpty()) { onStudy(StudyMode.WRITE) }
                    ModeTile(Modifier.weight(1f), Icons.Filled.GridView, tx(language, "matching"), Color(0xFF4DA6D9), enabled = deck.cards.size >= 2) { onStudy(StudyMode.MATCH) }
                }
                Row(Modifier.fillMaxWidth().padding(top = 23.dp, bottom = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tx(language, "cards_in_set"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    TextButton(onClick = onAddCard) { Icon(Icons.Filled.Add, null); Text(tx(language, "add_card")) }
                }
            }
        }
        if (deck.cards.isEmpty()) item { EmptyState(language, tx(language, "empty_set"), tx(language, "add_first_card"), Icons.Filled.Style) }
        items(deck.cards, key = { it.id }) { card ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp).clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { onEditCard(card) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(4.dp).height(48.dp).clip(CircleShape).background(if (card.learned) Green else Color(0xFFDDE6DC)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(card.front, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(card.back, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp))
                    if (card.note.isNotBlank()) Text(card.note, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 3.dp))
                }
                if (card.learned) Icon(Icons.Filled.CheckCircle, null, tint = Green, modifier = Modifier.size(18.dp))
                IconButton(onClick = { onDeleteCard(card) }) { Icon(Icons.Filled.DeleteOutline, null, tint = Color(0xFFB0BAB1), modifier = Modifier.size(19.dp)) }
            }
        }
    }
    if (showRename) TextEntryDialog(title = tx(language, "rename_set"), label = tx(language, "set_name"), initial = deck.title, confirm = tx(language, "save"), onDismiss = { showRename = false }) { onRename(it.trim()); showRename = false }
    if (showDelete) AlertDialog(onDismissRequest = { showDelete = false }, title = { Text(tx(language, "delete_set")) }, text = { Text(tx(language, "delete_set_warning")) }, confirmButton = { TextButton(onClick = { onDeleteDeck(); showDelete = false }) { Text(tx(language, "delete"), color = Red) } }, dismissButton = { TextButton(onClick = { showDelete = false }) { Text(tx(language, "cancel")) } })
}

@Composable
private fun ModeTile(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, tint: Color, enabled: Boolean, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(19.dp)).background(Color.White).clickable(enabled = enabled, onClick = onClick).padding(14.dp)) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(tint.copy(alpha = .14f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp), color = if (enabled) Ink else Muted)
    }
}

@Composable
private fun StudyScreen(deck: StudyDeck, mode: StudyMode, language: String, onExit: () -> Unit, onUpdateCard: (String, Boolean) -> Unit) {
    var index by remember(deck.id, mode) { mutableIntStateOf(0) }
    var revealed by remember(deck.id, mode) { mutableStateOf(false) }
    var selectedAnswer by remember(deck.id, mode) { mutableStateOf<String?>(null) }
    var typedAnswer by remember(deck.id, mode) { mutableStateOf("") }
    var submitted by remember(deck.id, mode) { mutableStateOf(false) }
    var matched by remember(deck.id, mode) { mutableStateOf(setOf<String>()) }
    var selectedFrontId by remember(deck.id, mode) { mutableStateOf<String?>(null) }
    val cards = if (mode == StudyMode.MATCH) deck.cards.take(6) else deck.cards
    val matchFronts = remember(deck.id, mode) { cards.shuffled() }
    val matchBacks = remember(deck.id, mode) { cards.shuffled() }
    val current = cards.getOrNull(index)
    val options = remember(deck.id, mode, index) {
        current?.let { card -> (cards.filter { it.id != card.id }.map { it.back }.distinct().shuffled().take(3) + card.back).distinct().shuffled() } ?: emptyList()
    }
    Column(Modifier.fillMaxSize().background(Page)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onExit) { Icon(Icons.Filled.Close, null) }
            Column(Modifier.weight(1f)) {
                Text(deck.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(modeLabel(language, mode), color = Muted, fontSize = 12.sp)
            }
            Text(if (mode == StudyMode.MATCH) "${matched.size}/${cards.size}" else "${(index + 1).coerceAtMost(cards.size)} / ${cards.size}", color = DeepGreen, fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(progress = { if (cards.isEmpty()) 0f else if (mode == StudyMode.MATCH) matched.size.toFloat() / cards.size else index.toFloat() / cards.size }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(6.dp).clip(CircleShape), color = Green, trackColor = Color(0xFFE0E9E0))
        if (cards.isEmpty()) {
            EmptyState(language, tx(language, "empty_set"), tx(language, "add_first_card"), Icons.Filled.Style)
        } else if (mode == StudyMode.MATCH) {
            Column(Modifier.fillMaxSize().padding(18.dp)) {
                Text(tx(language, "match_instruction"), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 10.dp))
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        matchFronts.forEach { card ->
                            val done = card.id in matched
                            Surface(modifier = Modifier.fillMaxWidth().weight(1f).clickable(enabled = !done) { selectedFrontId = card.id }, shape = RoundedCornerShape(15.dp), color = when { done -> Mint; selectedFrontId == card.id -> Color(0xFFDDE8FF); else -> Color.White }, border = BorderStroke(1.dp, if (selectedFrontId == card.id) Purple else Color(0xFFE4EAE3))) { Box(Modifier.padding(8.dp), contentAlignment = Alignment.Center) { Text(card.front, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) } }
                        }
                    }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        matchBacks.forEach { card ->
                            val done = card.id in matched
                            Surface(modifier = Modifier.fillMaxWidth().weight(1f).clickable(enabled = !done) {
                                val selected = cards.firstOrNull { it.id == selectedFrontId }
                                if (selected != null && selected.back == card.back) {
                                    matched = matched + selected.id + card.id
                                    onUpdateCard(selected.id, true); onUpdateCard(card.id, true)
                                }
                                selectedFrontId = null
                            }, shape = RoundedCornerShape(15.dp), color = if (done) Mint else Color.White, border = BorderStroke(1.dp, Color(0xFFE4EAE3))) { Box(Modifier.padding(8.dp), contentAlignment = Alignment.Center) { Text(card.back, fontWeight = FontWeight.Medium, fontSize = 13.sp) } }
                        }
                    }
                }
                if (matched.size >= cards.size) Button(onClick = onExit, modifier = Modifier.fillMaxWidth().padding(top = 14.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "finish")) }
            }
        } else if (current == null) {
            Column(Modifier.fillMaxSize().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Box(Modifier.size(94.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Icon(Icons.Filled.EmojiEvents, null, tint = Green, modifier = Modifier.size(52.dp)) }
                Text(tx(language, "session_done"), fontSize = 27.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 20.dp))
                Text(tx(language, "keep_it_up"), color = Muted, modifier = Modifier.padding(top = 7.dp))
                Button(onClick = onExit, modifier = Modifier.fillMaxWidth().padding(top = 25.dp), shape = RoundedCornerShape(16.dp)) { Text(tx(language, "finish")) }
            }
        } else when (mode) {
            StudyMode.CARDS -> {
                Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(tx(language, "tap_to_reveal"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp, bottom = 15.dp))
                    Surface(Modifier.fillMaxWidth().weight(1f).clickable { revealed = !revealed }, shape = RoundedCornerShape(30.dp), color = Color.White, shadowElevation = 3.dp) {
                        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Box(Modifier.clip(CircleShape).background(Mint).padding(horizontal = 12.dp, vertical = 7.dp)) { Text(if (revealed) tx(language, "answer") else tx(language, "question"), color = DeepGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            Text(if (revealed) current.back else current.front, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp, modifier = Modifier.padding(top = 24.dp), color = Ink)
                            if (revealed && current.note.isNotBlank()) Text(current.note, color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 15.dp))
                            if (!revealed) Text(tx(language, "tap_card"), color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 27.dp))
                        }
                    }
                    if (!revealed) Button(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth().padding(top = 18.dp), shape = RoundedCornerShape(17.dp)) { Text(tx(language, "show_answer")) }
                    else Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(onClick = { onUpdateCard(current.id, false); index++; revealed = false }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(17.dp), border = BorderStroke(1.dp, Color(0xFFF0B8B8)), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Icon(Icons.Filled.Replay, null); Spacer(Modifier.width(5.dp)); Text(tx(language, "again"), fontWeight = FontWeight.Bold) }
                        Button(onClick = { onUpdateCard(current.id, true); index++; revealed = false }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(17.dp)) { Icon(Icons.Filled.Check, null); Spacer(Modifier.width(5.dp)); Text(tx(language, "know_it"), fontWeight = FontWeight.Bold) }
                    }
                }
            }
            StudyMode.TEST -> {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Text(tx(language, "choose_translation"), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
                    Text(current.front, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(bottom = 18.dp))
                    options.forEach { option ->
                        val isCorrect = option == current.back
                        val bg = when { selectedAnswer == null -> Color.White; option == selectedAnswer && isCorrect -> Mint; option == selectedAnswer && !isCorrect -> Color(0xFFFFE7E7); isCorrect -> Mint; else -> Color.White }
                        Surface(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable(enabled = selectedAnswer == null) { selectedAnswer = option; onUpdateCard(current.id, isCorrect) }, shape = RoundedCornerShape(17.dp), color = bg, border = BorderStroke(1.dp, when { selectedAnswer == option && isCorrect -> Green; selectedAnswer == option -> Red; else -> Color(0xFFE4EAE3) })) { Text(option, Modifier.padding(16.dp), fontWeight = FontWeight.SemiBold) }
                    }
                    Spacer(Modifier.weight(1f))
                    if (selectedAnswer != null) Text(if (selectedAnswer == current.back) tx(language, "correct") else "${tx(language, "incorrect")} ${current.back}", color = if (selectedAnswer == current.back) DeepGreen else Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp))
                    Button(onClick = { index++; selectedAnswer = null }, enabled = selectedAnswer != null, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) { Text(if (index == cards.lastIndex) tx(language, "finish") else tx(language, "next")) }
                }
            }
            StudyMode.WRITE -> {
                Column(Modifier.fillMaxSize().padding(20.dp)) {
                    Text(tx(language, "type_translation"), color = Muted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 12.dp))
                    Text(current.front, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp, bottom = 25.dp))
                    OutlinedTextField(value = typedAnswer, onValueChange = { typedAnswer = it; submitted = false }, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tx(language, "your_answer")) }, shape = RoundedCornerShape(17.dp), singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))
                    if (submitted) {
                        val ok = typedAnswer.trim().equals(current.back.trim(), ignoreCase = true)
                        Text(if (ok) tx(language, "correct") else "${tx(language, "correct_answer")}: ${current.back}", color = if (ok) DeepGreen else Red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 15.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Button(onClick = {
                        if (!submitted) { submitted = true; onUpdateCard(current.id, typedAnswer.trim().equals(current.back.trim(), ignoreCase = true)) }
                        else { index++; typedAnswer = ""; submitted = false }
                    }, enabled = typedAnswer.isNotBlank(), modifier = Modifier.fillMaxWidth().height(53.dp), shape = RoundedCornerShape(16.dp)) { Text(if (submitted) tx(language, "next") else tx(language, "check_answer")) }
                }
            }
            StudyMode.MATCH -> Unit
        }
    }
}

@Composable
private fun ProgressScreen(decks: List<StudyDeck>, language: String) {
    val total = decks.sumOf { it.cards.size }
    val learned = decks.sumOf { d -> d.cards.count { it.learned } }
    val percent = if (total == 0) 0 else learned * 100 / total
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            BrandHeader(language, tx(language, "your_progress"))
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(tx(language, "progress"), fontSize = 28.sp, fontWeight = FontWeight.Black)
                Text(tx(language, "progress_subtitle"), color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(27.dp)).background(DeepGreen).padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tx(language, "overall_progress"), color = Color.White.copy(alpha = .8f), fontSize = 13.sp)
                            Text("$percent%", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Black)
                            Text("$learned ${tx(language, "of_words")} $total", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                        }
                        Box(Modifier.size(84.dp).clip(CircleShape).background(Color.White.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.TrendingUp, null, tint = Color.White, modifier = Modifier.size(42.dp)) }
                    }
                }
                Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatPill(Modifier.weight(1f), Icons.Filled.CollectionsBookmark, decks.size.toString(), tx(language, "sets"), Purple)
                    StatPill(Modifier.weight(1f), Icons.Filled.Style, total.toString(), tx(language, "cards"), Orange)
                    StatPill(Modifier.weight(1f), Icons.Filled.CheckCircle, learned.toString(), tx(language, "known"), Green)
                }
                Text(tx(language, "by_set"), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 25.dp, bottom = 8.dp))
            }
        }
        items(decks, key = { it.id }) { deck ->
            val count = deck.cards.count { it.learned }
            val progress = if (deck.cards.isEmpty()) 0f else count.toFloat() / deck.cards.size
            Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(19.dp)).background(Color.White).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(deck.title, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${(progress * 100).toInt()}%", color = DeepGreen, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(7.dp).clip(CircleShape), color = Color(deck.color), trackColor = Color(deck.color).copy(alpha = .13f))
                Text("$count ${tx(language, "of_words")} ${deck.cards.size}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 7.dp))
            }
        }
    }
}

@Composable
private fun SettingsScreen(language: String, onLanguage: (String) -> Unit, onImport: () -> Unit, onExport: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader(language, tx(language, "settings"))
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            Text(tx(language, "settings"), fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(tx(language, "personalize"), color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 20.dp))
            Text(tx(language, "interface_language"), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 9.dp))
            listOf("ru" to "🇷🇺 Русский", "en" to "🇬🇧 English", "sr" to "🇷🇸 Српски").forEach { (code, title) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).clickable { onLanguage(code) }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, modifier = Modifier.weight(1f), fontWeight = if (language == code) FontWeight.Bold else FontWeight.Medium)
                    if (language == code) Icon(Icons.Filled.CheckCircle, null, tint = Green)
                }
            }
            Text(tx(language, "data_backup"), fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 8.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(Color.White).clickable(onClick = onImport).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Mint), contentAlignment = Alignment.Center) { Icon(Icons.Filled.FileUpload, null, tint = DeepGreen) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(tx(language, "import_csv"), fontWeight = FontWeight.Bold); Text(tx(language, "import_hint"), fontSize = 12.sp, color = Muted) }
                Icon(Icons.Filled.ChevronRight, null, tint = Muted)
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(17.dp)).background(Color.White).clickable(onClick = onExport).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFFFFF0D8)), contentAlignment = Alignment.Center) { Icon(Icons.Filled.FileDownload, null, tint = Color(0xFFB87813)) }
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) { Text(tx(language, "export_csv"), fontWeight = FontWeight.Bold); Text(tx(language, "export_hint"), fontSize = 12.sp, color = Muted) }
                Icon(Icons.Filled.ChevronRight, null, tint = Muted)
            }
            Text("Leksi 1.0.0", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 28.dp))
            Text(tx(language, "offline_note"), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun EmptyState(language: String, title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 34.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(72.dp).clip(CircleShape).background(Mint), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Green, modifier = Modifier.size(32.dp)) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 14.dp))
        Text(subtitle, fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 5.dp))
    }
}

@Composable
private fun TextEntryDialog(title: String, label: String, initial: String = "", confirm: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember(title, initial) { mutableStateOf(initial) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(label) }, singleLine = true, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)) }, confirmButton = { TextButton(onClick = { onConfirm(value) }, enabled = value.isNotBlank()) { Text(confirm, color = DeepGreen) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun CardEditorDialog(card: StudyCard?, language: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var front by remember(card?.id) { mutableStateOf(card?.front ?: "") }
    var back by remember(card?.id) { mutableStateOf(card?.back ?: "") }
    var note by remember(card?.id) { mutableStateOf(card?.note ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (card == null) tx(language, "new_card") else tx(language, "edit_card")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(front, { front = it }, label = { Text(tx(language, "front_side")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(back, { back = it }, label = { Text(tx(language, "back_side")) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(note, { note = it }, label = { Text(tx(language, "note_optional")) }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(front, back, note) }, enabled = front.isNotBlank() && back.isNotBlank()) { Text(tx(language, "save"), color = DeepGreen) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "cancel")) } }
    )
}

private fun modeLabel(language: String, mode: StudyMode): String = when (mode) {
    StudyMode.CARDS -> tx(language, "flashcards")
    StudyMode.TEST -> tx(language, "test")
    StudyMode.WRITE -> tx(language, "write_answer")
    StudyMode.MATCH -> tx(language, "matching")
}

private fun tx(lang: String, key: String): String {
    val ru = mapOf(
        "home" to "Главная", "sets" to "Наборы", "progress" to "Прогресс", "settings" to "Настройки", "learn_play" to "Учись играя", "hello" to "Привет! 👋", "small_steps" to "Немного каждый день — большой результат.", "ready_today" to "ТВОЙ ШАГ НА СЕГОДНЯ", "little_every_day" to "Пять минут — и ты уже ближе к цели", "cards_learned" to "карточек уже освоено", "start" to "Начать", "cards" to "Карточки", "known" to "Знаю", "your_sets" to "Твои наборы", "see_all" to "Все", "no_sets" to "Пока пусто", "make_first_set" to "Создай первый набор в разделе «Наборы»", "your_library" to "Твоя библиотека", "search_sets" to "Найти набор…", "nothing_here" to "Ничего не найдено", "create_or_search" to "Создай набор или измени поиск", "new_set" to "Новый набор", "set_name" to "Название набора", "create" to "Создать", "study_set" to "НАБОР ДЛЯ ОБУЧЕНИЯ", "cards_small" to "карточек", "known_small" to "знаю", "start_learning" to "Учить", "practice_modes" to "Режимы тренировки", "flashcards" to "Карточки", "test" to "Тест", "write_answer" to "Ввод ответа", "matching" to "Пары", "cards_in_set" to "Карточки набора", "add_card" to "Добавить", "empty_set" to "В этом наборе пока нет карточек", "add_first_card" to "Добавь первую карточку кнопкой выше", "rename_set" to "Переименовать набор", "save" to "Сохранить", "delete_set" to "Удалить набор?", "delete_set_warning" to "Все карточки этого набора будут удалены. Это действие нельзя отменить.", "delete" to "Удалить", "cancel" to "Отмена", "tap_to_reveal" to "Вспомни ответ, прежде чем открыть карточку", "answer" to "ОТВЕТ", "question" to "ВОПРОС", "tap_card" to "Нажми, чтобы перевернуть", "show_answer" to "Показать ответ", "again" to "Не помню", "know_it" to "Уже знаю", "session_done" to "Отличная работа!", "keep_it_up" to "Каждая повторённая карточка приближает тебя к цели.", "finish" to "Завершить", "choose_translation" to "Выбери правильный перевод", "correct" to "Верно! Отлично!", "incorrect" to "Не совсем. Правильный ответ:", "next" to "Далее", "type_translation" to "Напиши ответ самостоятельно", "your_answer" to "Твой ответ…", "correct_answer" to "Правильный ответ", "check_answer" to "Проверить", "match_instruction" to "Соедини слово слева с его переводом справа.", "your_progress" to "Как идут занятия", "progress_subtitle" to "Маленькие победы складываются в большой прогресс.", "overall_progress" to "ОБЩИЙ ПРОГРЕСС", "of_words" to "из", "by_set" to "Прогресс по наборам", "personalize" to "Настрой приложение под себя.", "interface_language" to "Язык интерфейса", "data_backup" to "Импорт и резервная копия", "import_csv" to "Импортировать CSV", "import_hint" to "Добавить карточки из таблицы", "export_csv" to "Экспортировать CSV", "export_hint" to "Сохранить все наборы и карточки", "offline_note" to "Работает офлайн. Твои данные остаются на устройстве.", "new_card" to "Новая карточка", "edit_card" to "Изменить карточку", "front_side" to "Вопрос / слово", "back_side" to "Ответ / перевод", "note_optional" to "Подсказка (необязательно)", "notice" to "Готово", "ok" to "ОК", "imported" to "Импортировано наборов/карточек", "nothing_imported" to "В файле не найдено карточек", "import_error" to "Не удалось импортировать файл", "exported" to "Резервная копия сохранена", "export_error" to "Не удалось сохранить файл"
    )
    val en = mapOf(
        "home" to "Home", "sets" to "Sets", "progress" to "Progress", "settings" to "Settings", "learn_play" to "Learn by playing", "hello" to "Hey there! 👋", "small_steps" to "A little every day adds up.", "ready_today" to "YOUR DAILY STEP", "little_every_day" to "Five minutes closer to your goal", "cards_learned" to "cards learned", "start" to "Start", "cards" to "Cards", "known" to "Known", "your_sets" to "Your sets", "see_all" to "See all", "no_sets" to "Nothing here yet", "make_first_set" to "Create your first set in the Sets tab", "your_library" to "Your library", "search_sets" to "Search sets…", "nothing_here" to "Nothing found", "create_or_search" to "Create a set or change your search", "new_set" to "New set", "set_name" to "Set name", "create" to "Create", "study_set" to "STUDY SET", "cards_small" to "cards", "known_small" to "known", "start_learning" to "Study", "practice_modes" to "Practice modes", "flashcards" to "Flashcards", "test" to "Test", "write_answer" to "Type answer", "matching" to "Match pairs", "cards_in_set" to "Cards in this set", "add_card" to "Add", "empty_set" to "This set has no cards yet", "add_first_card" to "Add your first card above", "rename_set" to "Rename set", "save" to "Save", "delete_set" to "Delete set?", "delete_set_warning" to "All cards in this set will be deleted. This cannot be undone.", "delete" to "Delete", "cancel" to "Cancel", "tap_to_reveal" to "Try to remember before revealing", "answer" to "ANSWER", "question" to "QUESTION", "tap_card" to "Tap to flip", "show_answer" to "Show answer", "again" to "Not yet", "know_it" to "I know it", "session_done" to "Great work!", "keep_it_up" to "Every review brings you closer to your goal.", "finish" to "Finish", "choose_translation" to "Choose the correct answer", "correct" to "Correct! Nice work!", "incorrect" to "Not quite. Correct answer:", "next" to "Next", "type_translation" to "Type the answer yourself", "your_answer" to "Your answer…", "correct_answer" to "Correct answer", "check_answer" to "Check answer", "match_instruction" to "Match each word on the left with its translation.", "your_progress" to "Your learning journey", "progress_subtitle" to "Small wins add up to real progress.", "overall_progress" to "OVERALL PROGRESS", "of_words" to "of", "by_set" to "Progress by set", "personalize" to "Make the app yours.", "interface_language" to "Interface language", "data_backup" to "Import & backup", "import_csv" to "Import CSV", "import_hint" to "Add cards from a spreadsheet", "export_csv" to "Export CSV", "export_hint" to "Save all sets and cards", "offline_note" to "Works offline. Your data stays on your device.", "new_card" to "New card", "edit_card" to "Edit card", "front_side" to "Question / word", "back_side" to "Answer / translation", "note_optional" to "Hint (optional)", "notice" to "Done", "ok" to "OK", "imported" to "Imported cards", "nothing_imported" to "No cards found in the file", "import_error" to "Could not import this file", "exported" to "Backup saved", "export_error" to "Could not save the file"
    )
    val sr = mapOf(
        "home" to "Почетна", "sets" to "Сетови", "progress" to "Напредак", "settings" to "Подешавања", "learn_play" to "Учи кроз игру", "hello" to "Здраво! 👋", "small_steps" to "Мало сваког дана доноси много.", "ready_today" to "ТВОЈ ДНЕВНИ КОРАК", "little_every_day" to "Пет минута ближе циљу", "cards_learned" to "научених картица", "start" to "Почни", "cards" to "Картице", "known" to "Знам", "your_sets" to "Твоји сетови", "see_all" to "Сви", "no_sets" to "Још нема ничега", "make_first_set" to "Направи први сет у одељку Сетови", "your_library" to "Твоја библиотека", "search_sets" to "Претражи сетове…", "nothing_here" to "Ништа није пронађено", "create_or_search" to "Направи сет или промени претрагу", "new_set" to "Нови сет", "set_name" to "Назив сета", "create" to "Направи", "study_set" to "СЕТ ЗА УЧЕЊЕ", "cards_small" to "картица", "known_small" to "знам", "start_learning" to "Учи", "practice_modes" to "Начини вежбања", "flashcards" to "Картице", "test" to "Тест", "write_answer" to "Унеси одговор", "matching" to "Спари парове", "cards_in_set" to "Картице у сету", "add_card" to "Додај", "empty_set" to "Овај сет још нема картица", "add_first_card" to "Додај прву картицу изнад", "rename_set" to "Преименуј сет", "save" to "Сачувај", "delete_set" to "Обриши сет?", "delete_set_warning" to "Све картице из овог сета биће обрисане.", "delete" to "Обриши", "cancel" to "Откажи", "tap_to_reveal" to "Покушај да се сетиш пре откривања", "answer" to "ОДГОВОР", "question" to "ПИТАЊЕ", "tap_card" to "Додирни да окренеш", "show_answer" to "Прикажи одговор", "again" to "Не знам", "know_it" to "Знам", "session_done" to "Одличан посао!", "keep_it_up" to "Свако понављање те приближава циљу.", "finish" to "Заврши", "choose_translation" to "Изабери тачан одговор", "correct" to "Тачно! Браво!", "incorrect" to "Није сасвим. Тачан одговор:", "next" to "Даље", "type_translation" to "Самостално упиши одговор", "your_answer" to "Твој одговор…", "correct_answer" to "Тачан одговор", "check_answer" to "Провери", "match_instruction" to "Повежи реч са леве стране са преводом.", "your_progress" to "Твој напредак", "progress_subtitle" to "Мале победе доносе велики напредак.", "overall_progress" to "УКУПАН НАПРЕДАК", "of_words" to "од", "by_set" to "Напредак по сетовима", "personalize" to "Прилагоди апликацију себи.", "interface_language" to "Језик интерфејса", "data_backup" to "Увоз и резервна копија", "import_csv" to "Увези CSV", "import_hint" to "Додај картице из табеле", "export_csv" to "Извези CSV", "export_hint" to "Сачувај све сетове и картице", "offline_note" to "Ради без интернета. Подаци остају на уређају.", "new_card" to "Нова картица", "edit_card" to "Измени картицу", "front_side" to "Питање / реч", "back_side" to "Одговор / превод", "note_optional" to "Напомена (опционо)", "notice" to "Готово", "ok" to "У реду", "imported" to "Увезене картице", "nothing_imported" to "У датотеци нема картица", "import_error" to "Увоз датотеке није успео", "exported" to "Резервна копија је сачувана", "export_error" to "Чување датотеке није успело"
    )
    return when (lang) { "en" -> en[key] ?: ru[key] ?: key; "sr" -> sr[key] ?: ru[key] ?: key; else -> ru[key] ?: key }
}

private fun seedDecks(): List<StudyDeck> = listOf(
    StudyDeck(title = "Сербский: первые слова", color = 0xFF49B96B, cards = listOf(
        StudyCard(front = "здраво", back = "привет / здравствуйте"),
        StudyCard(front = "хвала", back = "спасибо"),
        StudyCard(front = "молим", back = "пожалуйста / прошу"),
        StudyCard(front = "кућа", back = "дом"),
        StudyCard(front = "вода", back = "вода"),
        StudyCard(front = "чај", back = "чай"),
        StudyCard(front = "мачка", back = "кошка"),
        StudyCard(front = "волети", back = "любить")
    )),
    StudyDeck(title = "История: базовые понятия", color = 0xFF8B78DB, cards = listOf(
        StudyCard(front = "Монархия", back = "Форма правления, при которой власть обычно передаётся по наследству"),
        StudyCard(front = "Колония", back = "Территория, находящаяся под властью другого государства"),
        StudyCard(front = "Республика", back = "Форма правления, при которой высшие органы власти избираются"),
        StudyCard(front = "Хронология", back = "Последовательность исторических событий во времени")
    ))
)

private fun loadLanguage(context: Context): String = context.getSharedPreferences("leksi", Context.MODE_PRIVATE).getString("language", "ru") ?: "ru"

private fun loadDecks(context: Context): List<StudyDeck> {
    val raw = context.getSharedPreferences("leksi", Context.MODE_PRIVATE).getString("decks", null) ?: return seedDecks()
    return runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val d = arr.getJSONObject(i)
            val cardArr = d.optJSONArray("cards") ?: JSONArray()
            val cards = (0 until cardArr.length()).map { j ->
                val c = cardArr.getJSONObject(j)
                StudyCard(id = c.optString("id", UUID.randomUUID().toString()), front = c.optString("front"), back = c.optString("back"), note = c.optString("note"), learned = c.optBoolean("learned", false), dueAt = c.optLong("dueAt", 0L))
            }
            StudyDeck(id = d.optString("id", UUID.randomUUID().toString()), title = d.optString("title", "Набор"), color = d.optLong("color", 0xFF49B96B), cards = cards)
        }
    }.getOrElse { seedDecks() }
}

private fun saveDecks(context: Context, decks: List<StudyDeck>) {
    val arr = JSONArray()
    decks.forEach { deck ->
        val d = JSONObject().put("id", deck.id).put("title", deck.title).put("color", deck.color)
        val cards = JSONArray()
        deck.cards.forEach { c -> cards.put(JSONObject().put("id", c.id).put("front", c.front).put("back", c.back).put("note", c.note).put("learned", c.learned).put("dueAt", c.dueAt)) }
        d.put("cards", cards); arr.put(d)
    }
    context.getSharedPreferences("leksi", Context.MODE_PRIVATE).edit().putString("decks", arr.toString()).apply()
}

private fun csvEscape(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""
private fun toCsv(decks: List<StudyDeck>): String = buildString {
    appendLine("set,front,back,note,learned")
    decks.forEach { deck -> deck.cards.forEach { c -> appendLine(listOf(deck.title, c.front, c.back, c.note, c.learned.toString()).joinToString(",") { csvEscape(it) }) } }
}

private fun parseCsv(text: String): List<StudyDeck> {
    val lines = text.lineSequence().filter { it.isNotBlank() }.toList()
    if (lines.size < 2) return emptyList()
    val rows = lines.map { parseCsvLine(it) }
    val header = rows.first().map { it.trim().lowercase() }
    val frontIndex = header.indexOfFirst { it in listOf("front", "word", "question", "term", "слово", "вопрос", "сербский") }.let { if (it < 0) 1 else it }
    val backIndex = header.indexOfFirst { it in listOf("back", "translation", "answer", "definition", "перевод", "ответ", "значение", "русский") }.let { if (it < 0) 2 else it }
    val setIndex = header.indexOfFirst { it in listOf("set", "deck", "category", "folder", "набор", "категория", "папка") }
    val noteIndex = header.indexOfFirst { it in listOf("note", "hint", "примечание", "подсказка") }
    val learnedIndex = header.indexOfFirst { it in listOf("learned", "знаю", "выучено") }
    val grouped = linkedMapOf<String, MutableList<StudyCard>>()
    rows.drop(1).forEach { row ->
        val front = row.getOrNull(frontIndex)?.trim().orEmpty()
        val back = row.getOrNull(backIndex)?.trim().orEmpty()
        if (front.isNotBlank() && back.isNotBlank()) {
            val title = if (setIndex >= 0) row.getOrNull(setIndex)?.trim().orEmpty().ifBlank { "Импорт" } else "Импорт"
            val note = if (noteIndex >= 0) row.getOrNull(noteIndex).orEmpty() else ""
            val learned = if (learnedIndex >= 0) row.getOrNull(learnedIndex).orEmpty().lowercase() in listOf("true", "1", "yes", "да", "знаю") else false
            grouped.getOrPut(title) { mutableListOf() }.add(StudyCard(front = front, back = back, note = note, learned = learned))
        }
    }
    return grouped.map { StudyDeck(title = it.key, cards = it.value) }
}

private fun parseCsvLine(line: String): List<String> {
    val result = mutableListOf<String>(); val cell = StringBuilder(); var quoted = false; var i = 0
    while (i < line.length) {
        val ch = line[i]
        when {
            ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { cell.append('"'); i++ }
            ch == '"' -> quoted = !quoted
            ch == ',' && !quoted -> { result.add(cell.toString()); cell.setLength(0) }
            else -> cell.append(ch)
        }
        i++
    }
    result.add(cell.toString())
    return result
}

private fun mergeImported(existing: List<StudyDeck>, imported: List<StudyDeck>): List<StudyDeck> {
    var result = existing
    imported.forEach { incoming ->
        val match = result.firstOrNull { it.title.equals(incoming.title, ignoreCase = true) }
        result = if (match == null) result + incoming else result.map { if (it.id == match.id) it.copy(cards = it.cards + incoming.cards) else it }
    }
    return result
}
